-- ============================================================================
-- 003 — Notifications push (version 3)
-- À exécuter après 000, 001 et 002.
-- ============================================================================

-- Une notification est marquée une fois poussée sur les téléphones (évite les doublons)
alter table public.notifications add column if not exists pushed_at timestamptz;

-- Table des appareils abonnés (elle existe déjà si tu utilisais l'ancienne application)
create table if not exists public.push_subscriptions (
  endpoint text primary key,
  p256dh text not null,
  auth text not null,
  created_at timestamptz not null default now()
);
alter table public.push_subscriptions add column if not exists user_id uuid references auth.users(id) on delete cascade;
alter table public.push_subscriptions add column if not exists created_at timestamptz not null default now();

-- Les anciens abonnements n'étaient pas liés à un compte : on les supprime.
-- Chaque colocataire réactive les notifications une fois dans Profil.
delete from public.push_subscriptions where user_id is null;

-- Nouvelle règle : un abonnement n'appartient qu'à son propriétaire.
-- (L'ancienne règle « tout compte connecté » laissait chacun lire les appareils des autres.)
do $$
declare p record;
begin
  alter table public.push_subscriptions enable row level security;
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'push_subscriptions' loop
    execute format('drop policy %I on public.push_subscriptions', p.policyname);
  end loop;
end $$;

create policy push_subscriptions_select on public.push_subscriptions for select to authenticated
  using (user_id = auth.uid());
revoke insert, update, delete on public.push_subscriptions from authenticated;

-- Écriture par fonctions : si un même téléphone passe d'un compte à un autre,
-- l'appareil est simplement rattaché au compte qui se connecte.
create or replace function public.save_push_subscription(p_endpoint text, p_p256dh text, p_auth text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Non connecté'; end if;
  if coalesce(p_endpoint, '') = '' or coalesce(p_p256dh, '') = '' or coalesce(p_auth, '') = '' then
    raise exception 'Abonnement incomplet';
  end if;
  insert into public.push_subscriptions (endpoint, p256dh, auth, user_id)
  values (p_endpoint, p_p256dh, p_auth, auth.uid())
  on conflict (endpoint) do update
    set p256dh = excluded.p256dh, auth = excluded.auth, user_id = auth.uid();
end;
$$;

create or replace function public.delete_push_subscription(p_endpoint text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Non connecté'; end if;
  delete from public.push_subscriptions where endpoint = p_endpoint and user_id = auth.uid();
end;
$$;

revoke all on function public.save_push_subscription(text, text, text) from public, anon;
revoke all on function public.delete_push_subscription(text) from public, anon;
grant execute on function public.save_push_subscription(text, text, text) to authenticated;
grant execute on function public.delete_push_subscription(text) to authenticated;

-- Contrôle : chaque ligne doit être réservée au rôle {authenticated}
select tablename, policyname, roles, cmd from pg_policies
where schemaname = 'public' and tablename = 'push_subscriptions';
