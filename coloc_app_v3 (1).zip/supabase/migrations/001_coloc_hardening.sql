-- ColocApp — migration 001 : paiements sécurisés, notifications, membres, création atomique
-- À exécuter dans Supabase → SQL Editor. Idempotente : peut être relancée sans risque.

-- 1. Montant déclaré mais pas encore confirmé (évite de compter un paiement non confirmé)
alter table public.invoice_shares
  add column if not exists pending_amount numeric(12,2) not null default 0;

-- 2. Création automatique du profil à l'inscription (ne bloque jamais l'inscription)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
exception when others then
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 3. Fonctions utilitaires
create or replace function public.is_apartment_member(apt uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.members where apartment_id = apt and user_id = auth.uid() and is_active);
$$;

create or replace function public.is_apartment_admin(apt uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.members where apartment_id = apt and user_id = auth.uid() and is_active and role = 'admin');
$$;

create or replace function public.push_notification(p_user uuid, p_title text, p_body text, p_type text, p_link text)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, type, link) values (p_user, p_title, p_body, p_type, p_link);
$$;
-- Interne uniquement : sinon n'importe quel utilisateur pourrait spammer les autres
revoke all on function public.push_notification(uuid, text, text, text, text) from public, anon, authenticated;

-- 4. Création / adhésion à un appartement (atomique, rôle imposé côté serveur)
create or replace function public.create_apartment(p_name text, p_address text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Non connecté'; end if;
  if exists (select 1 from public.members where user_id = auth.uid() and is_active) then
    raise exception 'Tu fais déjà partie d''un appartement';
  end if;
  if char_length(trim(coalesce(p_name, ''))) < 2 then raise exception 'Nom trop court'; end if;
  insert into public.apartments (name, address, created_by)
    values (trim(p_name), nullif(trim(coalesce(p_address, '')), ''), auth.uid())
    returning id into v_id;
  insert into public.members (apartment_id, user_id, role) values (v_id, auth.uid(), 'admin');
  return v_id;
end $$;

create or replace function public.join_apartment(p_code text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Non connecté'; end if;
  if exists (select 1 from public.members where user_id = auth.uid() and is_active) then
    raise exception 'Tu fais déjà partie d''un appartement';
  end if;
  select id into v_id from public.apartments where invite_code = upper(trim(p_code));
  if v_id is null then raise exception 'Code d''invitation invalide'; end if;
  if exists (select 1 from public.members where apartment_id = v_id and user_id = auth.uid()) then
    update public.members set is_active = true, role = 'member' where apartment_id = v_id and user_id = auth.uid();
  else
    insert into public.members (apartment_id, user_id, role) values (v_id, auth.uid(), 'member');
  end if;
  return v_id;
end $$;

-- 5. Gestion des membres
create or replace function public.set_member_role(p_member uuid, p_role text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members%rowtype;
begin
  if p_role not in ('admin', 'manager', 'member') then raise exception 'Rôle invalide'; end if;
  select * into m from public.members where id = p_member;
  if not found then raise exception 'Membre introuvable'; end if;
  if not public.is_apartment_admin(m.apartment_id) then raise exception 'Réservé aux administrateurs'; end if;
  if m.role = 'admin' and p_role <> 'admin'
     and (select count(*) from public.members where apartment_id = m.apartment_id and is_active and role = 'admin') <= 1 then
    raise exception 'Il doit rester au moins un administrateur';
  end if;
  update public.members set role = p_role where id = p_member;
end $$;

create or replace function public.remove_member(p_member uuid) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members%rowtype;
begin
  select * into m from public.members where id = p_member;
  if not found then raise exception 'Membre introuvable'; end if;
  if not public.is_apartment_admin(m.apartment_id) then raise exception 'Réservé aux administrateurs'; end if;
  if m.user_id = auth.uid() then raise exception 'Utilise « Quitter l''appartement »'; end if;
  update public.members set is_active = false where id = p_member;
end $$;

create or replace function public.leave_apartment(p_apartment uuid) returns void
language plpgsql security definer set search_path = public as $$
declare m public.members%rowtype;
begin
  select * into m from public.members where apartment_id = p_apartment and user_id = auth.uid() and is_active;
  if not found then raise exception 'Tu ne fais pas partie de cet appartement'; end if;
  if exists (
    select 1 from public.invoice_shares s join public.invoices i on i.id = s.invoice_id
    where i.apartment_id = p_apartment and s.status <> 'confirmed'
      and (s.debtor_id = auth.uid() or s.creditor_id = auth.uid())
      and s.amount_due - s.amount_paid > 0.005
  ) then
    raise exception 'Solde tes dettes et créances avant de quitter l''appartement';
  end if;
  if m.role = 'admin'
     and not exists (select 1 from public.members where apartment_id = p_apartment and is_active and role = 'admin' and user_id <> auth.uid())
     and exists (select 1 from public.members where apartment_id = p_apartment and is_active and user_id <> auth.uid()) then
    raise exception 'Nomme un autre administrateur avant de partir';
  end if;
  update public.members set is_active = false where id = m.id;
end $$;

create or replace function public.regenerate_invite_code(p_apartment uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_code text;
begin
  if not public.is_apartment_admin(p_apartment) then raise exception 'Réservé aux administrateurs'; end if;
  update public.apartments set invite_code = upper(substr(md5(gen_random_uuid()::text), 1, 8))
    where id = p_apartment returning invite_code into v_code;
  return v_code;
end $$;

-- 6. Facture + parts créées dans la même transaction (le reste des centimes reste à celui qui a payé)
create or replace function public.create_invoice_with_shares(
  p_apartment uuid, p_title text, p_amount numeric, p_category text, p_due date, p_debtors uuid[]
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_n int; v_base numeric; v_debtor uuid; v_debtors uuid[];
begin
  if not public.is_apartment_member(p_apartment) then raise exception 'Tu ne fais pas partie de cet appartement'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Montant invalide'; end if;
  if char_length(trim(coalesce(p_title, ''))) = 0 then raise exception 'Titre requis'; end if;

  v_debtors := array(select distinct x from unnest(coalesce(p_debtors, '{}'::uuid[])) x where x <> auth.uid());
  if exists (
    select 1 from unnest(v_debtors) x
    where not exists (select 1 from public.members m where m.apartment_id = p_apartment and m.user_id = x and m.is_active)
  ) then raise exception 'Participant invalide'; end if;

  insert into public.invoices (apartment_id, title, amount, category, due_date, paid_by, created_by, status)
    values (p_apartment, trim(p_title), round(p_amount, 2), p_category, p_due, auth.uid(), auth.uid(), 'pending')
    returning id into v_id;

  v_n := coalesce(array_length(v_debtors, 1), 0) + 1;
  v_base := floor(round(p_amount, 2) * 100 / v_n) / 100;
  foreach v_debtor in array v_debtors loop
    insert into public.invoice_shares (invoice_id, debtor_id, creditor_id, amount_due, status)
      values (v_id, v_debtor, auth.uid(), v_base, 'pending');
  end loop;
  return v_id;
end $$;

-- 7. Paiements : le serveur vérifie qui a le droit de faire quoi
create or replace function public.declare_payment(p_share uuid, p_amount numeric, p_method text) returns void
language plpgsql security definer set search_path = public as $$
declare s public.invoice_shares%rowtype; v_title text;
begin
  select * into s from public.invoice_shares where id = p_share for update;
  if not found then raise exception 'Dette introuvable'; end if;
  if s.debtor_id <> auth.uid() then raise exception 'Tu n''es pas le débiteur de cette dette'; end if;
  if s.status not in ('pending', 'disputed') then raise exception 'Cette dette n''accepte pas de paiement pour le moment'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > (s.amount_due - s.amount_paid) + 0.005 then
    raise exception 'Montant invalide';
  end if;
  update public.invoice_shares
    set pending_amount = round(p_amount, 2), payment_method = p_method, paid_at = now(),
        status = 'awaiting_confirmation', dispute_reason = null
    where id = p_share;
  select title into v_title from public.invoices where id = s.invoice_id;
  perform public.push_notification(s.creditor_id, 'Paiement à confirmer',
    format('%s MAD déclaré pour « %s »', round(p_amount, 2), v_title), 'debt', '/dettes/' || p_share || '/confirmer');
end $$;

create or replace function public.confirm_payment(p_share uuid) returns void
language plpgsql security definer set search_path = public as $$
declare s public.invoice_shares%rowtype; v_paid numeric; v_title text; v_done boolean;
begin
  select * into s from public.invoice_shares where id = p_share for update;
  if not found then raise exception 'Dette introuvable'; end if;
  if s.creditor_id <> auth.uid() then raise exception 'Tu n''es pas le créancier de cette dette'; end if;
  if s.status <> 'awaiting_confirmation' then raise exception 'Aucun paiement en attente'; end if;
  v_paid := s.amount_paid + s.pending_amount;
  v_done := v_paid >= s.amount_due - 0.005;
  update public.invoice_shares
    set amount_paid = v_paid, pending_amount = 0,
        status = case when v_done then 'confirmed' else 'pending' end,
        confirmed_at = case when v_done then now() else confirmed_at end
    where id = p_share;
  select title into v_title from public.invoices where id = s.invoice_id;
  perform public.push_notification(s.debtor_id, 'Paiement confirmé',
    format('Ton paiement pour « %s » a été confirmé', v_title), 'debt', '/dettes');
end $$;

create or replace function public.dispute_payment(p_share uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare s public.invoice_shares%rowtype; v_title text;
begin
  select * into s from public.invoice_shares where id = p_share for update;
  if not found then raise exception 'Dette introuvable'; end if;
  if s.creditor_id <> auth.uid() then raise exception 'Tu n''es pas le créancier de cette dette'; end if;
  if s.status <> 'awaiting_confirmation' then raise exception 'Aucun paiement en attente'; end if;
  update public.invoice_shares
    set pending_amount = 0, status = 'pending', dispute_reason = coalesce(nullif(trim(p_reason), ''), 'Aucun motif précisé')
    where id = p_share;
  select title into v_title from public.invoices where id = s.invoice_id;
  perform public.push_notification(s.debtor_id, 'Paiement contesté',
    format('Ton paiement pour « %s » a été contesté', v_title), 'debt', '/dettes/' || p_share || '/payer');
end $$;

-- 8. Notifications automatiques
create or replace function public.trg_share_created() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_title text;
begin
  select title into v_title from public.invoices where id = new.invoice_id;
  perform public.push_notification(new.debtor_id, 'Nouvelle dette',
    format('Tu dois %s MAD pour « %s »', new.amount_due, v_title), 'debt', '/dettes/' || new.id || '/payer');
  return new;
end $$;
drop trigger if exists on_share_created on public.invoice_shares;
create trigger on_share_created after insert on public.invoice_shares
  for each row execute function public.trg_share_created();

create or replace function public.trg_task_assigned() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.assigned_to is not null
     and (tg_op = 'INSERT' or new.assigned_to is distinct from old.assigned_to)
     and new.assigned_to is distinct from auth.uid() then
    perform public.push_notification(new.assigned_to, 'Nouvelle tâche', new.title, 'task', '/taches');
  end if;
  return new;
end $$;
drop trigger if exists on_task_assigned on public.tasks;
create trigger on_task_assigned after insert or update of assigned_to on public.tasks
  for each row execute function public.trg_task_assigned();

-- 9. Droits d'exécution : réservé aux utilisateurs connectés
do $$
declare f text;
begin
  foreach f in array array[
    'create_apartment(text,text)', 'join_apartment(text)', 'set_member_role(uuid,text)', 'remove_member(uuid)',
    'leave_apartment(uuid)', 'regenerate_invite_code(uuid)',
    'create_invoice_with_shares(uuid,text,numeric,text,date,uuid[])',
    'declare_payment(uuid,numeric,text)', 'confirm_payment(uuid)', 'dispute_payment(uuid,text)'
  ] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;

-- 10. Les parts de dette ne se modifient plus qu'à travers les fonctions ci-dessus
revoke update on public.invoice_shares from authenticated;

-- 11. Temps réel (chat, notifications, dettes, tâches)
do $$
declare t text;
begin
  foreach t in array array['notifications', 'messages', 'invoice_shares', 'tasks'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object or undefined_object then null;
    end;
  end loop;
end $$;

-- À faire à la main dans le dashboard Supabase :
--  • Storage : bucket PRIVÉ « receipts » (photos d'équipements et reçus de factures)
--  • Auth → URL Configuration : ajouter l'URL de production et http://localhost:5173 aux Redirect URLs
--  • Vérifier que le RLS est activé sur TOUTES les tables (la clé anon est publique)
