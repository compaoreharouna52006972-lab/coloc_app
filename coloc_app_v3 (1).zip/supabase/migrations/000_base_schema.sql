-- ============================================================================
-- 000 — Schéma de base : tables, règles d'accès (RLS) et dossier de reçus
-- À exécuter EN PREMIER (SQL Editor), puis 001, 002 et 003 dans l'ordre.
-- Rejouable : tu peux le relancer sans risque.
--
-- Principe de visibilité :
--   * les factures de la maison sont visibles par tous les membres (chacun en paie une part) ;
--   * une dette (invoice_shares) n'est visible que par les deux personnes concernées
--     ET par les admins de l'appartement ;
--   * toute écriture sensible passe par des fonctions serveur (001 et 002), jamais en direct.
-- ============================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- Tables ---

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  accessibility_settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.apartments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  invite_code text not null unique default upper(substr(md5(gen_random_uuid()::text), 1, 8)),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- Les clés étrangères pointent vers « profiles » (et non auth.users) : c'est ce qui permet
-- à l'application d'écrire profiles!debtor_id(...) dans ses requêtes.
create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('admin', 'manager', 'member')),
  is_active boolean not null default true,
  joined_at timestamptz not null default now(),
  unique (apartment_id, user_id)
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  title text not null,
  amount numeric(12, 2) not null check (amount > 0),
  category text not null default 'autre'
    check (category in ('loyer', 'electricite', 'eau', 'wifi', 'courses', 'gaz', 'autre')),
  due_date date,
  status text not null default 'pending'
    check (status in ('draft', 'pending', 'partially_paid', 'paid', 'disputed')),
  paid_by uuid not null references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  receipt_path text,
  period_start date,
  period_end date,
  is_recurring boolean not null default false,
  recurrence_rule text,
  created_at timestamptz not null default now()
);

create table if not exists public.invoice_shares (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  debtor_id uuid not null references public.profiles(id),
  creditor_id uuid not null references public.profiles(id),
  amount_due numeric(12, 2) not null check (amount_due >= 0),
  amount_paid numeric(12, 2) not null default 0,
  status text not null default 'pending'
    check (status in ('pending', 'awaiting_confirmation', 'confirmed', 'disputed')),
  payment_method text,
  paid_at timestamptz,
  confirmed_at timestamptz,
  dispute_reason text
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  title text not null,
  description text,
  assigned_to uuid references public.profiles(id) on delete set null,
  due_date date,
  status text not null default 'pending' check (status in ('pending', 'done', 'postponed')),
  is_recurring boolean not null default false,
  recurrence_rule text,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.equipments (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  name text not null,
  category text not null default 'autre',
  purchase_price numeric(12, 2),
  purchase_date date,
  status text not null default 'good'
    check (status in ('good', 'worn', 'to_repair', 'broken', 'disposed')),
  location text,
  photo_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.budgets (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  month date not null,
  category text not null,
  planned_amount numeric(12, 2) not null default 0 check (planned_amount >= 0),
  unique (apartment_id, month, category)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  content text not null check (length(trim(content)) > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text,
  type text check (type in ('debt', 'task', 'message', 'system')),
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists members_user_idx on public.members (user_id) where is_active;
create index if not exists members_apartment_idx on public.members (apartment_id) where is_active;
create index if not exists invoices_apartment_idx on public.invoices (apartment_id, created_at desc);
create index if not exists invoice_shares_invoice_idx on public.invoice_shares (invoice_id);
create index if not exists invoice_shares_debtor_idx on public.invoice_shares (debtor_id);
create index if not exists invoice_shares_creditor_idx on public.invoice_shares (creditor_id);
create index if not exists tasks_apartment_idx on public.tasks (apartment_id);
create index if not exists equipments_apartment_idx on public.equipments (apartment_id);
create index if not exists messages_apartment_idx on public.messages (apartment_id, created_at desc);
create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

-- Les comptes déjà créés avant cette migration n'ont pas de profil : on le crée.
insert into public.profiles (id, full_name)
select u.id, coalesce(nullif(u.raw_user_meta_data ->> 'full_name', ''), split_part(u.email, '@', 1))
from auth.users u
on conflict (id) do nothing;

-- ------------------------------------------------- Fonctions d'appartenance ---
-- SECURITY DEFINER : elles lisent « members » sans repasser par ses propres règles
-- (sinon une règle sur « members » qui appelle « members » tourne en boucle).

create or replace function public.is_apartment_member(apt uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.members
    where apartment_id = apt and user_id = auth.uid() and is_active
  );
$$;

create or replace function public.is_apartment_admin(apt uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.members
    where apartment_id = apt and user_id = auth.uid() and is_active and role = 'admin'
  );
$$;

create or replace function public.is_apartment_manager(apt uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.members
    where apartment_id = apt and user_id = auth.uid() and is_active and role in ('admin', 'manager')
  );
$$;

create or replace function public.shares_apartment_with(uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.members a
    join public.members b on b.apartment_id = a.apartment_id
    where a.user_id = auth.uid() and b.user_id = uid and a.is_active and b.is_active
  );
$$;

-- Un fichier du dossier « receipts » n'est accessible que si son premier dossier
-- (l'identifiant de l'appartement) est celui d'un appartement dont on est membre.
create or replace function public.receipt_path_allowed(p_name text)
returns boolean language sql stable security definer set search_path = public, storage as $$
  select case
    when (storage.foldername(p_name))[1] ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then public.is_apartment_member(((storage.foldername(p_name))[1])::uuid)
    else false
  end;
$$;

grant execute on function public.is_apartment_member(uuid) to authenticated;
grant execute on function public.is_apartment_admin(uuid) to authenticated;
grant execute on function public.is_apartment_manager(uuid) to authenticated;
grant execute on function public.shares_apartment_with(uuid) to authenticated;
grant execute on function public.receipt_path_allowed(text) to authenticated;

-- ------------------------------------------------------------ Règles (RLS) ---

do $$
declare
  t text;
  p record;
begin
  -- On repart d'une page blanche : toute règle existante sur ces tables est supprimée
  -- (notamment les anciennes règles ouvertes à tous), puis recréée ci-dessous.
  foreach t in array array[
    'profiles', 'apartments', 'members', 'invoices', 'invoice_shares',
    'tasks', 'equipments', 'budgets', 'messages', 'notifications'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    for p in select policyname from pg_policies where schemaname = 'public' and tablename = t loop
      execute format('drop policy %I on public.%I', p.policyname, t);
    end loop;
  end loop;
end $$;

-- profiles : on voit son profil et ceux de ses colocataires ; on ne modifie que le sien
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.shares_apartment_with(id));
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.profiles from authenticated;
grant update (full_name, avatar_url, accessibility_settings) on public.profiles to authenticated;

-- apartments / members : lecture pour les membres ; écriture uniquement par les fonctions serveur
create policy apartments_select on public.apartments for select to authenticated
  using (public.is_apartment_member(id));
create policy members_select on public.members for select to authenticated
  using (public.is_apartment_member(apartment_id));

-- invoices : visibles par tous les membres. Seul le reçu peut être modifié en direct
-- (création, modification et suppression passent par les fonctions serveur).
create policy invoices_select on public.invoices for select to authenticated
  using (public.is_apartment_member(apartment_id));
create policy invoices_update on public.invoices for update to authenticated
  using (created_by = auth.uid() or public.is_apartment_manager(apartment_id))
  with check (created_by = auth.uid() or public.is_apartment_manager(apartment_id));
revoke update on public.invoices from authenticated;
grant update (receipt_path) on public.invoices to authenticated;

-- invoice_shares (les dettes) : les deux personnes concernées + les admins. Aucune écriture directe.
create policy invoice_shares_select on public.invoice_shares for select to authenticated
  using (
    debtor_id = auth.uid()
    or creditor_id = auth.uid()
    or exists (
      select 1 from public.invoices i
      where i.id = invoice_shares.invoice_id and public.is_apartment_admin(i.apartment_id)
    )
  );
revoke insert, update, delete on public.invoice_shares from authenticated;

-- tâches et équipements : tous les membres de l'appartement
create policy tasks_all on public.tasks for all to authenticated
  using (public.is_apartment_member(apartment_id)) with check (public.is_apartment_member(apartment_id));
create policy equipments_all on public.equipments for all to authenticated
  using (public.is_apartment_member(apartment_id)) with check (public.is_apartment_member(apartment_id));

-- budgets : lecture pour tous, écriture pour les admins et gestionnaires
create policy budgets_select on public.budgets for select to authenticated
  using (public.is_apartment_member(apartment_id));
create policy budgets_write on public.budgets for all to authenticated
  using (public.is_apartment_manager(apartment_id)) with check (public.is_apartment_manager(apartment_id));

-- messages : lecture pour les membres ; on n'écrit que sous son propre nom
-- (modification et suppression passent par les fonctions edit_message / delete_message)
create policy messages_select on public.messages for select to authenticated
  using (public.is_apartment_member(apartment_id));
create policy messages_insert on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_apartment_member(apartment_id));

-- notifications : chacun les siennes ; seule la colonne « lue » est modifiable
create policy notifications_select on public.notifications for select to authenticated
  using (user_id = auth.uid());
create policy notifications_update on public.notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on public.notifications from authenticated;
grant update (is_read) on public.notifications to authenticated;

-- ---------------------------------------------- Dossier de fichiers « receipts » ---
-- Privé, 10 Mo maximum, images et PDF. Chemin attendu : <id appartement>/...

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'receipts', 'receipts', false, 10485760,
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'image/heif', 'application/pdf']
)
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists receipts_membres on storage.objects;
create policy receipts_membres on storage.objects for all to authenticated
  using (bucket_id = 'receipts' and public.receipt_path_allowed(name))
  with check (bucket_id = 'receipts' and public.receipt_path_allowed(name));

-- ------------------------------------------------------------- Contrôle ---
-- Chaque table doit apparaître avec le rôle {authenticated} uniquement.
select tablename, policyname, roles, cmd
from pg_policies
where schemaname = 'public'
  and tablename in ('profiles', 'apartments', 'members', 'invoices', 'invoice_shares',
                    'tasks', 'equipments', 'budgets', 'messages', 'notifications')
order by tablename, policyname;
