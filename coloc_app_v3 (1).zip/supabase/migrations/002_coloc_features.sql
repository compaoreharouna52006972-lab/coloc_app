-- ColocApp — migration 002 : factures modifiables, absences, ménage en rotation,
-- règlement groupé, messagerie modifiable. À exécuter APRÈS la migration 001. Idempotente.

-- 1. Colonnes
alter table public.invoices add column if not exists period_start date;
alter table public.invoices add column if not exists period_end date;
alter table public.messages add column if not exists edited_at timestamptz;

-- 2. Dates au fuseau du Maroc
create or replace function public.coloc_today() returns date language sql stable as $$
  select (now() at time zone 'Africa/Casablanca')::date;
$$;
create or replace function public.coloc_monday() returns date language sql stable as $$
  select public.coloc_today() - (extract(isodow from public.coloc_today())::int - 1);
$$;

-- 3. Absences ---------------------------------------------------------------------------
create table if not exists public.absences (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  start_date date not null,
  end_date date not null check (end_date >= start_date),
  created_at timestamptz not null default now()
);
create index if not exists absences_apartment_idx on public.absences (apartment_id, start_date);
alter table public.absences enable row level security;
drop policy if exists "absences_select" on public.absences;
create policy "absences_select" on public.absences for select to authenticated
  using (public.is_apartment_member(apartment_id));
revoke insert, update, delete on public.absences from authenticated;

create or replace function public.declare_absence(p_apartment uuid, p_start date, p_end date) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_name text; m record;
begin
  if not public.is_apartment_member(p_apartment) then raise exception 'Tu ne fais pas partie de cet appartement'; end if;
  if p_start is null or p_end is null or p_end < p_start then raise exception 'Dates invalides'; end if;
  if p_end - p_start > 366 then raise exception 'Une absence ne peut pas dépasser un an'; end if;
  insert into public.absences (apartment_id, user_id, start_date, end_date)
    values (p_apartment, auth.uid(), p_start, p_end) returning id into v_id;
  select full_name into v_name from public.profiles where id = auth.uid();
  for m in select user_id from public.members where apartment_id = p_apartment and is_active and user_id <> auth.uid() loop
    perform public.push_notification(m.user_id, 'Absence déclarée',
      format('%s sera absent(e) du %s au %s', coalesce(v_name, 'Un colocataire'), to_char(p_start, 'DD/MM'), to_char(p_end, 'DD/MM')),
      'system', '/absences');
  end loop;
  return v_id;
end $$;

create or replace function public.delete_absence(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare a public.absences%rowtype;
begin
  select * into a from public.absences where id = p_id;
  if not found then raise exception 'Absence introuvable'; end if;
  if a.user_id <> auth.uid() and not public.is_apartment_admin(a.apartment_id) then
    raise exception 'Tu ne peux supprimer que tes propres absences';
  end if;
  delete from public.absences where id = p_id;
end $$;

-- 4. Calcul des parts : égal, ou au prorata des jours de présence si une période est donnée.
--    Les centimes restants restent à celui qui a payé (il n'est pas dans le résultat).
create or replace function public.compute_shares(
  p_apartment uuid, p_amount numeric, p_payer uuid, p_debtors uuid[], p_start date, p_end date
) returns table (user_id uuid, amount numeric)
language sql stable security definer set search_path = public as $$
  with people as (
    select distinct u from unnest(array_append(coalesce(p_debtors, '{}'::uuid[]), p_payer)) as u
  ),
  w as (
    select people.u as uid,
      (case when p_start is not null and p_end is not null and p_end >= p_start then
         ((p_end - p_start) + 1) - (
           select count(*) from generate_series(p_start::timestamp, p_end::timestamp, interval '1 day') as d
           where exists (
             select 1 from public.absences a
             where a.apartment_id = p_apartment and a.user_id = people.u
               and d::date between a.start_date and a.end_date)
         )
       else 1 end)::numeric as days
    from people
  ),
  t as (select nullif(sum(days), 0) as tot, count(*)::numeric as n from w)
  select w.uid,
         floor(round(p_amount, 2) * 100 * (case when t.tot is null then 1 / t.n else w.days / t.tot end)) / 100
  from w cross join t
  where w.uid <> p_payer;
$$;
revoke all on function public.compute_shares(uuid, numeric, uuid, uuid[], date, date) from public, anon, authenticated;

-- 5. Factures : création (avec période), modification, suppression ---------------------
drop function if exists public.create_invoice_with_shares(uuid, text, numeric, text, date, uuid[]);

create or replace function public.create_invoice_with_shares(
  p_apartment uuid, p_title text, p_amount numeric, p_category text, p_due date, p_debtors uuid[],
  p_period_start date default null, p_period_end date default null
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_debtors uuid[]; v_start date; v_end date; r record;
begin
  if not public.is_apartment_member(p_apartment) then raise exception 'Tu ne fais pas partie de cet appartement'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Montant invalide'; end if;
  if char_length(trim(coalesce(p_title, ''))) = 0 then raise exception 'Titre requis'; end if;

  v_debtors := array(select distinct x from unnest(coalesce(p_debtors, '{}'::uuid[])) x where x <> auth.uid());
  if exists (
    select 1 from unnest(v_debtors) x
    where not exists (select 1 from public.members m where m.apartment_id = p_apartment and m.user_id = x and m.is_active)
  ) then raise exception 'Participant invalide'; end if;

  if p_category in ('eau', 'electricite') and p_period_start is not null and p_period_end is not null
     and p_period_end >= p_period_start then
    v_start := p_period_start; v_end := p_period_end;
  end if;

  insert into public.invoices (apartment_id, title, amount, category, due_date, paid_by, created_by, status, period_start, period_end)
    values (p_apartment, trim(p_title), round(p_amount, 2), p_category, p_due, auth.uid(), auth.uid(), 'pending', v_start, v_end)
    returning id into v_id;

  for r in select * from public.compute_shares(p_apartment, p_amount, auth.uid(), v_debtors, v_start, v_end) loop
    if r.amount > 0 then
      insert into public.invoice_shares (invoice_id, debtor_id, creditor_id, amount_due, status)
        values (v_id, r.user_id, auth.uid(), r.amount, 'pending');
    end if;
  end loop;
  return v_id;
end $$;

create or replace function public.update_invoice(
  p_invoice uuid, p_title text, p_amount numeric, p_category text, p_due date, p_debtors uuid[],
  p_period_start date default null, p_period_end date default null
) returns void
language plpgsql security definer set search_path = public as $$
declare inv public.invoices%rowtype; v_locked boolean; v_debtors uuid[]; v_start date; v_end date;
        r record; v_old numeric; v_existing uuid[];
begin
  select * into inv from public.invoices where id = p_invoice for update;
  if not found then raise exception 'Facture introuvable'; end if;
  if not (inv.created_by = auth.uid() or exists (
      select 1 from public.members where apartment_id = inv.apartment_id and user_id = auth.uid()
        and is_active and role in ('admin', 'manager'))) then
    raise exception 'Seuls l''auteur de la facture et les responsables peuvent la modifier';
  end if;
  if char_length(trim(coalesce(p_title, ''))) = 0 then raise exception 'Titre requis'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Montant invalide'; end if;

  v_debtors := array(select distinct x from unnest(coalesce(p_debtors, '{}'::uuid[])) x where x <> inv.paid_by);
  if exists (
    select 1 from unnest(v_debtors) x
    where not exists (select 1 from public.members m where m.apartment_id = inv.apartment_id and m.user_id = x and m.is_active)
  ) then raise exception 'Participant invalide'; end if;

  if p_category in ('eau', 'electricite') and p_period_start is not null and p_period_end is not null
     and p_period_end >= p_period_start then
    v_start := p_period_start; v_end := p_period_end;
  end if;

  v_locked := exists (
    select 1 from public.invoice_shares where invoice_id = p_invoice
      and (amount_paid > 0 or pending_amount > 0 or status in ('awaiting_confirmation', 'confirmed')));
  v_existing := array(select debtor_id from public.invoice_shares where invoice_id = p_invoice order by debtor_id);

  if v_locked and (
       round(p_amount, 2) <> inv.amount
    or v_existing is distinct from array(select x from unnest(v_debtors) x order by x)
    or v_start is distinct from inv.period_start
    or v_end is distinct from inv.period_end
  ) then
    raise exception 'Des paiements ont déjà été enregistrés : seuls le titre, la catégorie et l''échéance sont modifiables';
  end if;

  if not v_locked then
    for r in select * from public.compute_shares(inv.apartment_id, p_amount, inv.paid_by, v_debtors, v_start, v_end) loop
      if r.amount > 0 then
        select amount_due into v_old from public.invoice_shares where invoice_id = p_invoice and debtor_id = r.user_id;
        if found then
          update public.invoice_shares set amount_due = r.amount, status = 'pending'
            where invoice_id = p_invoice and debtor_id = r.user_id;
          if v_old <> r.amount then
            perform public.push_notification(r.user_id, 'Facture modifiée',
              format('« %s » : ta part passe à %s MAD', trim(p_title), r.amount), 'debt', '/dettes');
          end if;
        else
          insert into public.invoice_shares (invoice_id, debtor_id, creditor_id, amount_due, status)
            values (p_invoice, r.user_id, inv.paid_by, r.amount, 'pending');
        end if;
      end if;
    end loop;
    delete from public.invoice_shares s
      where s.invoice_id = p_invoice
        and not exists (
          select 1 from public.compute_shares(inv.apartment_id, p_amount, inv.paid_by, v_debtors, v_start, v_end) c
          where c.user_id = s.debtor_id and c.amount > 0);
  end if;

  update public.invoices
    set title = trim(p_title), amount = round(p_amount, 2), category = p_category, due_date = p_due,
        period_start = v_start, period_end = v_end
    where id = p_invoice;
end $$;

-- Renvoie le chemin du reçu pour que l'application supprime aussi le fichier
create or replace function public.delete_invoice(p_invoice uuid) returns text
language plpgsql security definer set search_path = public as $$
declare inv public.invoices%rowtype;
begin
  select * into inv from public.invoices where id = p_invoice for update;
  if not found then raise exception 'Facture introuvable'; end if;
  if not (inv.created_by = auth.uid() or exists (
      select 1 from public.members where apartment_id = inv.apartment_id and user_id = auth.uid()
        and is_active and role in ('admin', 'manager'))) then
    raise exception 'Seuls l''auteur de la facture et les responsables peuvent la supprimer';
  end if;
  if exists (
    select 1 from public.invoice_shares where invoice_id = p_invoice
      and (amount_paid > 0 or pending_amount > 0 or status in ('awaiting_confirmation', 'confirmed'))
  ) then
    raise exception 'Des paiements ont déjà été enregistrés : cette facture ne peut plus être supprimée';
  end if;
  delete from public.invoice_shares where invoice_id = p_invoice;
  delete from public.invoices where id = p_invoice;
  return inv.receipt_path;
end $$;

-- 6. Grand nettoyage en rotation -------------------------------------------------------
create or replace function public.cleaning_zones() returns text[] language sql immutable as $$
  select array['cuisine', 'salle_de_bain', 'toilettes', 'sol_poussiere', 'poubelles', 'salon'];
$$;

create table if not exists public.cleaning_turns (
  id uuid primary key default gen_random_uuid(),
  apartment_id uuid not null references public.apartments(id) on delete cascade,
  user_id uuid not null references auth.users(id),
  week_start date not null,
  status text not null default 'pending' check (status in ('pending', 'done')),
  catching_up boolean not null default false,
  postponed_count int not null default 0,
  zones_done text[] not null default '{}',
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
-- un seul tour en cours par appartement
create unique index if not exists cleaning_one_pending on public.cleaning_turns (apartment_id) where status = 'pending';
alter table public.cleaning_turns enable row level security;
drop policy if exists "cleaning_select" on public.cleaning_turns;
create policy "cleaning_select" on public.cleaning_turns for select to authenticated
  using (public.is_apartment_member(apartment_id));
revoke insert, update, delete on public.cleaning_turns from authenticated;

-- Personne suivante dans l'ordre d'arrivée (puis identifiant), en boucle
create or replace function public.next_cleaner(p_apartment uuid, p_after uuid) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v_next uuid;
begin
  with ordered as (
    select user_id, row_number() over (order by joined_at, user_id) as rn
    from public.members where apartment_id = p_apartment and is_active
  )
  select user_id into v_next from ordered
  where rn = coalesce((select rn from ordered where user_id = p_after), 0) + 1;
  if v_next is null then
    select user_id into v_next from public.members
      where apartment_id = p_apartment and is_active order by joined_at, user_id limit 1;
  end if;
  return v_next;
end $$;
revoke all on function public.next_cleaner(uuid, uuid) from public, anon, authenticated;

create or replace function public.ensure_cleaning_turn(p_apartment uuid) returns void
language plpgsql security definer set search_path = public as $$
declare t public.cleaning_turns%rowtype; v_user uuid; v_inserted int;
begin
  if not public.is_apartment_member(p_apartment) then raise exception 'Tu ne fais pas partie de cet appartement'; end if;
  select * into t from public.cleaning_turns where apartment_id = p_apartment and status = 'pending';
  if not found then
    select user_id into v_user from public.members
      where apartment_id = p_apartment and is_active order by joined_at, user_id limit 1;
    if v_user is not null then
      insert into public.cleaning_turns (apartment_id, user_id, week_start)
        values (p_apartment, v_user, public.coloc_monday())
        on conflict (apartment_id) where status = 'pending' do nothing;
      get diagnostics v_inserted = row_count;
      if v_inserted > 0 then
        perform public.push_notification(v_user, 'Grand nettoyage', 'C''est ton tour de ménage cette semaine', 'task', '/taches');
      end if;
    end if;
  elsif not exists (select 1 from public.members where apartment_id = p_apartment and user_id = t.user_id and is_active) then
    -- la personne de tour a quitté l'appartement : le tour passe à la suivante
    v_user := public.next_cleaner(p_apartment, t.user_id);
    if v_user is not null then
      update public.cleaning_turns set user_id = v_user where id = t.id;
      perform public.push_notification(v_user, 'Grand nettoyage', 'C''est ton tour de ménage', 'task', '/taches');
    end if;
  end if;
end $$;

create or replace function public.toggle_cleaning_zone(p_turn uuid, p_zone text) returns void
language plpgsql security definer set search_path = public as $$
declare t public.cleaning_turns%rowtype;
begin
  select * into t from public.cleaning_turns where id = p_turn for update;
  if not found then raise exception 'Tour introuvable'; end if;
  if t.user_id <> auth.uid() then raise exception 'Ce n''est pas ton tour de ménage'; end if;
  if t.status <> 'pending' then raise exception 'Ce tour est déjà terminé'; end if;
  if not (p_zone = any (public.cleaning_zones())) then raise exception 'Zone inconnue'; end if;
  update public.cleaning_turns
    set zones_done = case when p_zone = any (zones_done) then array_remove(zones_done, p_zone) else array_append(zones_done, p_zone) end
    where id = p_turn;
end $$;

create or replace function public.complete_cleaning(p_turn uuid) returns void
language plpgsql security definer set search_path = public as $$
declare t public.cleaning_turns%rowtype; v_next uuid; v_start date; v_name text;
begin
  select * into t from public.cleaning_turns where id = p_turn for update;
  if not found then raise exception 'Tour introuvable'; end if;
  if t.user_id <> auth.uid() then raise exception 'Ce n''est pas ton tour de ménage'; end if;
  if t.status <> 'pending' then raise exception 'Ce tour est déjà terminé'; end if;
  if not (t.zones_done @> public.cleaning_zones()) then raise exception 'Coche toutes les zones avant de valider'; end if;

  update public.cleaning_turns set status = 'done', completed_at = now(), catching_up = false where id = p_turn;

  -- La rotation n'avance qu'à la validation : fait à l'heure → semaine suivante, en retard → cette semaine
  v_next := public.next_cleaner(t.apartment_id, t.user_id);
  v_start := case when t.week_start >= public.coloc_monday() then t.week_start + 7 else public.coloc_monday() end;
  if v_next is not null then
    insert into public.cleaning_turns (apartment_id, user_id, week_start) values (t.apartment_id, v_next, v_start);
    select full_name into v_name from public.profiles where id = auth.uid();
    perform public.push_notification(v_next, 'Grand nettoyage',
      format('%s a terminé son ménage : c''est ton tour', coalesce(v_name, 'Un colocataire')), 'task', '/taches');
  end if;
end $$;

create or replace function public.postpone_cleaning(p_turn uuid) returns void
language plpgsql security definer set search_path = public as $$
declare t public.cleaning_turns%rowtype; m record; v_name text;
begin
  select * into t from public.cleaning_turns where id = p_turn for update;
  if not found then raise exception 'Tour introuvable'; end if;
  if t.user_id <> auth.uid() then raise exception 'Ce n''est pas ton tour de ménage'; end if;
  if t.status <> 'pending' then raise exception 'Ce tour est déjà terminé'; end if;
  update public.cleaning_turns set catching_up = true, postponed_count = postponed_count + 1 where id = p_turn;
  select full_name into v_name from public.profiles where id = auth.uid();
  for m in select user_id from public.members where apartment_id = t.apartment_id and is_active and user_id <> auth.uid() loop
    perform public.push_notification(m.user_id, 'Ménage reporté',
      format('%s rattrape son ménage plus tard : la rotation est en pause', coalesce(v_name, 'Un colocataire')), 'task', '/taches');
  end loop;
end $$;

-- 7. Règlement groupé : toutes les dettes envers une même personne ----------------------
create or replace function public.declare_payment_bulk(p_creditor uuid, p_method text) returns numeric
language plpgsql security definer set search_path = public as $$
declare s record; v_total numeric := 0; v_count int := 0; v_name text;
begin
  for s in
    select * from public.invoice_shares
    where debtor_id = auth.uid() and creditor_id = p_creditor
      and status in ('pending', 'disputed') and amount_due - amount_paid > 0.005
    for update
  loop
    update public.invoice_shares
      set pending_amount = round(s.amount_due - s.amount_paid, 2), payment_method = p_method,
          paid_at = now(), status = 'awaiting_confirmation', dispute_reason = null
      where id = s.id;
    v_total := v_total + round(s.amount_due - s.amount_paid, 2);
    v_count := v_count + 1;
  end loop;
  if v_count = 0 then raise exception 'Aucune dette à régler avec cette personne'; end if;
  select full_name into v_name from public.profiles where id = auth.uid();
  perform public.push_notification(p_creditor, 'Paiement à confirmer',
    format('%s déclare t''avoir réglé %s MAD (%s dettes)', coalesce(v_name, 'Un colocataire'), v_total, v_count), 'debt', '/dettes');
  return v_total;
end $$;

create or replace function public.confirm_payments_bulk(p_debtor uuid) returns int
language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  update public.invoice_shares
    set amount_paid = amount_paid + pending_amount,
        pending_amount = 0,
        status = case when amount_paid + pending_amount >= amount_due - 0.005 then 'confirmed' else 'pending' end,
        confirmed_at = case when amount_paid + pending_amount >= amount_due - 0.005 then now() else confirmed_at end
    where creditor_id = auth.uid() and debtor_id = p_debtor and status = 'awaiting_confirmation';
  get diagnostics v_n = row_count;
  if v_n = 0 then raise exception 'Aucun paiement en attente de cette personne'; end if;
  perform public.push_notification(p_debtor, 'Paiements confirmés',
    format('%s de tes paiements ont été confirmés', v_n), 'debt', '/dettes');
  return v_n;
end $$;

-- 8. Messagerie : modifier / supprimer ses messages -----------------------------------
create or replace function public.edit_message(p_message uuid, p_content text) returns void
language plpgsql security definer set search_path = public as $$
declare m public.messages%rowtype;
begin
  select * into m from public.messages where id = p_message;
  if not found then raise exception 'Message introuvable'; end if;
  if m.sender_id <> auth.uid() then raise exception 'Tu ne peux modifier que tes propres messages'; end if;
  if char_length(trim(coalesce(p_content, ''))) = 0 then raise exception 'Le message ne peut pas être vide'; end if;
  update public.messages set content = trim(p_content), edited_at = now() where id = p_message;
end $$;

create or replace function public.delete_message(p_message uuid) returns void
language plpgsql security definer set search_path = public as $$
declare m public.messages%rowtype;
begin
  select * into m from public.messages where id = p_message;
  if not found then raise exception 'Message introuvable'; end if;
  if m.sender_id <> auth.uid() and not public.is_apartment_admin(m.apartment_id) then
    raise exception 'Tu ne peux supprimer que tes propres messages';
  end if;
  delete from public.messages where id = p_message;
end $$;

-- 9. Droits d'exécution
do $$
declare f text;
begin
  foreach f in array array[
    'declare_absence(uuid,date,date)', 'delete_absence(uuid)',
    'create_invoice_with_shares(uuid,text,numeric,text,date,uuid[],date,date)',
    'update_invoice(uuid,text,numeric,text,date,uuid[],date,date)', 'delete_invoice(uuid)',
    'ensure_cleaning_turn(uuid)', 'toggle_cleaning_zone(uuid,text)', 'complete_cleaning(uuid)', 'postpone_cleaning(uuid)',
    'declare_payment_bulk(uuid,text)', 'confirm_payments_bulk(uuid)',
    'edit_message(uuid,text)', 'delete_message(uuid)'
  ] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;

-- 10. Temps réel (la suppression d'un message se propage à tous)
do $$
begin
  begin
    alter publication supabase_realtime add table public.cleaning_turns;
  exception when duplicate_object or undefined_object then null;
  end;
end $$;
