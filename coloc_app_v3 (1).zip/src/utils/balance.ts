import type { InvoiceShare, Invoice } from '@/types'
import { todayMA } from './format'

export type ShareWithInvoice = InvoiceShare & {
  invoice: Pick<Invoice, 'id' | 'title' | 'due_date' | 'category' | 'amount' | 'created_at'>
}

export function computeRemaining(share: InvoiceShare): number {
  return Math.max(0, share.amount_due - share.amount_paid)
}

export function isLate(share: InvoiceShare, dueDate: string | null): boolean {
  if (!dueDate) return false
  if (share.status === 'confirmed') return false
  // Comparaison de dates AAAA-MM-JJ : en retard seulement APRÈS le jour d'échéance
  return dueDate.slice(0, 10) < todayMA()
}

export function totalPending(shares: ShareWithInvoice[]): number {
  return shares
    .filter((s) => s.status !== 'confirmed')
    .reduce((sum, s) => sum + computeRemaining(s), 0)
}

export function totalLate(shares: ShareWithInvoice[]): number {
  return shares
    .filter(
      (s) => s.status !== 'confirmed' && isLate(s, s.invoice.due_date)
    )
    .reduce((sum, s) => sum + computeRemaining(s), 0)
}

export function totalConfirmedThisMonth(shares: ShareWithInvoice[]): number {
  const now = new Date()
  const start = new Date(now.getFullYear(), now.getMonth(), 1)
  return shares
    .filter(
      (s) =>
        s.status === 'confirmed' &&
        s.confirmed_at &&
        new Date(s.confirmed_at) >= start
    )
    .reduce((sum, s) => sum + s.amount_paid, 0)
}

type ShareLike = InvoiceShare & {
  debtor?: { id: string; full_name: string } | null
  creditor?: { id: string; full_name: string } | null
}

export type NetBalance = { id: string; name: string; amount: number } // > 0 : on lui doit
export type Transfer = { from: string; to: string; amount: number }

export function netBalances(shares: ShareLike[]): NetBalance[] {
  const map = new Map<string, NetBalance>()
  const add = (id: string, name: string, delta: number) => {
    const cur = map.get(id) ?? { id, name, amount: 0 }
    cur.amount += delta
    map.set(id, cur)
  }
  for (const s of shares) {
    if (s.status === 'confirmed') continue
    const r = computeRemaining(s)
    if (r <= 0) continue
    add(s.debtor_id, s.debtor?.full_name ?? 'Inconnu', -r)
    add(s.creditor_id, s.creditor?.full_name ?? 'Inconnu', r)
  }
  return [...map.values()]
}

// Le moins de virements possible pour tout solder (calcul en centimes pour éviter les erreurs d'arrondi)
export function settleUp(balances: NetBalance[]): Transfer[] {
  const cents = (n: number) => Math.round(n * 100)
  const debtors = balances.filter((b) => cents(b.amount) < 0).map((b) => ({ name: b.name, c: -cents(b.amount) })).sort((a, b) => b.c - a.c)
  const creditors = balances.filter((b) => cents(b.amount) > 0).map((b) => ({ name: b.name, c: cents(b.amount) })).sort((a, b) => b.c - a.c)
  const out: Transfer[] = []
  let i = 0
  let j = 0
  while (i < debtors.length && j < creditors.length) {
    const x = Math.min(debtors[i].c, creditors[j].c)
    out.push({ from: debtors[i].name, to: creditors[j].name, amount: x / 100 })
    debtors[i].c -= x
    creditors[j].c -= x
    if (debtors[i].c === 0) i++
    if (creditors[j].c === 0) j++
  }
  return out
}
