import type { Absence } from '@/types'

export type ShareInfo = { amount: number; present: number; total: number }

function eachDay(start: string, end: string): string[] {
  const out: string[] = []
  const e = new Date(`${end}T00:00:00Z`).getTime()
  for (let t = new Date(`${start}T00:00:00Z`).getTime(); t <= e && out.length < 400; t += 86400000) {
    out.push(new Date(t).toISOString().slice(0, 10))
  }
  return out
}

/**
 * Aperçu des parts (même règle que le serveur) : égal, ou au prorata des jours de présence
 * si une période est fournie. Le payeur absorbe les centimes restants.
 */
export function computeShares(
  amount: number,
  payerId: string,
  debtorIds: string[],
  absences: Absence[],
  start?: string | null,
  end?: string | null
): Map<string, ShareInfo> {
  const people = [...new Set([...debtorIds.filter((d) => d !== payerId), payerId])]
  const usePeriod = !!start && !!end && end >= start
  const days = usePeriod ? eachDay(start as string, end as string) : []

  const info = people.map((id) => {
    const absent = usePeriod
      ? days.filter((d) => absences.some((a) => a.user_id === id && a.start_date <= d && d <= a.end_date)).length
      : 0
    return { id, present: usePeriod ? days.length - absent : 1, total: usePeriod ? days.length : 1 }
  })

  const sum = info.reduce((s, i) => s + i.present, 0)
  const cents = Math.round(amount * 100)
  const out = new Map<string, ShareInfo>()
  for (const i of info) {
    if (i.id === payerId) continue
    const weight = sum > 0 ? i.present / sum : 1 / info.length
    out.set(i.id, { amount: Math.floor(cents * weight + 1e-9) / 100, present: i.present, total: i.total })
  }
  return out
}

export function previousMonthRange(): { start: string; end: string } {
  const now = new Date()
  const first = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const last = new Date(now.getFullYear(), now.getMonth(), 0)
  const fmt = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
  return { start: fmt(first), end: fmt(last) }
}
