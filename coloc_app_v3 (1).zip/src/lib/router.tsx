'use client'

// Petite couche de compatibilité : la v2 utilisait React Router, ici on utilise le routeur de Next.js.
// Elle garde la même API (to, navigate(-1), NavLink...) pour ne pas réécrire chaque page.
import NextLink from 'next/link'
import { useParams as useNextParams, usePathname, useRouter } from 'next/navigation'
import { useCallback, useEffect, type ComponentProps, type CSSProperties, type ReactNode } from 'react'

type LinkProps = Omit<ComponentProps<typeof NextLink>, 'href'> & { to: string }

export function Link({ to, ...rest }: LinkProps) {
  return <NextLink href={to} {...rest} />
}

export function useNavigate() {
  const router = useRouter()
  return useCallback(
    (to: string | number, options?: { replace?: boolean }) => {
      if (typeof to === 'number') {
        router.back()
        return
      }
      if (options?.replace) router.replace(to)
      else router.push(to)
    },
    [router]
  )
}

export function useParams<T extends Record<string, string>>(): Partial<T> {
  return useNextParams() as unknown as Partial<T>
}

export function Navigate({ to, replace }: { to: string; replace?: boolean }) {
  const router = useRouter()
  useEffect(() => {
    if (replace) router.replace(to)
    else router.push(to)
  }, [router, to, replace])
  return null
}

type NavLinkProps = Omit<LinkProps, 'style' | 'children'> & {
  end?: boolean
  style?: CSSProperties | ((state: { isActive: boolean }) => CSSProperties)
  children?: ReactNode
}

export function NavLink({ to, end, style, children, ...rest }: NavLinkProps) {
  const pathname = usePathname()
  const isActive = end ? pathname === to : pathname === to || pathname.startsWith(`${to}/`)
  return (
    <NextLink
      href={to}
      aria-current={isActive ? 'page' : undefined}
      style={typeof style === 'function' ? style({ isActive }) : style}
      {...rest}
    >
      {children}
    </NextLink>
  )
}
