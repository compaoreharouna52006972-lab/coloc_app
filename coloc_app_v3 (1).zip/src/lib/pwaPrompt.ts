export type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

let deferred: BeforeInstallPromptEvent | null = null
const listeners = new Set<(e: BeforeInstallPromptEvent | null) => void>()

// L'événement est émis une seule fois, peu après le chargement : on l'écoute
// donc ici (importé par RegisterSW) et pas seulement quand la page Profil s'ouvre.
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferred = e as BeforeInstallPromptEvent
    listeners.forEach((l) => l(deferred))
  })
}

export function getDeferredPrompt() {
  return deferred
}

export function clearDeferredPrompt() {
  deferred = null
  listeners.forEach((l) => l(null))
}

export function subscribePrompt(cb: (e: BeforeInstallPromptEvent | null) => void) {
  listeners.add(cb)
  return () => {
    listeners.delete(cb)
  }
}
