import webpush from 'web-push'
import { createClient, type SupabaseClient } from '@supabase/supabase-js'
import { createHash, timingSafeEqual } from 'node:crypto'

// Code exécuté uniquement sur le serveur (routes /api). Il utilise la clé « service_role » :
// elle contourne les règles d'accès, ce qui est voulu ici (aucune session utilisateur),
// et ne doit JAMAIS être préfixée par NEXT_PUBLIC_.

export type NoteRow = { id: string; user_id: string; title: string; body: string | null; link: string | null }

// Comparaison à temps constant (évite de deviner un secret caractère par caractère)
export function safeEqual(a: string, b: string): boolean {
  const ha = createHash('sha256').update(a).digest()
  const hb = createHash('sha256').update(b).digest()
  return timingSafeEqual(ha, hb)
}

export function setup(): { admin: SupabaseClient } | { error: string } {
  const required = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'SUPABASE_SERVICE_ROLE_KEY',
    'NEXT_PUBLIC_VAPID_PUBLIC_KEY',
    'VAPID_PRIVATE_KEY',
    'VAPID_EMAIL',
  ]
  const missing = required.filter((k) => !process.env[k])
  if (missing.length) return { error: `Variables manquantes : ${missing.join(', ')}` }

  const email = process.env.VAPID_EMAIL as string
  // web-push exige un sujet au format mailto: ou https:
  const subject = /^(mailto:|https?:)/.test(email) ? email : `mailto:${email}`
  webpush.setVapidDetails(
    subject,
    process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY as string,
    process.env.VAPID_PRIVATE_KEY as string
  )

  const admin = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL as string,
    process.env.SUPABASE_SERVICE_ROLE_KEY as string,
    { auth: { persistSession: false } }
  )
  return { admin }
}

// Envoie une notification à tous les appareils d'une personne, puis la marque comme envoyée.
export async function pushNote(
  admin: SupabaseClient,
  note: NoteRow
): Promise<{ sent: number; failed: number; removed: number }> {
  const { data: subs, error } = await admin
    .from('push_subscriptions')
    .select('endpoint, p256dh, auth')
    .eq('user_id', note.user_id)
  if (error) throw error

  const payload = JSON.stringify({ title: note.title, body: note.body ?? '', url: note.link ?? '/' })
  let sent = 0
  let failed = 0
  let removed = 0

  for (const s of subs ?? []) {
    try {
      // TTL 1 h : un rappel reçu des heures plus tard ne sert plus à rien
      await webpush.sendNotification(
        { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
        payload,
        { TTL: 3600 }
      )
      sent++
    } catch (err) {
      const code = (err as { statusCode?: number }).statusCode
      if (code === 404 || code === 410) {
        // Abonnement expiré (app désinstallée, permission retirée) : on le supprime
        await admin.from('push_subscriptions').delete().eq('endpoint', s.endpoint)
        removed++
      } else {
        failed++
        console.error('Échec envoi push :', code ?? err)
      }
    }
  }

  await admin.from('notifications').update({ pushed_at: new Date().toISOString() }).eq('id', note.id)
  return { sent, failed, removed }
}
