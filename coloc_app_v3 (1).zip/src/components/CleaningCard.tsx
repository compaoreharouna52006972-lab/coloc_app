'use client'

import { Check, CheckCircle2, Sparkles } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from '@/contexts/ToastContext'
import { useCleaning, CLEANING_ZONES } from '@/hooks/useCleaning'
import { useMembers } from '@/hooks/useMembers'
import { errorMessage } from '@/utils/errors'

function firstName(name: string | undefined | null) {
  return (name ?? 'Colocataire').split(' ')[0]
}

export default function CleaningCard() {
  const { user } = useAuth()
  const { toast } = useToast()
  const { turn, history, loading, toggleZone, complete, postpone } = useCleaning()
  const { members } = useMembers()

  const nameOf = (id: string) => firstName(members.find((m) => m.user_id === id)?.profile?.full_name)

  async function run(action: () => Promise<void>, ok?: string) {
    try {
      await action()
      if (ok) toast(ok, 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  if (loading) {
    return (
      <div className="card" style={{ marginBottom: 14, textAlign: 'center', color: 'var(--text-muted)' }}>
        Chargement du grand nettoyage…
      </div>
    )
  }

  if (!turn) {
    return (
      <div className="card" style={{ marginBottom: 14, color: 'var(--text-muted)', fontSize: 13 }}>
        <Sparkles size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Grand nettoyage : aucun colocataire actif pour l'instant.
      </div>
    )
  }

  const mine = turn.user_id === user?.id
  const doneCount = turn.zones_done.length
  const allDone = doneCount === CLEANING_ZONES.length

  // Personne suivante dans l'ordre d'arrivée
  const idx = members.findIndex((m) => m.user_id === turn.user_id)
  const next = members.length > 1 ? members[(idx + 1) % members.length] : null

  return (
    <div
      className="card"
      style={{ marginBottom: 14, borderLeft: turn.catching_up ? '4px solid var(--danger)' : '4px solid var(--primary)' }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <h2 style={{ fontSize: 14, fontWeight: 700 }}>Grand nettoyage</h2>
        <span style={{ background: 'var(--primary-bg)', color: 'var(--primary)', padding: '2px 8px', borderRadius: 99, fontSize: 10.5, fontWeight: 700 }}>
          Chaque semaine
        </span>
      </div>

      <div style={{ fontSize: 13, marginBottom: 10 }}>
        {mine ? (
          <strong>C'est ton tour</strong>
        ) : (
          <>
            Tour de <strong>{nameOf(turn.user_id)}</strong>
          </>
        )}
        {turn.catching_up && (
          <span style={{ marginLeft: 8, background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 700 }}>
            ⏭️ À rattraper
          </span>
        )}
      </div>

      {CLEANING_ZONES.map((z) => {
        const checked = turn.zones_done.includes(z.key)
        return (
          <button
            key={z.key}
            type="button"
            disabled={!mine}
            onClick={() => run(() => toggleZone(z.key))}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              width: '100%',
              padding: '8px 0',
              border: 'none',
              borderBottom: '1px dashed var(--border)',
              background: 'transparent',
              cursor: mine ? 'pointer' : 'default',
              fontSize: 12.5,
              textAlign: 'left',
              fontFamily: 'inherit',
            }}
          >
            <span
              style={{
                width: 18,
                height: 18,
                borderRadius: 5,
                border: checked ? '2px solid var(--success)' : '2px solid var(--border)',
                background: checked ? 'var(--success)' : '#fff',
                color: '#fff',
                display: 'grid',
                placeItems: 'center',
                fontSize: 11,
                fontWeight: 700,
                flexShrink: 0,
              }}
            >
              {checked ? <Check size={12} strokeWidth={3} /> : null}
            </span>
            <span style={{ flex: 1, textDecoration: checked ? 'line-through' : 'none', color: checked ? 'var(--text-muted)' : 'var(--text)' }}>
              {z.label}
            </span>
          </button>
        )
      })}

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10, fontSize: 11, color: 'var(--text-muted)', fontWeight: 600 }}>
        <div style={{ flex: 1, height: 7, background: 'var(--track)', borderRadius: 99, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${(doneCount / CLEANING_ZONES.length) * 100}%`, background: 'linear-gradient(90deg, var(--primary), var(--primary-light))', borderRadius: 99 }} />
        </div>
        <span>{doneCount}/{CLEANING_ZONES.length}</span>
      </div>

      {mine && (
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button
            className="btn btn-secondary"
            style={{ flex: 1, padding: '10px', fontSize: 12.5 }}
            onClick={() => {
              if (confirm('Reporter ton ménage ? La rotation reste en pause pour tout le monde jusqu\'à ce que tu le valides.')) {
                run(postpone, 'Ménage reporté, tes colocataires sont prévenus')
              }
            }}
          >
            ⏭️ Reporter
          </button>
          <button
            className="btn btn-success"
            style={{ flex: 1, padding: '10px', fontSize: 12.5 }}
            disabled={!allDone}
            onClick={() => run(complete, 'Bravo ! Le tour passe à la personne suivante')}
          >
            <Check size={14} /> Fait
          </button>
        </div>
      )}
      {mine && !allDone && (
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 8 }}>
          Coche toutes les zones pour pouvoir valider.
        </p>
      )}

      {next && (
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 10 }}>
          Ensuite : <strong>{firstName(next.profile?.full_name)}</strong>
          {turn.postponed_count > 0 && ` · reporté ${turn.postponed_count} fois`}
        </p>
      )}

      {history.length > 0 && (
        <div style={{ marginTop: 10, paddingTop: 8, borderTop: '1px dashed var(--border)' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 4 }}>Derniers tours</div>
          {history.map((h) => (
            <div key={h.id} style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>
              <CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />{nameOf(h.user_id)} · {h.completed_at ? new Date(h.completed_at).toLocaleDateString('fr-FR') : ''}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
