'use client'

import { type ReactNode } from 'react'
import TopBar from '@/components/TopBar'
import BottomBar from '@/components/BottomBar'
import OfflineBanner from '@/components/OfflineBanner'

// `hero` : contenu affiché dans l'en-tête sombre (utilisé par l'accueil pour ses chiffres clés).
export default function Layout({ children, hero }: { children: ReactNode; hero?: ReactNode }) {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', paddingBottom: 88 }}>
      <OfflineBanner />
      <TopBar>{hero}</TopBar>

      <main style={{ flex: 1, padding: '18px 16px', maxWidth: 600, margin: '0 auto', width: '100%' }}>
        {children}
      </main>

      <BottomBar />
    </div>
  )
}
