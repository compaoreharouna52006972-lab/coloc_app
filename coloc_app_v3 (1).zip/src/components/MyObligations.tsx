'use client'

import { CheckCircle2, Sparkles, StickyNote, Wallet, type LucideIcon } from 'lucide-react'
import { useMemo } from 'react'
import { Link } from '@/lib/router'
import { useAuth } from '@/contexts/AuthContext'
import { useCleaning, CLEANING_ZONES } from '@/hooks/useCleaning'
import { useTasks } from '@/hooks/useTasks'
import type { DebtWithPeople } from '@/hooks/useDebts'
import { computeRemaining, isLate } from '@/utils/balance'
import { formatDate, formatMoney, todayMA } from '@/utils/format'

type Tone = 'danger' | 'warning' | 'info'
type Item = { key: string; icon: LucideIcon; title: string; sub?: string; to: string; tone: Tone }

const TONE: Record<Tone, string> = {
  danger: 'var(--danger)',
  warning: 'var(--warning)',
  info: 'var(--primary)',
}

export default function MyObligations({ debts }: { debts: DebtWithPeople[] }) {
  const { user } = useAuth()
  const { turn } = useCleaning()
  const { tasks } = useTasks()

  const items = useMemo<Item[]>(() => {
    if (!user) return []
    const out: Item[] = []

    // 1. Grand nettoyage en rotation
    if (turn && turn.user_id === user.id) {
      out.push({
        key: 'cleaning',
        icon: Sparkles,
        title: 'Grand nettoyage',
        sub: `${turn.zones_done.length}/${CLEANING_ZONES.length} zones${turn.catching_up ? ' · à rattraper' : ''}`,
        to: '/taches',
        tone: turn.catching_up ? 'danger' : 'warning',
      })
    }

    // 2. Tâches qui me sont assignées
    for (const t of tasks) {
      if (t.assigned_to !== user.id || (t.status !== 'pending' && t.status !== 'postponed')) continue
      const late = !!t.due_date && t.due_date.slice(0, 10) < todayMA()
      out.push({
        key: `task-${t.id}`,
        icon: StickyNote,
        title: t.title,
        sub: t.status === 'postponed' ? 'Reportée' : t.due_date ? `Pour le ${formatDate(t.due_date)}` : undefined,
        to: '/taches',
        tone: late ? 'danger' : 'warning',
      })
    }

    // 3. Dettes à régler (regroupées par personne)
    const toPay = debts.filter(
      (d) => d.debtor_id === user.id && (d.status === 'pending' || d.status === 'disputed') && computeRemaining(d) > 0
    )
    const byCreditor = new Map<string, DebtWithPeople[]>()
    for (const d of toPay) byCreditor.set(d.creditor_id, [...(byCreditor.get(d.creditor_id) ?? []), d])
    for (const [creditorId, list] of byCreditor) {
      const total = list.reduce((s, d) => s + computeRemaining(d), 0)
      const name = (list[0].creditor?.full_name ?? 'un colocataire').split(' ')[0]
      out.push({
        key: `pay-${creditorId}`,
        icon: Wallet,
        title: `Régler ${formatMoney(total)} à ${name}`,
        sub: list.length > 1 ? `${list.length} dettes, tout payer d'un coup` : list[0].invoice.title,
        to: list.length > 1 ? `/dettes/regler/${creditorId}` : `/dettes/${list[0].id}/payer`,
        tone: list.some((d) => isLate(d, d.invoice.due_date)) ? 'danger' : 'warning',
      })
    }

    // 4. Paiements à confirmer
    const toConfirm = debts.filter((d) => d.creditor_id === user.id && d.status === 'awaiting_confirmation')
    const byDebtor = new Map<string, DebtWithPeople[]>()
    for (const d of toConfirm) byDebtor.set(d.debtor_id, [...(byDebtor.get(d.debtor_id) ?? []), d])
    for (const [debtorId, list] of byDebtor) {
      const total = list.reduce((s, d) => s + (d.pending_amount > 0 ? d.pending_amount : d.amount_paid), 0)
      const name = (list[0].debtor?.full_name ?? 'Un colocataire').split(' ')[0]
      out.push({
        key: `confirm-${debtorId}`,
        icon: CheckCircle2,
        title: `Confirmer le paiement de ${name}`,
        sub: `${formatMoney(total)} déclaré${list.length > 1 ? ` (${list.length} dettes)` : ''}`,
        to: list.length > 1 ? '/dettes' : `/dettes/${list[0].id}/confirmer`,
        tone: 'info',
      })
    }

    return out
  }, [user, turn, tasks, debts])

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <h2 style={{ fontSize: 15, fontWeight: 800, marginBottom: 10 }}>Mes obligations {items.length > 0 && <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>({items.length})</span>}
      </h2>

      {items.length === 0 ? (
        <div style={{ fontSize: 13, color: 'var(--success-text)', fontWeight: 600 }}><CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Rien à faire pour toi aujourd'hui</div>
      ) : (
        items.map((it) => (
          <Link
            key={it.key}
            to={it.to}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: '10px 10px',
              marginBottom: 6,
              borderRadius: 10,
              borderLeft: `4px solid ${TONE[it.tone]}`,
              background: 'var(--surface-2)',
              textDecoration: 'none',
              color: 'var(--text)',
            }}
          >
            <it.icon size={18} color={TONE[it.tone]} />
            <span style={{ flex: 1, minWidth: 0 }}>
              <span style={{ display: 'block', fontSize: 13, fontWeight: 700 }}>{it.title}</span>
              {it.sub && <span style={{ display: 'block', fontSize: 11.5, color: 'var(--text-muted)' }}>{it.sub}</span>}
            </span>
            <span style={{ color: 'var(--text-muted)' }}>›</span>
          </Link>
        ))
      )}
    </div>
  )
}
