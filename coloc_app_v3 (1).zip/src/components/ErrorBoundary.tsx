'use client'

import { AlertTriangle } from 'lucide-react'
import { Component, type ErrorInfo, type ReactNode } from 'react'

type Props = { children: ReactNode }
type State = { error: Error | null }

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null }

  static getDerivedStateFromError(error: Error): State {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Erreur interface:', error, info)
  }

  render() {
    if (!this.state.error) return this.props.children
    return (
      <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24 }}>
        <div className="card" style={{ maxWidth: 420, textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center' }}><AlertTriangle size={40} color="var(--warning)" /></div>
          <h1 style={{ fontSize: 18, fontWeight: 800, marginTop: 8 }}>Une erreur est survenue</h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', margin: '8px 0 16px' }}>
            L'application a rencontré un problème inattendu. Tes données ne sont pas perdues.
          </p>
          <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => window.location.assign('/')}>
            Recharger l'application
          </button>
        </div>
      </div>
    )
  }
}
