'use client'

import { Home, Wallet, Receipt, Sparkles, LayoutGrid } from 'lucide-react'
import { usePathname } from 'next/navigation'
import { Link } from '@/lib/router'

// 5 onglets, comme Appart 4B. Tout le reste est regroupé dans « Plus ».
const MORE_ROUTES = ['/plus', '/chat', '/inventaire', '/budget', '/absences', '/membres', '/profil', '/notifications']

const ITEMS = [
  { to: '/', label: 'Accueil', icon: Home, match: (p: string) => p === '/' },
  { to: '/dettes', label: 'Dettes', icon: Wallet, match: (p: string) => p.startsWith('/dettes') },
  { to: '/factures', label: 'Factures', icon: Receipt, match: (p: string) => p.startsWith('/factures') },
  { to: '/taches', label: 'Tâches', icon: Sparkles, match: (p: string) => p.startsWith('/taches') },
  { to: '/plus', label: 'Plus', icon: LayoutGrid, match: (p: string) => MORE_ROUTES.some((r) => p === r || p.startsWith(`${r}/`)) },
]

export default function BottomBar() {
  const pathname = usePathname()
  return (
    <nav
      aria-label="Navigation principale"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#fff',
        borderTop: '1px solid #EEF1EF',
        display: 'flex',
        padding: '9px 4px calc(13px + var(--safe-bottom))',
        zIndex: 50,
        boxShadow: '0 -2px 12px rgba(24, 37, 33, 0.05)',
      }}
    >
      {ITEMS.map((item) => {
        const active = item.match(pathname)
        const Icon = item.icon
        return (
          <Link
            key={item.to}
            to={item.to}
            aria-current={active ? 'page' : undefined}
            style={{
              flex: 1,
              textDecoration: 'none',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 3,
              color: active ? 'var(--primary)' : '#9AA6A0',
            }}
          >
            <Icon size={20} strokeWidth={active ? 2.4 : 2} />
            <span style={{ fontSize: 10.5, fontWeight: active ? 700 : 500 }}>{item.label}</span>
          </Link>
        )
      })}
    </nav>
  )
}
