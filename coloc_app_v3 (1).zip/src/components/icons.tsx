'use client'

import {
  Home,
  Zap,
  Droplet,
  Wifi,
  ShoppingCart,
  Flame,
  Package,
  Plug,
  UtensilsCrossed,
  type LucideIcon,
} from 'lucide-react'

// Une seule table pour les icônes de catégories (factures, budget) : plus d'emojis dans les écrans.
export const CATEGORY_ICON: Record<string, LucideIcon> = {
  loyer: Home,
  electricite: Zap,
  eau: Droplet,
  wifi: Wifi,
  courses: ShoppingCart,
  gaz: Flame,
  autre: Package,
}

export const EQUIPMENT_CATEGORY_ICON: Record<string, LucideIcon> = {
  electromenager: Plug,
  mobilier: Home,
  vaisselle: UtensilsCrossed,
  autre: Package,
}

export function CategoryIcon({ category, size = 18, color }: { category?: string | null; size?: number; color?: string }) {
  const Icon = CATEGORY_ICON[category ?? ''] ?? Package
  return <Icon size={size} color={color ?? 'var(--primary)'} strokeWidth={2.1} />
}

export function EquipmentIcon({ category, size = 20 }: { category?: string | null; size?: number }) {
  const Icon = EQUIPMENT_CATEGORY_ICON[category ?? ''] ?? Package
  return <Icon size={size} color="var(--primary)" strokeWidth={2.1} />
}

// Pastille de couleur (remplace les ronds )
export function StatusDot({ color }: { color: string }) {
  return <span className="dot" style={{ background: color }} aria-hidden="true" />
}
