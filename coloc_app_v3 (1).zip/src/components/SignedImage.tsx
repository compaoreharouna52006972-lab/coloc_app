'use client'

import { useEffect, useState, type ReactNode } from 'react'
import { supabase } from '@/lib/supabase'

export default function SignedImage({
  path,
  alt,
  fallback,
}: {
  path: string
  alt: string
  fallback?: ReactNode
}) {
  const [url, setUrl] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    supabase.storage
      .from('receipts')
      .createSignedUrl(path, 3600)
      .then(({ data }) => {
        if (active) setUrl(data?.signedUrl ?? null)
      })
    return () => {
      active = false
    }
  }, [path])

  if (!url) return <>{fallback ?? null}</>
  return <img src={url} alt={alt} loading="lazy" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
}
