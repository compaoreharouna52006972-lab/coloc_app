'use client'

import { WifiOff } from 'lucide-react'
import { useEffect, useState } from 'react'

export default function OfflineBanner() {
  const [online, setOnline] = useState(true)

  useEffect(() => {
    setOnline(navigator.onLine)
    const on = () => setOnline(true)
    const off = () => setOnline(false)
    window.addEventListener('online', on)
    window.addEventListener('offline', off)
    return () => {
      window.removeEventListener('online', on)
      window.removeEventListener('offline', off)
    }
  }, [])

  if (online) return null
  return (
    <div
      role="status"
      style={{
        background: 'var(--warning-bg)',
        color: 'var(--warning-text)',
        textAlign: 'center',
        fontSize: 12.5,
        fontWeight: 700,
        padding: '8px 12px',
      }}
    >
      <WifiOff size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Hors ligne — les modifications ne seront pas enregistrées
    </div>
  )
}
