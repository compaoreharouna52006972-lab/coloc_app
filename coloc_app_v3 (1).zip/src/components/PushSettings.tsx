'use client'

import { Bell } from 'lucide-react'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useToast } from '@/contexts/ToastContext'
import { errorMessage } from '@/utils/errors'

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(base64)
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)))
}

export default function PushSettings() {
  const { toast } = useToast()
  const [supported, setSupported] = useState(false)
  const [enabled, setEnabled] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    const ok = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window
    setSupported(ok)
    if (!ok) return
    navigator.serviceWorker
      .getRegistration()
      .then((reg) => reg?.pushManager.getSubscription())
      .then((sub) => setEnabled(!!sub && Notification.permission === 'granted'))
      .catch(() => setEnabled(false))
  }, [])

  async function enable() {
    const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY
    if (!publicKey) {
      toast('Clé de notifications manquante dans la configuration', 'error')
      return
    }
    setBusy(true)
    try {
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        toast('Permission refusée : autorise les notifications dans les réglages du navigateur', 'error')
        return
      }
      const registration = await navigator.serviceWorker.register('/sw.js')
      await navigator.serviceWorker.ready
      const subscription =
        (await registration.pushManager.getSubscription()) ??
        (await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey) as BufferSource,
        }))
      const json = subscription.toJSON()
      const { error } = await supabase.rpc('save_push_subscription', {
        p_endpoint: json.endpoint,
        p_p256dh: json.keys?.p256dh,
        p_auth: json.keys?.auth,
      })
      if (error) throw error
      setEnabled(true)
      toast('Notifications activées sur cet appareil', 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    } finally {
      setBusy(false)
    }
  }

  async function disable() {
    setBusy(true)
    try {
      const registration = await navigator.serviceWorker.getRegistration()
      const subscription = await registration?.pushManager.getSubscription()
      if (subscription) {
        await supabase.rpc('delete_push_subscription', { p_endpoint: subscription.endpoint })
        await subscription.unsubscribe()
      }
      setEnabled(false)
      toast('Notifications désactivées sur cet appareil', 'info')
    } catch (err) {
      toast(errorMessage(err), 'error')
    } finally {
      setBusy(false)
    }
  }

  if (!supported) return null

  return (
    <div className="card" style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}><Bell size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Notifications sur ce téléphone</div>
      <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12, lineHeight: 1.5 }}>
        Reçois une alerte quand une dette, un paiement ou une tâche te concerne, même application fermée.
        Sur iPhone, installe d'abord l'application sur l'écran d'accueil.
      </div>
      <button
        onClick={enabled ? disable : enable}
        disabled={busy}
        className={enabled ? 'btn btn-secondary' : 'btn btn-primary'}
        style={{ width: '100%' }}
      >
        {busy ? '…' : enabled ? 'Désactiver les notifications' : 'Activer les notifications'}
      </button>
    </div>
  )
}
