'use client'

import { useEffect } from 'react'
// Importé ici (côté navigateur) pour écouter « beforeinstallprompt » dès le chargement
import '@/lib/pwaPrompt'

// Le service worker ne sert qu'aux notifications push. Il ne met aucune donnée en cache :
// l'ancien cache de l'API (Workbox) pouvait montrer à un compte les données d'un autre.
export default function RegisterSW() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => console.error('Service worker :', err))
    }
  }, [])
  return null
}
