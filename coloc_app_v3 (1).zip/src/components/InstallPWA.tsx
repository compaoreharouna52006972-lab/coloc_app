'use client'

import { CheckCircle2, Smartphone } from 'lucide-react'
import { useEffect, useState } from 'react'
import {
  getDeferredPrompt,
  clearDeferredPrompt,
  subscribePrompt,
  type BeforeInstallPromptEvent,
} from '@/lib/pwaPrompt'

export default function InstallPWA() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(getDeferredPrompt())
  const [isInstalled, setIsInstalled] = useState(false)
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    // Détection iOS
    const ios =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
    setIsIOS(ios)

    // Déjà installée ?
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
      return
    }

    return subscribePrompt(setDeferredPrompt)
  }, [])

  async function handleInstall() {
    if (!deferredPrompt) return
    await deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice
    if (outcome === 'accepted') setIsInstalled(true)
    clearDeferredPrompt()
  }

  if (isInstalled) {
    return (
      <div className="card" style={{ marginBottom: 14, background: 'var(--success-bg)', borderLeft: '4px solid var(--success)' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--success-text)' }}>
          <CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Application installée
        </div>
        <div style={{ fontSize: 11.5, color: 'var(--success-text)', opacity: 0.85, marginTop: 2 }}>
          Appart 4B est sur ton écran d'accueil.
        </div>
      </div>
    )
  }

  // Cas iOS : pas de prompt natif, on affiche les instructions
  if (isIOS) {
    return (
      <div className="card" style={{ marginBottom: 14, background: 'var(--primary-bg)', borderLeft: '4px solid var(--primary)' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--primary)', marginBottom: 4 }}>
          <Smartphone size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Installer Appart 4B
        </div>
        <div style={{ fontSize: 12, color: 'var(--primary)', lineHeight: 1.5 }}>
          Appuie sur <strong>Partager</strong> (icône ⬆️) puis sur <strong>« Sur l'écran d'accueil »</strong>.
        </div>
      </div>
    )
  }

  // Cas Android/Chrome avec prompt natif disponible
  if (deferredPrompt) {
    return (
      <button
        onClick={handleInstall}
        className="btn btn-primary"
        style={{ width: '100%', marginBottom: 14 }}
      >
        <Smartphone size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Installer l'app
      </button>
    )
  }

  return null
}
