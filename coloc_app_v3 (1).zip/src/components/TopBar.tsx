'use client'

import type { ReactNode } from 'react'
import { Bell, Plus, User } from 'lucide-react'
import { Link } from '@/lib/router'
import { useApartment } from '@/contexts/ApartmentContext'
import { useNotifications } from '@/hooks/useNotifications'

const iconButton = {
  position: 'relative' as const,
  width: 38,
  height: 38,
  borderRadius: 11,
  background: 'rgba(255,255,255,0.1)',
  color: '#EEF1EF',
  display: 'grid',
  placeItems: 'center',
  textDecoration: 'none',
}

// En-tête sombre d'Appart 4B. Sur l'accueil, `children` (le bloc de chiffres) s'affiche
// dans le même bandeau, sous la ligne du haut.
export default function TopBar({ children }: { children?: ReactNode }) {
  const { apartment } = useApartment()
  const { unreadCount } = useNotifications()

  return (
    <header
      style={{
        background: 'var(--hero)',
        color: '#EEF1EF',
        padding: `calc(14px + var(--safe-top)) 16px ${children ? 22 : 16}px`,
        borderRadius: '0 0 24px 24px',
      }}
    >
      <div style={{ maxWidth: 600, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 11, letterSpacing: 1.2, opacity: 0.55, textTransform: 'uppercase', fontWeight: 600 }}>
              Appart 4B
            </div>
            <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: -0.2, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {apartment?.name ?? 'Mon appartement'}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Link to="/factures/nouvelle" style={iconButton} aria-label="Ajouter une facture">
              <Plus size={20} />
            </Link>
            <Link to="/notifications" style={iconButton} aria-label="Notifications">
              <Bell size={19} />
              {unreadCount > 0 && (
                <span
                  style={{
                    position: 'absolute',
                    top: -4,
                    right: -4,
                    background: 'var(--danger)',
                    color: '#fff',
                    borderRadius: 99,
                    minWidth: 18,
                    height: 18,
                    display: 'grid',
                    placeItems: 'center',
                    fontSize: 10,
                    fontWeight: 700,
                    padding: '0 4px',
                  }}
                >
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </Link>
            <Link to="/profil" style={iconButton} aria-label="Mon profil">
              <User size={19} />
            </Link>
          </div>
        </div>

        {children}
      </div>
    </header>
  )
}
