'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'

export type BudgetLine = {
  category: string
  planned: number
  actual: number
  budgetId: string | null
}

const CATEGORIES = [
  'loyer',
  'electricite',
  'eau',
  'wifi',
  'courses',
  'gaz',
  'autre',
] as const

export const CATEGORY_META: Record<string, { label: string }> = {
  loyer: { label: 'Loyer' },
  electricite: { label: 'Électricité' },
  eau: { label: 'Eau' },
  wifi: { label: 'WiFi' },
  courses: { label: 'Courses' },
  gaz: { label: 'Gaz' },
  autre: { label: 'Autre' },
}

// Format AAAA-MM-01 construit en heure locale (toISOString() convertit en UTC
// et renvoyait le dernier jour du mois précédent au Maroc, en UTC+1).
function monthStartString(year: number, monthIndex: number): string {
  const d = new Date(year, monthIndex, 1)
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  return `${d.getFullYear()}-${mm}-01`
}

function firstDayOfMonth(d = new Date()): string {
  return monthStartString(d.getFullYear(), d.getMonth())
}

function firstDayNextMonth(d = new Date()): string {
  return monthStartString(d.getFullYear(), d.getMonth() + 1)
}

export function useBudget() {
  const { apartment } = useApartment()
  const [lines, setLines] = useState<BudgetLine[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setLines([])
      setLoading(false)
      return
    }

    setLoading(true)

    const monthStart = firstDayOfMonth()
    const monthEnd = firstDayNextMonth()

    const [budgetsRes, invoicesRes] = await Promise.all([
      supabase
        .from('budgets')
        .select('*')
        .eq('apartment_id', apartment.id)
        .eq('month', monthStart),
      supabase
        .from('invoices')
        .select('category, amount')
        .eq('apartment_id', apartment.id)
        .gte('created_at', monthStart)
        .lt('created_at', monthEnd),
    ])

    const plannedByCat: Record<string, { amount: number; id: string }> = {}
    for (const b of budgetsRes.data ?? []) {
      plannedByCat[b.category] = { amount: Number(b.planned_amount), id: b.id }
    }

    const actualByCat: Record<string, number> = {}
    for (const inv of invoicesRes.data ?? []) {
      actualByCat[inv.category] = (actualByCat[inv.category] ?? 0) + Number(inv.amount)
    }

    const result: BudgetLine[] = CATEGORIES.map((cat) => ({
      category: cat,
      planned: plannedByCat[cat]?.amount ?? 0,
      actual: actualByCat[cat] ?? 0,
      budgetId: plannedByCat[cat]?.id ?? null,
    }))

    setLines(result)
    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function upsertPlanned(category: string, amount: number) {
    if (!apartment) return

    const monthStart = firstDayOfMonth()

    const { error } = await supabase.from('budgets').upsert(
      {
        apartment_id: apartment.id,
        month: monthStart,
        category,
        planned_amount: amount,
      },
      { onConflict: 'apartment_id,month,category' }
    )

    if (error) throw error
    await load()
  }

  return { lines, loading, upsertPlanned, refresh: load }
}
