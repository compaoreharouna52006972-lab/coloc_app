'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Absence } from '@/types'

export function useAbsences() {
  const { apartment } = useApartment()
  const [absences, setAbsences] = useState<Absence[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setAbsences([])
      setLoading(false)
      return
    }
    const { data, error } = await supabase
      .from('absences')
      .select('*')
      .eq('apartment_id', apartment.id)
      .order('start_date', { ascending: false })
    if (error) {
      console.error('Erreur absences:', error)
      setAbsences([])
    } else {
      setAbsences((data as Absence[]) ?? [])
    }
    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function declare(start: string, end: string) {
    if (!apartment) return
    const { error } = await supabase.rpc('declare_absence', {
      p_apartment: apartment.id,
      p_start: start,
      p_end: end,
    })
    if (error) throw error
    await load()
  }

  async function remove(id: string) {
    const { error } = await supabase.rpc('delete_absence', { p_id: id })
    if (error) throw error
    await load()
  }

  return { absences, loading, declare, remove, refresh: load }
}
