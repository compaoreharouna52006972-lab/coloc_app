'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Message, Profile } from '@/types'

export type MessageWithSender = Message & {
  sender: Pick<Profile, 'id' | 'full_name'>
}

export function useMessages() {
  const { apartment } = useApartment()
  const [messages, setMessages] = useState<MessageWithSender[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setMessages([])
      setLoading(false)
      return
    }

    setLoading(true)

    const { data, error } = await supabase
      .from('messages')
      .select(`
        *,
        sender:profiles!sender_id(id, full_name)
      `)
      .eq('apartment_id', apartment.id)
      .order('created_at', { ascending: false })
      .limit(100)

    if (error) {
      console.error('Erreur chargement messages:', error)
      setMessages([])
    } else {
      // Reçus du plus récent au plus ancien : on remet l'ordre de lecture
      setMessages(((data as unknown as MessageWithSender[]) ?? []).slice().reverse())
    }

    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  // Temps réel : nouveaux messages, modifications et suppressions
  useEffect(() => {
    if (!apartment) return

    const channel = supabase
      .channel(`messages:${apartment.id}:${Math.random().toString(36).slice(2)}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `apartment_id=eq.${apartment.id}` },
        async (payload) => {
          const newMsg = payload.new as Message
          const { data: sender } = await supabase
            .from('profiles')
            .select('id, full_name')
            .eq('id', newMsg.sender_id)
            .single()

          const safeSender = (sender as Pick<Profile, 'id' | 'full_name'> | null) ?? {
            id: newMsg.sender_id,
            full_name: 'Inconnu',
          }
          setMessages((prev) =>
            prev.some((m) => m.id === newMsg.id) ? prev : [...prev, { ...newMsg, sender: safeSender }]
          )
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'messages', filter: `apartment_id=eq.${apartment.id}` },
        (payload) => {
          const upd = payload.new as Message
          setMessages((prev) =>
            prev.map((m) => (m.id === upd.id ? { ...m, content: upd.content, edited_at: upd.edited_at } : m))
          )
        }
      )
      // Les événements DELETE ne peuvent pas être filtrés : on ignore les identifiants inconnus
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, (payload) => {
        const oldId = (payload.old as { id?: string }).id
        if (oldId) setMessages((prev) => prev.filter((m) => m.id !== oldId))
      })
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [apartment])

  async function sendMessage(content: string) {
    if (!apartment) return
    const { data: userData } = await supabase.auth.getUser()
    if (!userData.user) throw new Error('Non connecté')

    const { error } = await supabase.from('messages').insert({
      apartment_id: apartment.id,
      sender_id: userData.user.id,
      content: content.trim(),
    })

    if (error) throw error
  }

  async function editMessage(id: string, content: string) {
    const { error } = await supabase.rpc('edit_message', { p_message: id, p_content: content })
    if (error) throw error
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, content: content.trim(), edited_at: new Date().toISOString() } : m))
    )
  }

  async function deleteMessage(id: string) {
    const { error } = await supabase.rpc('delete_message', { p_message: id })
    if (error) throw error
    setMessages((prev) => prev.filter((m) => m.id !== id))
  }

  return { messages, loading, sendMessage, editMessage, deleteMessage, refresh: load }
}
