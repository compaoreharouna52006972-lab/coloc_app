'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Invoice } from '@/types'

export type InvoiceWithCreator = Invoice & {
  creator: { full_name: string }
}

export function useInvoices() {
  const { apartment } = useApartment()
  const [invoices, setInvoices] = useState<InvoiceWithCreator[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setInvoices([])
      setLoading(false)
      return
    }

    setLoading(true)
    const { data, error } = await supabase
      .from('invoices')
      .select(`*, creator:profiles!created_by(full_name)`)
      .eq('apartment_id', apartment.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Erreur factures:', error)
    } else {
      setInvoices((data as unknown as InvoiceWithCreator[]) ?? [])
    }
    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function deleteInvoice(id: string) {
    // Le serveur vérifie les droits (auteur ou responsable) et refuse si des paiements existent
    const { data: receiptPath, error } = await supabase.rpc('delete_invoice', { p_invoice: id })
    if (error) throw error
    if (receiptPath) {
      // Nettoyage au mieux : un reçu orphelin ne doit pas bloquer la suppression
      await supabase.storage.from('receipts').remove([receiptPath as string])
    }
    await load()
  }

  return { invoices, loading, deleteInvoice, refresh: load }
}
