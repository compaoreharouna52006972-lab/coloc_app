'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Equipment } from '@/types'

export const EQUIPMENT_STATUS: Record<
  Equipment['status'],
  { label: string; dot: string; color: string }
> = {
  good: { label: 'Bon état', dot: '#2F6F63', color: 'var(--success-text)' },
  worn: { label: 'Usé', dot: '#D9A441', color: 'var(--warning-text)' },
  to_repair: { label: 'À réparer', dot: '#C97A3D', color: 'var(--warning-text)' },
  broken: { label: 'Hors service', dot: '#C0463C', color: 'var(--danger-text)' },
  disposed: { label: 'Jeté', dot: '#8A968F', color: 'var(--text-muted)' },
}

export function useEquipments() {
  const { apartment } = useApartment()
  const [equipments, setEquipments] = useState<Equipment[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setEquipments([])
      setLoading(false)
      return
    }

    setLoading(true)

    const { data, error } = await supabase
      .from('equipments')
      .select('*')
      .eq('apartment_id', apartment.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Erreur chargement équipements:', error)
      setEquipments([])
    } else {
      setEquipments((data as Equipment[]) ?? [])
    }

    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function createEquipment(payload: {
    name: string
    category: string
    status: Equipment['status']
    location?: string
    purchase_price?: number
    purchase_date?: string
    photo?: File | null
  }) {
    if (!apartment) return

    let photoPath: string | null = null

    // Upload photo si fournie
    if (payload.photo) {
      const ext = payload.photo.name.split('.').pop() || 'jpg'
      const fileName = `${apartment.id}/${Date.now()}.${ext}`

      const { error: uploadErr } = await supabase.storage
        .from('receipts')
        .upload(fileName, payload.photo)

      if (uploadErr) {
        console.error('Erreur upload photo:', uploadErr)
      } else {
        photoPath = fileName
      }
    }

    const { error } = await supabase.from('equipments').insert({
      apartment_id: apartment.id,
      name: payload.name,
      category: payload.category,
      status: payload.status,
      location: payload.location || null,
      purchase_price: payload.purchase_price ?? null,
      purchase_date: payload.purchase_date || null,
      photo_path: photoPath,
    })

    if (error) throw error
    await load()
  }

  async function updateStatus(id: string, status: Equipment['status']) {
    const { error } = await supabase
      .from('equipments')
      .update({ status })
      .eq('id', id)
    if (error) throw error
    await load()
  }

  async function deleteEquipment(id: string) {
    const photoPath = equipments.find((e) => e.id === id)?.photo_path
    const { error } = await supabase.from('equipments').delete().eq('id', id)
    if (error) throw error
    if (photoPath) {
      // Nettoyage au mieux : une photo orpheline ne doit pas bloquer la suppression
      await supabase.storage.from('receipts').remove([photoPath])
    }
    await load()
  }

  return {
    equipments,
    loading,
    createEquipment,
    updateStatus,
    deleteEquipment,
    refresh: load,
  }
}
