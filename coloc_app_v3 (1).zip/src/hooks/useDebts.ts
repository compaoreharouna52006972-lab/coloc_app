'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Profile } from '@/types'
import type { ShareWithInvoice } from '@/utils/balance'

export type DebtWithPeople = ShareWithInvoice & {
  debtor: Pick<Profile, 'id' | 'full_name'>
  creditor: Pick<Profile, 'id' | 'full_name'>
}

export function useDebts() {
  const { apartment } = useApartment()
  const [debts, setDebts] = useState<DebtWithPeople[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setDebts([])
      setLoading(false)
      return
    }

    setLoading(true)

    const { data, error } = await supabase
      .from('invoice_shares')
      .select(`
        *,
        invoice:invoices!inner(id, title, due_date, category, amount, apartment_id, created_at),
        debtor:profiles!debtor_id(id, full_name),
        creditor:profiles!creditor_id(id, full_name)
      `)
      .eq('invoice.apartment_id', apartment.id)

    if (error) {
      console.error('Erreur chargement dettes:', error)
      setDebts([])
    } else {
      const rows = (data as unknown as DebtWithPeople[]) ?? []
      rows.sort((a, b) =>
        String(b.invoice?.created_at ?? '').localeCompare(String(a.invoice?.created_at ?? ''))
      )
      setDebts(rows)
    }

    setLoading(false)
  }, [apartment])

  // Charge les dettes au démarrage
  useEffect(() => {
    load()
  }, [load])

  return { debts, loading, refresh: load }
}
