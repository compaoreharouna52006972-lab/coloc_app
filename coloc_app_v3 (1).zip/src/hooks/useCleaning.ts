'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { CleaningTurn } from '@/types'

export const CLEANING_ZONES = [
  { key: 'cuisine', label: 'Cuisine' },
  { key: 'salle_de_bain', label: 'Salle de bain' },
  { key: 'toilettes', label: 'Toilettes' },
  { key: 'sol_poussiere', label: 'Sol et poussière' },
  { key: 'poubelles', label: 'Poubelles' },
  { key: 'salon', label: 'Salon' },
] as const

export function useCleaning() {
  const { apartment } = useApartment()
  const [turn, setTurn] = useState<CleaningTurn | null>(null)
  const [history, setHistory] = useState<CleaningTurn[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(
    async (silent = false) => {
      if (!apartment) {
        setTurn(null)
        setHistory([])
        setLoading(false)
        return
      }
      if (!silent) setLoading(true)

      // Crée le premier tour ou réaffecte si la personne de tour est partie
      const { error: ensureErr } = await supabase.rpc('ensure_cleaning_turn', { p_apartment: apartment.id })
      if (ensureErr) console.error('Erreur rotation ménage:', ensureErr)

      const { data, error } = await supabase
        .from('cleaning_turns')
        .select('*')
        .eq('apartment_id', apartment.id)
        .order('created_at', { ascending: false })
        .limit(10)

      if (error) {
        console.error('Erreur chargement ménage:', error)
        setTurn(null)
        setHistory([])
      } else {
        const rows = (data as CleaningTurn[]) ?? []
        setTurn(rows.find((r) => r.status === 'pending') ?? null)
        setHistory(rows.filter((r) => r.status === 'done').slice(0, 4))
      }
      setLoading(false)
    },
    [apartment]
  )

  useEffect(() => {
    load()
  }, [load])

  async function toggleZone(zone: string) {
    if (!turn) return
    // Affichage immédiat, puis synchronisation avec le serveur
    setTurn({
      ...turn,
      zones_done: turn.zones_done.includes(zone)
        ? turn.zones_done.filter((z) => z !== zone)
        : [...turn.zones_done, zone],
    })
    const { error } = await supabase.rpc('toggle_cleaning_zone', { p_turn: turn.id, p_zone: zone })
    if (error) {
      await load(true)
      throw error
    }
  }

  async function complete() {
    if (!turn) return
    const { error } = await supabase.rpc('complete_cleaning', { p_turn: turn.id })
    if (error) throw error
    await load(true)
  }

  async function postpone() {
    if (!turn) return
    const { error } = await supabase.rpc('postpone_cleaning', { p_turn: turn.id })
    if (error) throw error
    await load(true)
  }

  return { turn, history, loading, toggleZone, complete, postpone, refresh: load }
}
