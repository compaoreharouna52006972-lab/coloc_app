'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Member, Profile } from '@/types'

export type MemberWithProfile = Member & {
  profile: Pick<Profile, 'id' | 'full_name'> | null
}

export function useMembers() {
  const { apartment, refresh: refreshApartment } = useApartment()
  const [members, setMembers] = useState<MemberWithProfile[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setMembers([])
      setLoading(false)
      return
    }
    setLoading(true)
    const { data, error } = await supabase
      .from('members')
      .select('*, profiles(id, full_name)')
      .eq('apartment_id', apartment.id)
      .eq('is_active', true)
      .order('joined_at', { ascending: true })

    if (error) {
      console.error('Erreur chargement membres:', error)
      setMembers([])
    } else {
      setMembers(
        (data ?? []).map((row) => {
          const { profiles, ...rest } = row as Record<string, unknown>
          return {
            ...(rest as unknown as Member),
            profile: (profiles ?? null) as MemberWithProfile['profile'],
          }
        })
      )
    }
    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function setRole(memberId: string, role: Member['role']) {
    const { error } = await supabase.rpc('set_member_role', { p_member: memberId, p_role: role })
    if (error) throw error
    await load()
  }

  async function removeMember(memberId: string) {
    const { error } = await supabase.rpc('remove_member', { p_member: memberId })
    if (error) throw error
    await load()
  }

  async function leave() {
    if (!apartment) return
    const { error } = await supabase.rpc('leave_apartment', { p_apartment: apartment.id })
    if (error) throw error
    await refreshApartment()
  }

  async function regenerateCode() {
    if (!apartment) return
    const { error } = await supabase.rpc('regenerate_invite_code', { p_apartment: apartment.id })
    if (error) throw error
    await refreshApartment()
  }

  return { members, loading, setRole, removeMember, leave, regenerateCode, refresh: load }
}
