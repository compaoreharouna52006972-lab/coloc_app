'use client'

import { useCallback, useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import type { Task, Profile } from '@/types'

export type TaskWithAssignee = Task & {
  assignee: Pick<Profile, 'id' | 'full_name'> | null
}

export function useTasks() {
  const { apartment } = useApartment()
  const [tasks, setTasks] = useState<TaskWithAssignee[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    if (!apartment) {
      setTasks([])
      setLoading(false)
      return
    }

    setLoading(true)

    const { data, error } = await supabase
      .from('tasks')
      .select(`
        *,
        assignee:profiles!assigned_to(id, full_name)
      `)
      .eq('apartment_id', apartment.id)
      .order('due_date', { ascending: true, nullsFirst: false })

    if (error) {
      console.error('Erreur chargement tâches:', error)
      setTasks([])
    } else {
      setTasks((data as unknown as TaskWithAssignee[]) ?? [])
    }

    setLoading(false)
  }, [apartment])

  useEffect(() => {
    load()
  }, [load])

  async function createTask(payload: {
    title: string
    description?: string
    assigned_to?: string | null
    due_date?: string | null
    is_recurring?: boolean
    recurrence_rule?: string | null
  }) {
    if (!apartment) return
    const { error } = await supabase.from('tasks').insert({
      apartment_id: apartment.id,
      title: payload.title,
      description: payload.description || null,
      assigned_to: payload.assigned_to || null,
      due_date: payload.due_date || null,
      is_recurring: payload.is_recurring ?? false,
      recurrence_rule: payload.recurrence_rule ?? null,
      status: 'pending',
    })
    if (error) throw error
    await load()
  }

  async function markDone(taskId: string) {
    const { error } = await supabase
      .from('tasks')
      .update({ status: 'done', completed_at: new Date().toISOString() })
      .eq('id', taskId)
    if (error) throw error
    await load()
  }

  async function postpone(taskId: string) {
    const { error } = await supabase
      .from('tasks')
      .update({ status: 'postponed' })
      .eq('id', taskId)
    if (error) throw error
    await load()
  }

  async function resume(taskId: string) {
    const { error } = await supabase
      .from('tasks')
      .update({ status: 'pending', completed_at: null })
      .eq('id', taskId)
    if (error) throw error
    await load()
  }

  async function deleteTask(taskId: string) {
    const { error } = await supabase.from('tasks').delete().eq('id', taskId)
    if (error) throw error
    await load()
  }

  return { tasks, loading, createTask, markDone, postpone, resume, deleteTask, refresh: load }
}
