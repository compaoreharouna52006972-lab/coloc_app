export type Profile = {
  id: string
  full_name: string
  avatar_url: string | null
  accessibility_settings: Record<string, unknown>
  created_at: string
}

export type Apartment = {
  id: string
  name: string
  address: string | null
  invite_code: string
  created_by: string
  created_at: string
}

export type Member = {
  id: string
  apartment_id: string
  user_id: string
  role: 'admin' | 'manager' | 'member'
  is_active: boolean
  joined_at: string
}

export type Invoice = {
  id: string
  apartment_id: string
  title: string
  amount: number
  category: 'loyer' | 'electricite' | 'eau' | 'wifi' | 'courses' | 'gaz' | 'autre'
  due_date: string | null
  status: 'draft' | 'pending' | 'partially_paid' | 'paid' | 'disputed'
  paid_by: string
  created_by: string
  receipt_path: string | null
  period_start: string | null
  period_end: string | null
  is_recurring: boolean
  recurrence_rule: string | null
  created_at: string
}

export type InvoiceShare = {
  id: string
  invoice_id: string
  debtor_id: string
  creditor_id: string
  amount_due: number
  amount_paid: number
  pending_amount: number
  status: 'pending' | 'awaiting_confirmation' | 'confirmed' | 'disputed'
  payment_method: string | null
  paid_at: string | null
  confirmed_at: string | null
  dispute_reason: string | null
}

export type Task = {
  id: string
  apartment_id: string
  title: string
  description: string | null
  assigned_to: string | null
  due_date: string | null
  status: 'pending' | 'done' | 'postponed'
  is_recurring: boolean
  recurrence_rule: string | null
  completed_at: string | null
  created_at: string
}

export type Equipment = {
  id: string
  apartment_id: string
  name: string
  category: string | null
  purchase_price: number | null
  purchase_date: string | null
  status: 'good' | 'worn' | 'to_repair' | 'broken' | 'disposed'
  location: string | null
  photo_path: string | null
  created_at: string
}

export type Budget = {
  id: string
  apartment_id: string
  month: string
  category: string
  planned_amount: number
}

export type Message = {
  id: string
  apartment_id: string
  sender_id: string
  content: string
  edited_at?: string | null
  created_at: string
}

export type Notification = {
  id: string
  user_id: string
  title: string
  body: string | null
  type: 'debt' | 'task' | 'message' | 'system' | null
  link: string | null
  is_read: boolean
  created_at: string
}

export type Absence = {
  id: string
  apartment_id: string
  user_id: string
  start_date: string
  end_date: string
  created_at: string
}

export type CleaningTurn = {
  id: string
  apartment_id: string
  user_id: string
  week_start: string
  status: 'pending' | 'done'
  catching_up: boolean
  postponed_count: number
  zones_done: string[]
  completed_at: string | null
  created_at: string
}
