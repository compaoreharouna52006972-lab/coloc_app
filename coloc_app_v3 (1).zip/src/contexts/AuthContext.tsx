'use client'

import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'
import type { Profile } from '@/types'

type AuthState = {
  user: User | null
  profile: Profile | null
  loading: boolean
  signInWithEmail: (email: string) => Promise<void>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthState | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const userIdRef = useRef<string | null>(null)

  async function loadProfile(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle()

    if (error) {
      console.error('Erreur chargement profil:', error)
      setProfile(null)
    } else {
      setProfile(data)
    }
  }

  useEffect(() => {
    let active = true

    supabase.auth
      .getSession()
      .then(async ({ data: { session } }) => {
        if (!active) return
        userIdRef.current = session?.user?.id ?? null
        setUser(session?.user ?? null)
        if (session?.user) await loadProfile(session.user.id)
      })
      .catch((err) => console.error('Erreur session:', err))
      .finally(() => {
        if (active) setLoading(false)
      })

    // IMPORTANT : ce callback ne doit pas être async ni attendre un appel Supabase,
    // sinon le client peut se bloquer (page figée sur « Chargement… » après le lien magique).
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      const newId = session?.user?.id ?? null

      if (!newId) {
        userIdRef.current = null
        setUser(null)
        setProfile(null)
        return
      }

      // Évite de recréer l'objet user (et de tout recharger) à chaque retour sur l'onglet
      setUser((prev) => (prev?.id === newId ? prev : session!.user))

      if (userIdRef.current !== newId || event === 'USER_UPDATED') {
        userIdRef.current = newId
        setTimeout(() => {
          loadProfile(newId)
        }, 0)
      }
    })

    return () => {
      active = false
      subscription.unsubscribe()
    }
  }, [])

  async function signInWithEmail(email: string) {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
      },
    })
    if (error) throw error
  }

  async function signOut() {
    await supabase.auth.signOut()
    setUser(null)
    setProfile(null)
  }

  async function refreshProfile() {
    if (user) await loadProfile(user.id)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        signInWithEmail,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth doit être utilisé dans AuthProvider')
  return ctx
}
