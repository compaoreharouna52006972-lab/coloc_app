'use client'

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import type { Apartment, Member } from '@/types'

type ApartmentState = {
  apartment: Apartment | null
  member: Member | null
  loading: boolean
  refresh: () => Promise<void>
}

const ApartmentContext = createContext<ApartmentState | undefined>(undefined)

export function ApartmentProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [apartment, setApartment] = useState<Apartment | null>(null)
  const [member, setMember] = useState<Member | null>(null)
  const [loading, setLoading] = useState(true)

  async function load() {
    if (!user) {
      setApartment(null)
      setMember(null)
      setLoading(false)
      return
    }

    setLoading(true)

    const { data: memberData, error: memberError } = await supabase
      .from('members')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .maybeSingle()

    if (memberError) {
      console.error('Erreur chargement membre:', memberError)
      setLoading(false)
      return
    }

    if (!memberData) {
      setMember(null)
      setApartment(null)
      setLoading(false)
      return
    }

    setMember(memberData as Member)

    const { data: aptData, error: aptError } = await supabase
      .from('apartments')
      .select('*')
      .eq('id', memberData.apartment_id)
      .single()

    if (aptError) {
      console.error('Erreur chargement appartement:', aptError)
      setApartment(null)
    } else {
      setApartment(aptData as Apartment)
    }

    setLoading(false)
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id])

  return (
    <ApartmentContext.Provider
      value={{ apartment, member, loading, refresh: load }}
    >
      {children}
    </ApartmentContext.Provider>
  )
}

export function useApartment() {
  const ctx = useContext(ApartmentContext)
  if (!ctx)
    throw new Error('useApartment doit être utilisé dans ApartmentProvider')
  return ctx
}
