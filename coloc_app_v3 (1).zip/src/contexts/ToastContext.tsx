'use client'

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'

type Kind = 'success' | 'error' | 'info'
type ToastItem = { id: number; message: string; kind: Kind }
type ToastState = { toast: (message: string, kind?: Kind) => void }

const ToastContext = createContext<ToastState | undefined>(undefined)

const STYLES: Record<Kind, { bg: string; color: string }> = {
  success: { bg: 'var(--success-bg)', color: 'var(--success-text)' },
  error: { bg: 'var(--danger-bg)', color: 'var(--danger-text)' },
  info: { bg: 'var(--primary-bg)', color: 'var(--primary)' },
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])
  const nextId = useRef(1)

  const toast = useCallback((message: string, kind: Kind = 'info') => {
    const id = nextId.current++
    setItems((prev) => [...prev, { id, message, kind }])
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4000)
  }, [])

  const value = useMemo(() => ({ toast }), [toast])

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        style={{
          position: 'fixed',
          top: 'calc(12px + env(safe-area-inset-top, 0px))',
          left: 12,
          right: 12,
          zIndex: 1000,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
          pointerEvents: 'none',
        }}
      >
        {items.map((t) => (
          <div
            key={t.id}
            role={t.kind === 'error' ? 'alert' : 'status'}
            style={{
              background: STYLES[t.kind].bg,
              color: STYLES[t.kind].color,
              padding: '10px 14px',
              borderRadius: 10,
              fontSize: 13,
              fontWeight: 600,
              maxWidth: 420,
              boxShadow: '0 4px 14px rgba(0,0,0,.15)',
            }}
          >
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast doit être utilisé dans ToastProvider')
  return ctx
}
