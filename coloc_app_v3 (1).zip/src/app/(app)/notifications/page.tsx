'use client'

import { Bell, MessageCircle, Sparkles, Wallet, type LucideIcon } from 'lucide-react'
import { Link } from '@/lib/router'
import Layout from '@/components/Layout'
import { useNotifications } from '@/hooks/useNotifications'
import { formatRelative } from '@/utils/format'

const TYPE_META: Record<string, { icon: LucideIcon; color: string }> = {
  debt: { icon: Wallet, color: 'var(--danger)' },
  task: { icon: Sparkles, color: 'var(--warning)' },
  message: { icon: MessageCircle, color: 'var(--primary)' },
  system: { icon: Bell, color: 'var(--text-muted)' },
}

export default function NotificationsPage() {
  const { notifications, loading, unreadCount, markAsRead, markAllAsRead } =
    useNotifications()

  return (
    <Layout>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <h1 className="page-title">Notifications</h1>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>
            {unreadCount > 0
              ? `${unreadCount} non lue${unreadCount > 1 ? 's' : ''}`
              : 'Tout est lu'}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            style={{
              background: 'var(--primary-bg)',
              color: 'var(--primary)',
              border: 'none',
              padding: '8px 12px',
              borderRadius: 8,
              fontSize: 11.5,
              fontWeight: 700,
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            Tout marquer lu
          </button>
        )}
      </div>

      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement…
        </div>
      ) : notifications.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
          Aucune notification pour l'instant.
        </div>
      ) : (
        notifications.map((n) => {
          const meta = TYPE_META[n.type ?? 'system'] ?? TYPE_META.system
          
          // Protection : Si la date est invalide, on affiche un fallback
          let safeTime = 'récemment'
          try {
            if (n.created_at) {
              safeTime = formatRelative(n.created_at)
            }
          } catch (e) {
            console.warn("Date invalide pour la notification", n.id)
          }

          const content = (
            <div
              style={{
                display: 'flex',
                gap: 11,
                padding: 14,
                background: n.is_read ? 'var(--card)' : 'var(--primary-bg)',
                borderRadius: 12,
                boxShadow: 'var(--shadow)',
                marginBottom: 8,
                borderLeft: n.is_read ? '4px solid var(--border)' : `4px solid ${meta.color}`,
                textDecoration: 'none',
                color: 'inherit',
                cursor: n.link ? 'pointer' : 'default',
              }}
              onClick={() => {
                if (!n.is_read) markAsRead(n.id)
              }}
            >
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 9,
                  background: 'var(--primary-bg)',
                  display: 'grid',
                  placeItems: 'center',
                  fontSize: 16,
                  flexShrink: 0,
                }}
              >
                <meta.icon size={17} color="var(--primary)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div
                  style={{
                    fontSize: 13,
                    fontWeight: n.is_read ? 600 : 800,
                    color: 'var(--text)',
                    marginBottom: 2,
                  }}
                >
                  {n.title || 'Notification'}
                </div>
                {n.body && (
                  <div
                    style={{
                      fontSize: 12,
                      color: 'var(--text-muted)',
                      lineHeight: 1.45,
                      marginBottom: 4,
                    }}
                  >
                    {n.body}
                  </div>
                )}
                <div style={{ fontSize: 10.5, color: 'var(--text-muted)' }}>
                  {safeTime}
                </div>
              </div>
              {!n.is_read && (
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: '50%',
                    background: 'var(--danger)',
                    flexShrink: 0,
                    marginTop: 6,
                  }}
                />
              )}
            </div>
          )

          // Protection : On vérifie que le lien est valide avant de l'utiliser
          if (n.link && typeof n.link === 'string' && n.link.startsWith('/')) {
            return (
              <Link key={n.id} to={n.link} style={{ textDecoration: 'none' }}>
                {content}
              </Link>
            )
          }

          return <div key={n.id}>{content}</div>
        })
      )}
    </Layout>
  )
}
