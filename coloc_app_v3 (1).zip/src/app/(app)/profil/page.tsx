'use client'

import { CheckCircle2, PlaneTakeoff, Users } from 'lucide-react'
import { useState, useEffect, type FormEvent } from 'react'
import { Link, useNavigate } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import Layout from '@/components/Layout'
import InstallPWA from '@/components/InstallPWA'
import PushSettings from '@/components/PushSettings'

export default function ProfilePage() {
  const navigate = useNavigate()
  const { user, profile, signOut, refreshProfile } = useAuth()
  const { apartment, member } = useApartment()
  
  const [fullName, setFullName] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (profile?.full_name) {
      setFullName(profile.full_name)
    }
  }, [profile])

  async function handleUpdate(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setError(null)
    setSuccess(false)
    setLoading(true)

    try {
      const { error: updErr } = await supabase
        .from('profiles')
        .update({ full_name: fullName.trim() })
        .eq('id', user.id)

      if (updErr) throw updErr

      await refreshProfile()
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur inconnue')
    } finally {
      setLoading(false)
    }
  }

  async function handleSignOut() {
    await signOut()
    navigate('/login', { replace: true })
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 16 }}>Mon profil
      </h1>

      <InstallPWA />
      <PushSettings />

      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--primary), var(--primary-light))',
              color: '#fff',
              display: 'grid',
              placeItems: 'center',
              fontSize: 22,
              fontWeight: 800,
            }}
          >
            {fullName.charAt(0).toUpperCase() || '?'}
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700 }}>{profile?.full_name}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{user?.email}</div>
          </div>
        </div>

        {apartment && (
          <div style={{ background: 'var(--bg)', borderRadius: 10, padding: 12, fontSize: 12.5, marginBottom: 14 }}>
            <div style={{ color: 'var(--text-muted)', marginBottom: 4 }}>Appartement</div>
            <div style={{ fontWeight: 700 }}>{apartment.name}</div>
            <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 4 }}>
              Rôle : <strong>{member?.role === 'admin' ? 'Admin' : member?.role === 'manager' ? 'Gestionnaire' : 'Membre'}</strong>
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>
              Code d'invitation : <strong>{apartment.invite_code}</strong>
            </div>
          </div>
        )}

        {apartment && (
          <Link
            to="/membres"
            className="btn btn-secondary"
            style={{ display: 'block', textAlign: 'center', textDecoration: 'none', marginBottom: 14, border: '1.5px solid var(--border)' }}
          >
            <Users size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Colocataires &amp; invitation
          </Link>
        )}

        {apartment && (
          <Link
            to="/absences"
            className="btn btn-secondary"
            style={{ display: 'block', textAlign: 'center', textDecoration: 'none', marginBottom: 14, border: '1.5px solid var(--border)' }}
          >
            <PlaneTakeoff size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Mes absences
          </Link>
        )}

        <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label htmlFor="name" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
              Mon prénom
            </label>
            <input
              id="name"
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 14px',
                border: '1.5px solid var(--border)',
                borderRadius: 10,
                outline: 'none',
              }}
            />
          </div>

          {error && (
            <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>
              {error}
            </div>
          )}

          {success && (
            <div role="status" style={{ background: 'var(--success-bg)', color: 'var(--success-text)', padding: 10, borderRadius: 8, fontSize: 12.5, fontWeight: 600 }}>
              <CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Profil mis à jour
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading || fullName.trim().length < 2 || fullName === profile?.full_name}
          >
            {loading ? 'Enregistrement…' : 'Enregistrer'}
          </button>
        </form>
      </div>

      <button onClick={handleSignOut} className="btn btn-danger" style={{ width: '100%' }}>
        Se déconnecter
      </button>
    </Layout>
  )
}
