'use client'

import type { ComponentType } from 'react'
import { MessageCircle, Package, PieChart, PlaneTakeoff, Users, Bell, User, ChevronRight } from 'lucide-react'
import { Link } from '@/lib/router'
import Layout from '@/components/Layout'

const ITEMS: { to: string; label: string; sub: string; icon: ComponentType<{ size?: number; color?: string }> }[] = [
  { to: '/chat', label: 'Messagerie', sub: 'Discuter avec les colocataires', icon: MessageCircle },
  { to: '/inventaire', label: 'Inventaire', sub: 'Équipements et état du matériel', icon: Package },
  { to: '/budget', label: 'Budget', sub: 'Prévu et dépensé ce mois-ci', icon: PieChart },
  { to: '/absences', label: 'Absences', sub: 'Déclarer un départ, parts au prorata', icon: PlaneTakeoff },
  { to: '/membres', label: 'Colocataires', sub: 'Membres et code d\'invitation', icon: Users },
  { to: '/notifications', label: 'Notifications', sub: 'Dettes, tâches et messages', icon: Bell },
  { to: '/profil', label: 'Mon profil', sub: 'Nom, notifications, installation', icon: User },
]

export default function MorePage() {
  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 14 }}>Plus</h1>
      <div className="card" style={{ padding: '4px 17px' }}>
        {ITEMS.map((item, i) => {
          const Icon = item.icon
          return (
            <Link
              key={item.to}
              to={item.to}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 13,
                padding: '13px 0',
                textDecoration: 'none',
                borderBottom: i < ITEMS.length - 1 ? '1px solid #EEF1EF' : 'none',
              }}
            >
              <div style={{ width: 38, height: 38, borderRadius: 11, background: 'var(--primary-bg)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                <Icon size={19} color="var(--primary)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)' }}>{item.label}</div>
                <div style={{ fontSize: 11.5, color: 'var(--text-soft)', marginTop: 1 }}>{item.sub}</div>
              </div>
              <ChevronRight size={17} color="#9AA6A0" />
            </Link>
          )
        })}
      </div>
    </Layout>
  )
}
