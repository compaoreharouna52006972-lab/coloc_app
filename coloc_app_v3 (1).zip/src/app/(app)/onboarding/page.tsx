'use client'

import { useState, type FormEvent } from 'react'
import { useNavigate, Navigate } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { errorMessage } from '@/utils/errors'

type Mode = 'create' | 'join'

export default function OnboardingPage() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { apartment, loading: aptLoading, refresh } = useApartment()

  const [mode, setMode] = useState<Mode>('create')
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [code, setCode] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Déjà dans un appartement → accueil
  if (!aptLoading && apartment) {
    return <Navigate to="/" replace />
  }

  async function handleCreate(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setError(null)
    setLoading(true)

    try {
      const { error: rpcErr } = await supabase.rpc('create_apartment', {
        p_name: name.trim(),
        p_address: address.trim() || null,
      })
      if (rpcErr) throw rpcErr

      await refresh()
      navigate('/', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  async function handleJoin(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setError(null)
    setLoading(true)

    try {
      const { error: rpcErr } = await supabase.rpc('join_apartment', { p_code: code.trim() })
      if (rpcErr) throw rpcErr

      await refresh()
      navigate('/', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
      }}
    >
      <div style={{ width: '100%', maxWidth: 460 }}>
        <div
          style={{
            background: 'var(--hero)',
            color: '#EEF1EF',
            borderRadius: 20,
            padding: '32px 24px',
            textAlign: 'center',
            marginBottom: 20,
          }}
        >
          <div style={{ fontSize: 11.5, letterSpacing: 1.2, opacity: 0.55, textTransform: 'uppercase', fontWeight: 600 }}>Appart 4B</div>
          <h1 style={{ fontSize: 24, fontWeight: 800, letterSpacing: -0.3, marginTop: 4 }}>Bienvenue</h1>
          <p style={{ fontSize: 13, opacity: 0.7, marginTop: 6 }}>Crée ton appartement ou rejoins-en un</p>
        </div>

        <div
          style={{
            display: 'flex',
            gap: 6,
            background: '#fff',
            padding: 4,
            borderRadius: 10,
            marginBottom: 16,
            boxShadow: 'var(--shadow)',
          }}
        >
          <button
            type="button"
            onClick={() => {
              setMode('create')
              setError(null)
            }}
            style={{
              flex: 1,
              padding: '10px 0',
              border: 'none',
              borderRadius: 8,
              fontWeight: 700,
              fontSize: 13,
              background:
                mode === 'create' ? 'var(--primary)' : 'transparent',
              color: mode === 'create' ? '#fff' : 'var(--text-muted)',
            }}
          >
            Créer
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('join')
              setError(null)
            }}
            style={{
              flex: 1,
              padding: '10px 0',
              border: 'none',
              borderRadius: 8,
              fontWeight: 700,
              fontSize: 13,
              background: mode === 'join' ? 'var(--primary)' : 'transparent',
              color: mode === 'join' ? '#fff' : 'var(--text-muted)',
            }}
          >
            Rejoindre
          </button>
        </div>

        {mode === 'create' ? (
          <form
            onSubmit={handleCreate}
            className="card"
            style={{ display: 'flex', flexDirection: 'column', gap: 14 }}
          >
            <div>
              <label
                htmlFor="apt-name"
                style={{
                  display: 'block',
                  fontSize: 13,
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Nom de l'appartement
              </label>
              <input
                id="apt-name"
                type="text"
                required
                minLength={2}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex : Appartement Al Manar"
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  border: '1.5px solid var(--border)',
                  borderRadius: 10,
                  outline: 'none',
                }}
              />
            </div>

            <div>
              <label
                htmlFor="apt-address"
                style={{
                  display: 'block',
                  fontSize: 13,
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Adresse (optionnel)
              </label>
              <input
                id="apt-address"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Ex : 12 rue des Palmiers, Casablanca"
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  border: '1.5px solid var(--border)',
                  borderRadius: 10,
                  outline: 'none',
                }}
              />
            </div>

            {error && (
              <div
                role="alert"
                style={{
                  background: 'var(--danger-bg)',
                  color: 'var(--danger-text)',
                  padding: 10,
                  borderRadius: 8,
                  fontSize: 12.5,
                }}
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || name.trim().length < 2}
              style={{ width: '100%' }}
            >
              {loading ? 'Création…' : "Créer l'appartement"}
            </button>
          </form>
        ) : (
          <form
            onSubmit={handleJoin}
            className="card"
            style={{ display: 'flex', flexDirection: 'column', gap: 14 }}
          >
            <div>
              <label
                htmlFor="invite-code"
                style={{
                  display: 'block',
                  fontSize: 13,
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Code d'invitation
              </label>
              <input
                id="invite-code"
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="Ex : A1B2C3D4"
                maxLength={8}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  border: '1.5px solid var(--border)',
                  borderRadius: 10,
                  outline: 'none',
                  textTransform: 'uppercase',
                  letterSpacing: '0.1em',
                  fontWeight: 700,
                }}
              />
              <p
                style={{
                  fontSize: 11.5,
                  color: 'var(--text-muted)',
                  marginTop: 6,
                }}
              >
                Demande le code à un colocataire déjà membre.
              </p>
            </div>

            {error && (
              <div
                role="alert"
                style={{
                  background: 'var(--danger-bg)',
                  color: 'var(--danger-text)',
                  padding: 10,
                  borderRadius: 8,
                  fontSize: 12.5,
                }}
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || code.length < 6}
              style={{ width: '100%' }}
            >
              {loading ? 'Connexion…' : "Rejoindre l'appartement"}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
