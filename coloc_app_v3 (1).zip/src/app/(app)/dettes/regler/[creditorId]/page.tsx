'use client'

import { Banknote, Landmark, Smartphone } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, Navigate, useNavigate, useParams } from '@/lib/router'
import Layout from '@/components/Layout'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from '@/contexts/ToastContext'
import { useDebts } from '@/hooks/useDebts'
import { computeRemaining } from '@/utils/balance'
import { formatMoney } from '@/utils/format'
import { errorMessage } from '@/utils/errors'

const METHODS = [
  { id: 'virement', label: 'Virement bancaire', icon: Landmark },
  { id: 'especes', label: 'Espèces', icon: Banknote },
  { id: 'app', label: 'Application de paiement', icon: Smartphone },
]

export default function PayAllPage() {
  const { creditorId } = useParams<{ creditorId: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast } = useToast()
  const { debts, loading } = useDebts()
  const [method, setMethod] = useState(METHODS[0])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const list = useMemo(
    () =>
      debts.filter(
        (d) =>
          d.debtor_id === user?.id &&
          d.creditor_id === creditorId &&
          (d.status === 'pending' || d.status === 'disputed') &&
          computeRemaining(d) > 0
      ),
    [debts, user?.id, creditorId]
  )
  const total = list.reduce((s, d) => s + computeRemaining(d), 0)
  const creditorName = list[0]?.creditor?.full_name ?? 'ce colocataire'

  if (loading) {
    return (
      <Layout>
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      </Layout>
    )
  }
  if (!user || !creditorId || list.length === 0) return <Navigate to="/dettes" replace />

  async function handlePay() {
    setBusy(true)
    setError(null)
    try {
      const { error: rpcErr } = await supabase.rpc('declare_payment_bulk', {
        p_creditor: creditorId,
        p_method: method.label,
      })
      if (rpcErr) throw rpcErr
      toast(`Paiement de ${formatMoney(total)} déclaré, ${creditorName.split(' ')[0]} doit le confirmer`, 'success')
      navigate('/dettes', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Tout régler</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
        {list.length} dettes envers {creditorName.split(' ')[0]}, payées en une seule fois
      </p>

      <div className="card" style={{ marginBottom: 14 }}>
        {list.map((d, i) => (
          <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '7px 0', borderTop: i ? '1px dashed var(--border)' : 'none' }}>
            <span>{d.invoice.title}</span>
            <strong className="money">{formatMoney(computeRemaining(d))}</strong>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 15, fontWeight: 800, paddingTop: 10, marginTop: 6, borderTop: '2px solid var(--border)' }}>
          <span>Total</span>
          <span className="money" style={{ color: 'var(--primary)' }}>{formatMoney(total)}</span>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 14 }}>
        <h2 style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 8 }}>Moyen de paiement</h2>
        {METHODS.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setMethod(m)}
            style={{
              display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: '12px',
              marginBottom: 6, borderRadius: 10, fontFamily: 'inherit', fontSize: 13, cursor: 'pointer',
              border: method.id === m.id ? '2px solid var(--primary)' : '1.5px solid var(--border)',
              background: method.id === m.id ? 'var(--primary-bg)' : '#fff',
            }}
          >
            <m.icon size={18} color="var(--primary)" />
            <span style={{ fontWeight: 600 }}>{m.label}</span>
          </button>
        ))}
      </div>

      {error && (
        <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5, marginBottom: 10 }}>{error}</div>
      )}

      <div style={{ display: 'flex', gap: 8 }}>
        <Link to="/dettes" className="btn btn-secondary" style={{ flex: 1, textAlign: 'center', textDecoration: 'none' }}>Annuler</Link>
        <button className="btn btn-primary" style={{ flex: 2 }} disabled={busy} onClick={handlePay}>
          {busy ? 'Envoi…' : `Déclarer ${formatMoney(total)} payés`}
        </button>
      </div>
    </Layout>
  )
}
