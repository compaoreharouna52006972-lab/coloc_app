'use client'

import { AlertTriangle, Calendar, CheckCircle2, Wallet } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link } from '@/lib/router'
import { useAuth } from '@/contexts/AuthContext'
import { useDebts } from '@/hooks/useDebts'
import { supabase } from '@/lib/supabase'
import { useToast } from '@/contexts/ToastContext'
import { errorMessage } from '@/utils/errors'
import Layout from '@/components/Layout'
import { computeRemaining, isLate, netBalances, settleUp } from '@/utils/balance'
import { formatMoney, formatDate } from '@/utils/format'

type Tab = 'all' | 'mine' | 'credits'

export default function DebtsPage() {
  const { profile } = useAuth()
  const { debts, loading, refresh } = useDebts()
  const { toast } = useToast()
  const [tab, setTab] = useState<Tab>('all')
  const settlement = useMemo(() => settleUp(netBalances(debts)), [debts])

  // Mes dettes regroupées par créancier (règlement en une fois) et paiements à confirmer par débiteur
  const payGroups = useMemo(() => {
    const map = new Map<string, { id: string; name: string; count: number; total: number }>()
    for (const d of debts) {
      if (d.debtor_id !== profile?.id || (d.status !== 'pending' && d.status !== 'disputed')) continue
      const r = computeRemaining(d)
      if (r <= 0) continue
      const g = map.get(d.creditor_id) ?? { id: d.creditor_id, name: d.creditor?.full_name ?? 'Inconnu', count: 0, total: 0 }
      g.count += 1
      g.total += r
      map.set(d.creditor_id, g)
    }
    return [...map.values()].filter((g) => g.count > 1)
  }, [debts, profile?.id])

  const confirmGroups = useMemo(() => {
    const map = new Map<string, { id: string; name: string; count: number; total: number }>()
    for (const d of debts) {
      if (d.creditor_id !== profile?.id || d.status !== 'awaiting_confirmation') continue
      const g = map.get(d.debtor_id) ?? { id: d.debtor_id, name: d.debtor?.full_name ?? 'Inconnu', count: 0, total: 0 }
      g.count += 1
      g.total += d.pending_amount > 0 ? d.pending_amount : d.amount_paid
      map.set(d.debtor_id, g)
    }
    return [...map.values()].filter((g) => g.count > 1)
  }, [debts, profile?.id])

  async function confirmAll(debtorId: string) {
    try {
      const { error } = await supabase.rpc('confirm_payments_bulk', { p_debtor: debtorId })
      if (error) throw error
      toast('Paiements confirmés', 'success')
      await refresh()
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  const filtered = useMemo(() => {
    // On ne garde que les dettes non confirmées (donc en cours)
    const active = debts.filter((d) => d.status !== 'confirmed')
    
    if (tab === 'mine') {
      // Mes dettes : ce que JE dois aux autres
      return active.filter((d) => d.debtor_id === profile?.id)
    }
    if (tab === 'credits') {
      // Mes créances : ce que les autres ME doivent
      return active.filter((d) => d.creditor_id === profile?.id)
    }
    
    // Tout : toutes les dettes en cours
    return active
  }, [debts, tab, profile?.id])

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 16 }}>Toutes les dettes</h1>

      {/* Onglets de filtrage */}
      <div style={{ display: 'flex', gap: 6, background: '#fff', padding: 4, borderRadius: 10, marginBottom: 14, boxShadow: 'var(--shadow)' }}>
        {[
          { id: 'all' as Tab, label: 'Tout' },
          { id: 'mine' as Tab, label: 'Mes dettes' },
          { id: 'credits' as Tab, label: 'Mes créances' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              flex: 1,
              padding: '8px 0',
              border: 'none',
              borderRadius: 8,
              fontSize: 12,
              fontWeight: 700,
              background: tab === t.id ? 'var(--primary)' : 'transparent',
              color: tab === t.id ? '#fff' : 'var(--text-muted)',
              fontFamily: 'inherit',
              cursor: 'pointer',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {!loading && payGroups.map((g) => (
        <div key={g.id} className="card" style={{ marginBottom: 10, borderLeft: '4px solid var(--primary)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 2 }}><Wallet size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Tout régler avec {g.name.split(' ')[0]}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10 }}>
            {g.count} dettes · <strong className="money">{formatMoney(g.total)}</strong> en un seul paiement
          </div>
          <Link to={`/dettes/regler/${g.id}`} className="btn btn-primary" style={{ display: 'block', textAlign: 'center', textDecoration: 'none', padding: '10px', fontSize: 13 }}>
            Tout payer d'un coup
          </Link>
        </div>
      ))}

      {!loading && confirmGroups.map((g) => (
        <div key={g.id} className="card" style={{ marginBottom: 10, borderLeft: '4px solid var(--success)' }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 2 }}><CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />{g.name.split(' ')[0]} a réglé {g.count} dettes</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10 }}>
            Montant déclaré : <strong className="money">{formatMoney(g.total)}</strong>
          </div>
          <button onClick={() => confirmAll(g.id)} className="btn btn-success" style={{ width: '100%', padding: '10px', fontSize: 13 }}>
            Tout confirmer
          </button>
        </div>
      ))}

      {!loading && tab === 'all' && settlement.length > 0 && (
        <div className="card" style={{ marginBottom: 14 }}>
          <h2 style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 4 }}>Pour tout régler</h2>
          <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 8 }}>
            Le moins de paiements possible pour solder la coloc :
          </p>
          {settlement.map((t, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, padding: '6px 0', borderTop: i ? '1px dashed var(--border)' : 'none' }}>
              <span>{t.from.split(' ')[0]} → {t.to.split(' ')[0]}</span>
              <strong className="money">{formatMoney(t.amount)}</strong>
            </div>
          ))}
        </div>
      )}

      {/* Liste des dettes */}
      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      ) : filtered.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--success-text)', fontWeight: 600 }}>
          {tab === 'mine' 
            ? 'Tu ne dois rien à personne !' 
            : tab === 'credits' 
            ? 'Personne ne te doit d\'argent !' 
            : 'Aucune dette en cours dans l\'appartement !'}
        </div>
      ) : (
        filtered.map((d) => {
          const remaining = computeRemaining(d)
          const late = isLate(d, d.invoice.due_date)
          
          // On vérifie si c'est moi le débiteur ou le créancier
          const amIDebtor = d.debtor_id === profile?.id
          const amICreditor = d.creditor_id === profile?.id
          
          // Boutons d'action
          const canPay = amIDebtor && (d.status === 'pending' || d.status === 'disputed')
          const canConfirm = amICreditor && d.status === 'awaiting_confirmation'

          // Sécurisation des noms (au cas où un profil manquerait)
          const debtorName = d.debtor?.full_name || 'Inconnu'
          const creditorName = d.creditor?.full_name || 'Inconnu'

          return (
            <div
              key={d.id}
              className="card"
              style={{
                padding: 14,
                marginBottom: 8,
                borderLeft: late ? '4px solid var(--danger)' : '4px solid var(--warning)',
                background: late ? 'var(--danger-bg)' : 'var(--card)',
              }}
            >
              {/* Ligne du haut : Qui doit à qui */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: amIDebtor ? 'var(--accent)' : 'var(--primary)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12 }}>
                    {debtorName.charAt(0).toUpperCase()}
                  </div>
                  <span style={{ fontSize: 12.5, fontWeight: 700 }}>{debtorName.split(' ')[0]}</span>
                  <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>→</span>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: amICreditor ? 'var(--accent)' : 'var(--accent)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 12 }}>
                    {creditorName.charAt(0).toUpperCase()}
                  </div>
                  <span style={{ fontSize: 12.5, fontWeight: 700 }}>{creditorName.split(' ')[0]}</span>
                </div>
                <span className="money" style={{ fontSize: 15, fontWeight: 800, color: 'var(--danger-text)' }}>
                  {formatMoney(remaining)}
                </span>
              </div>

              {/* Ligne du milieu : Détails de la facture */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 10 }}>
                <span style={{ background: 'var(--primary-bg)', color: 'var(--primary)', padding: '2px 8px', borderRadius: 5, fontWeight: 600 }}>
                  {d.invoice.title}
                </span>
                {d.invoice.due_date && <span><Calendar size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />{formatDate(d.invoice.due_date)}</span>}
                {late && <span style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: '2px 8px', borderRadius: 5, fontWeight: 700 }}><AlertTriangle size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />En retard</span>}
                {d.status === 'awaiting_confirmation' && <span style={{ background: 'var(--warning-bg)', color: 'var(--warning-text)', padding: '2px 8px', borderRadius: 5, fontWeight: 700 }}>⏳ En attente</span>}
                {d.dispute_reason && d.status !== 'awaiting_confirmation' && <span style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: '2px 8px', borderRadius: 5, fontWeight: 700 }}><AlertTriangle size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Contesté : {d.dispute_reason}</span>}
              </div>

              {/* Ligne du bas : Boutons d'action */}
              {canPay && (
                <Link to={`/dettes/${d.id}/payer`} className="btn btn-primary" style={{ display: 'block', textAlign: 'center', textDecoration: 'none', padding: '10px', fontSize: 13 }}>
                  Régler ma part
                </Link>
              )}
              {canConfirm && (
                <Link to={`/dettes/${d.id}/confirmer`} className="btn btn-success" style={{ display: 'block', textAlign: 'center', textDecoration: 'none', padding: '10px', fontSize: 13 }}>
                  Confirmer la réception
                </Link>
              )}
            </div>
          )
        })
      )}
    </Layout>
  )
}
