'use client'

import { AlertTriangle, Ban, Banknote, CheckCircle2, Landmark, Lock, Smartphone } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useParams, useNavigate, Navigate } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import Layout from '@/components/Layout'
import { formatMoney } from '@/utils/format'
import { errorMessage } from '@/utils/errors'
import type { InvoiceShare, Invoice, Profile } from '@/types'

const METHODS = [
  { id: 'virement', label: 'Virement bancaire', sub: 'Vers le compte du créancier', icon: Landmark },
  { id: 'especes', label: 'Espèces', sub: 'Remise en main propre', icon: Banknote },
  { id: 'app', label: 'Application de paiement', sub: 'PayPal, Cash Plus…', icon: Smartphone },
]

type ShareData = InvoiceShare & {
  invoice: Invoice
  creditor: Pick<Profile, 'id' | 'full_name'>
}

export default function PayDebtPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()

  const [share, setShare] = useState<ShareData | null>(null)
  const [loading, setLoading] = useState(true)
  const [step, setStep] = useState<1 | 2>(1)
  const [amount, setAmount] = useState<number>(0)
  const [method, setMethod] = useState(METHODS[0])
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    supabase
      .from('invoice_shares')
      .select(`
        *,
        invoice:invoices(*),
        creditor:profiles!creditor_id(id, full_name)
      `)
      .eq('id', id)
      .single()
      .then(({ data, error }) => {
        if (error) {
          setError(error.message)
        } else if (data) {
          const s = data as unknown as ShareData
          setShare(s)
          setAmount(Math.max(0, s.amount_due - s.amount_paid))
        }
        setLoading(false)
      })
  }, [id])

  if (loading) {
    return (
      <Layout>
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement…
        </div>
      </Layout>
    )
  }

  if (!share || !user) {
    return <Navigate to="/" replace />
  }

  if (share.debtor_id !== user.id) {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center', color: 'var(--danger-text)' }}>
          <Ban size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Tu n'es pas le débiteur de cette dette.
        </div>
      </Layout>
    )
  }

  if (share.status === 'confirmed') {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 6 }}><CheckCircle2 size={44} color="var(--primary)" /></div>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginTop: 10 }}>
            Cette dette est déjà soldée
          </h2>
        </div>
      </Layout>
    )
  }

  if (share.status === 'awaiting_confirmation') {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 40 }}>⏳</div>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginTop: 10 }}>
            Paiement en attente de confirmation
          </h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 8 }}>
            {share.creditor?.full_name ?? 'Inconnu'} doit confirmer la réception.
          </p>
        </div>
      </Layout>
    )
  }

  const max = Math.max(0, share.amount_due - share.amount_paid)

  async function handleConfirm() {
    if (!share || !user) return
    setSubmitting(true)
    setError(null)

    try {
      const { error: rpcErr } = await supabase.rpc('declare_payment', {
        p_share: share.id,
        p_amount: amount,
        p_method: method.label,
      })

      if (rpcErr) throw rpcErr

      navigate('/', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Régler ma part
      </h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
        Paiement direct à {share.creditor?.full_name ?? 'Inconnu'}
      </p>

      {share.dispute_reason && (
        <div role="status" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 12, borderRadius: 10, fontSize: 12.5, marginBottom: 14, lineHeight: 1.5 }}>
          <AlertTriangle size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Ton dernier paiement a été contesté : « {share.dispute_reason} ». Tu peux le déclarer à nouveau.
        </div>
      )}

      {step === 1 && (
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ background: 'var(--surface-2)', borderRadius: 11, padding: 14, border: '1px solid var(--border)' }}>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 6 }}>
              {share.invoice.title}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, padding: '3px 0' }}>
              <span style={{ color: 'var(--text-muted)' }}>Montant total</span>
              <span className="money" style={{ fontWeight: 700 }}>{formatMoney(share.invoice.amount)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, padding: '3px 0' }}>
              <span style={{ color: 'var(--text-muted)' }}>Ta part</span>
              <span className="money" style={{ fontWeight: 700 }}>{formatMoney(share.amount_due)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '8px 0 3px', borderTop: '1px solid var(--border)', marginTop: 6 }}>
              <span style={{ fontWeight: 600 }}>Reste à payer</span>
              <span className="money" style={{ fontWeight: 800, color: 'var(--danger-text)' }}>{formatMoney(max)}</span>
            </div>
          </div>

          <div>
            <label htmlFor="amount" style={{ display: 'block', fontSize: 12.5, fontWeight: 700, marginBottom: 6, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Montant à rembourser
            </label>
            <input
              id="amount"
              type="number"
              min={0.01}
              max={max}
              step={0.01}
              value={amount}
              onChange={(e) => {
                const v = parseFloat(e.target.value) || 0
                setAmount(Math.min(max, Math.max(0, v)))
              }}
              style={{ width: '100%', padding: '14px 16px', border: '2px solid var(--primary)', borderRadius: 11, outline: 'none', fontSize: 24, fontWeight: 800 }}
            />
            <p style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 6 }}>
              Max : {formatMoney(max)}
            </p>
          </div>

          <div>
            <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, marginBottom: 8, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Mode de paiement
            </label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {METHODS.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMethod(m)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 11,
                    padding: '12px 14px',
                    border: method.id === m.id ? '2px solid var(--primary)' : '1.5px solid var(--border)',
                    borderRadius: 11,
                    background: method.id === m.id ? 'var(--primary-bg)' : '#fff',
                    textAlign: 'left',
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                  }}
                >
                  <div style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--track)', display: 'grid', placeItems: 'center', fontSize: 17, flexShrink: 0 }}>
                    <m.icon size={17} color="var(--primary)" />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 700 }}>{m.label}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{m.sub}</div>
                  </div>
                  <div
                    style={{
                      width: 18,
                      height: 18,
                      borderRadius: '50%',
                      border: method.id === m.id ? '5px solid var(--primary)' : '2px solid var(--border)',
                      background: '#fff',
                      flexShrink: 0,
                    }}
                  />
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 9, background: 'var(--primary-bg)', borderRadius: 10, padding: '11px 13px', fontSize: 12, color: 'var(--primary)', lineHeight: 1.5 }}>
            <Lock size={15} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Le montant est versé <strong>directement à {share.creditor?.full_name ?? 'Inconnu'}</strong>. Aucun partage.</span>
          </div>

          {error && (
            <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>
              {error}
            </div>
          )}

          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => navigate(-1)} className="btn btn-secondary" style={{ flex: 1 }}>
              Annuler
            </button>
            <button onClick={() => setStep(2)} className="btn btn-primary" style={{ flex: 1 }} disabled={amount <= 0 || amount > max}>
              Continuer →
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ textAlign: 'center', padding: '12px 0' }}>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              Tu vas envoyer
            </div>
            <div className="money" style={{ fontSize: 36, fontWeight: 800, color: 'var(--primary)', marginTop: 6 }}>
              {formatMoney(amount)}
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>
              à {share.creditor?.full_name ?? 'Inconnu'} · {method.label}
            </div>
          </div>

          <div style={{ background: 'var(--surface-2)', borderRadius: 11, padding: 14, border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, padding: '4px 0' }}>
              <span style={{ color: 'var(--text-muted)' }}>Facture</span>
              <span style={{ fontWeight: 600 }}>{share.invoice.title}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, padding: '4px 0' }}>
              <span style={{ color: 'var(--text-muted)' }}>Créancier</span>
              <span style={{ fontWeight: 600 }}>{share.creditor?.full_name ?? 'Inconnu'}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '8px 0 3px', borderTop: '1px solid var(--border)', marginTop: 6 }}>
              <span style={{ fontWeight: 600 }}>Montant envoyé</span>
              <span className="money" style={{ fontWeight: 800, color: 'var(--danger-text)' }}>{formatMoney(amount)}</span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 9, background: 'var(--warning-bg)', borderRadius: 10, padding: '11px 13px', fontSize: 12, color: 'var(--warning-text)', lineHeight: 1.5 }}>
            <AlertTriangle size={15} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>{share.creditor?.full_name ?? 'Inconnu'} recevra une notification et devra confirmer la réception.</span>
          </div>

          {error && (
            <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>
              {error}
            </div>
          )}

          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setStep(1)} className="btn btn-secondary" style={{ flex: 1 }} disabled={submitting}>
              ← Modifier
            </button>
            <button onClick={handleConfirm} className="btn btn-primary" style={{ flex: 1 }} disabled={submitting}>
              {submitting ? 'Envoi…' : 'Confirmer le paiement'}
            </button>
          </div>
        </div>
      )}
    </Layout>
  )
}
