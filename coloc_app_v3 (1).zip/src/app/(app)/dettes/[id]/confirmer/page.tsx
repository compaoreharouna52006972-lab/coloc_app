'use client'

import { Ban, CheckCircle2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useParams, useNavigate, Navigate } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from '@/contexts/ToastContext'
import Layout from '@/components/Layout'
import { formatMoney } from '@/utils/format'
import { errorMessage } from '@/utils/errors'
import type { InvoiceShare, Invoice, Profile } from '@/types'

type ShareData = InvoiceShare & {
  invoice: Invoice
  debtor: Pick<Profile, 'id' | 'full_name'> | null
}

export default function ConfirmPaymentPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { toast } = useToast()

  const [share, setShare] = useState<ShareData | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [disputing, setDisputing] = useState(false)
  const [reason, setReason] = useState('')

  useEffect(() => {
    if (!id) return
    supabase
      .from('invoice_shares')
      .select(`*, invoice:invoices(*), debtor:profiles!debtor_id(id, full_name)`)
      .eq('id', id)
      .single()
      .then(({ data, error }) => {
        if (error) setError(error.message)
        else if (data) setShare(data as unknown as ShareData)
        setLoading(false)
      })
  }, [id])

  if (loading) {
    return (
      <Layout>
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      </Layout>
    )
  }

  if (!share || !user) {
    return <Navigate to="/dettes" replace />
  }

  if (share.creditor_id !== user.id) {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center', color: 'var(--danger-text)' }}><Ban size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Tu n'es pas le créancier de cette dette.</div>
      </Layout>
    )
  }

  if (share.status === 'confirmed') {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 6 }}><CheckCircle2 size={44} color="var(--primary)" /></div>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginTop: 10 }}>Déjà confirmé</h2>
          {share.confirmed_at && (
            <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>
              Cette dette est soldée depuis le {new Date(share.confirmed_at).toLocaleDateString('fr-FR')}.
            </p>
          )}
        </div>
      </Layout>
    )
  }

  if (share.status !== 'awaiting_confirmation') {
    return (
      <Layout>
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>⏳ Aucun paiement en attente de confirmation pour cette dette.</div>
      </Layout>
    )
  }

  const declared = (share.pending_amount ?? 0) > 0 ? share.pending_amount : share.amount_paid
  const debtorName = share.debtor?.full_name ?? 'Un colocataire'

  async function act(fn: () => PromiseLike<{ error: { message: string } | null }>, okMsg: string) {
    setSubmitting(true)
    setError(null)
    try {
      const { error: rpcErr } = await fn()
      if (rpcErr) throw rpcErr
      toast(okMsg, 'success')
      navigate('/dettes', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setSubmitting(false)
    }
  }

  const handleConfirm = () => act(() => supabase.rpc('confirm_payment', { p_share: share.id }), 'Réception confirmée')
  const handleDispute = () =>
    act(() => supabase.rpc('dispute_payment', { p_share: share.id, p_reason: reason }), 'Paiement contesté')

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Confirmer la réception</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>{debtorName} dit t'avoir envoyé un paiement</p>

      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--primary)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 14 }}>
              {debtorName.charAt(0).toUpperCase()}
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 700 }}>{debtorName}</div>
              <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{share.invoice.title}</div>
            </div>
          </div>
          <div className="money" style={{ fontSize: 20, fontWeight: 800, color: 'var(--success-text)' }}>{formatMoney(declared)}</div>
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {share.payment_method && (
            <span style={{ background: 'var(--primary-bg)', color: 'var(--primary)', padding: '3px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600 }}>{share.payment_method}</span>
          )}
          <span style={{ background: 'var(--warning-bg)', color: 'var(--warning-text)', padding: '3px 9px', borderRadius: 6, fontSize: 11, fontWeight: 700 }}>⏳ En attente</span>
        </div>
      </div>

      <div className="card" style={{ background: 'var(--success-bg)', borderLeft: '4px solid var(--success)' }}>
        <h3 style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--success-text)', marginBottom: 6 }}>Confirmer la réception ?</h3>
        <p style={{ fontSize: 12.5, color: 'var(--success-text)', lineHeight: 1.5, marginBottom: 12 }}>
          En confirmant, tu attestes avoir bien reçu {formatMoney(declared)}. Si la part n'est pas entièrement payée, le reste dû est conservé.
        </p>

        {disputing && (
          <div style={{ marginBottom: 12 }}>
            <label htmlFor="reason" style={{ display: 'block', fontSize: 12.5, fontWeight: 700, marginBottom: 6, color: 'var(--text)' }}>Motif de la contestation</label>
            <textarea id="reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ex : je n'ai rien reçu…" style={{ width: '100%', padding: '10px 12px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none', fontFamily: 'inherit', resize: 'none' }} />
          </div>
        )}

        {error && (
          <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5, marginBottom: 10 }}>{error}</div>
        )}

        {disputing ? (
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setDisputing(false)} className="btn btn-secondary" style={{ flex: 1 }} disabled={submitting}>Retour</button>
            <button onClick={handleDispute} className="btn btn-danger" style={{ flex: 2 }} disabled={submitting}>{submitting ? 'Envoi…' : 'Envoyer la contestation'}</button>
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setDisputing(true)} className="btn btn-danger" style={{ flex: 1 }} disabled={submitting}>Contester</button>
            <button onClick={handleConfirm} className="btn btn-success" style={{ flex: 2 }} disabled={submitting}>{submitting ? 'Confirmation…' : 'Oui, confirmer la réception'}</button>
          </div>
        )}
      </div>
    </Layout>
  )
}
