'use client'

import { useState, type FormEvent } from 'react'
import { useNavigate } from '@/lib/router'
import Layout from '@/components/Layout'
import { useEquipments, EQUIPMENT_STATUS } from '@/hooks/useEquipments'
import type { Equipment } from '@/types'

const CATEGORIES = [
  { value: 'electromenager', label: 'Électroménager' },
  { value: 'mobilier', label: 'Mobilier' },
  { value: 'vaisselle', label: 'Vaisselle' },
  { value: 'autre', label: 'Autre' },
]

export default function NewEquipmentPage() {
  const navigate = useNavigate()
  const { createEquipment } = useEquipments()

  const [name, setName] = useState('')
  const [category, setCategory] = useState('electromenager')
  const [status, setStatus] = useState<Equipment['status']>('good')
  const [location, setLocation] = useState('')
  const [price, setPrice] = useState('')
  const [purchaseDate, setPurchaseDate] = useState('')
  const [photo, setPhoto] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await createEquipment({
        name: name.trim(),
        category,
        status,
        location: location.trim() || undefined,
        purchase_price: price ? parseFloat(price) : undefined,
        purchase_date: purchaseDate || undefined,
        photo,
      })
      navigate('/inventaire', { replace: true })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 16 }}>Nouvel équipement
      </h1>

      <form onSubmit={handleSubmit} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <label htmlFor="name" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Nom</label>
          <input
            id="name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex : Réfrigérateur"
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="category" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Catégorie</label>
          <select
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none', background: '#fff' }}
          >
            {CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>État</label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value as Equipment['status'])}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none', background: '#fff' }}
          >
            {Object.entries(EQUIPMENT_STATUS).map(([key, val]) => (
              <option key={key} value={key}>{val.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="location" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Emplacement (optionnel)</label>
          <input
            id="location"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Ex : Cuisine"
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="price" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Prix d'achat (DH, optionnel)</label>
          <input
            id="price"
            type="number"
            min="0"
            step="0.01"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="Ex : 3500"
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="purchaseDate" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Date d'achat (optionnel)</label>
          <input
            id="purchaseDate"
            type="date"
            value={purchaseDate}
            onChange={(e) => setPurchaseDate(e.target.value)}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="photo" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Photo (optionnel)</label>
          <input
            id="photo"
            type="file"
            accept="image/*"
            onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
            style={{ width: '100%', fontSize: 12 }}
          />
        </div>

        {error && (
          <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>
            {error}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <button type="button" onClick={() => navigate(-1)} className="btn btn-secondary" style={{ flex: 1 }}>Annuler</button>
          <button type="submit" className="btn btn-primary" disabled={loading || name.trim().length < 2} style={{ flex: 1 }}>
            {loading ? 'Ajout…' : 'Ajouter'}
          </button>
        </div>
      </form>
    </Layout>
  )
}
