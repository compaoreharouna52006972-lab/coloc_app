'use client'

import { Trash2 } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link } from '@/lib/router'
import Layout from '@/components/Layout'
import { useEquipments, EQUIPMENT_STATUS } from '@/hooks/useEquipments'
import { formatMoney } from '@/utils/format'
import SignedImage from '@/components/SignedImage'
import { useToast } from '@/contexts/ToastContext'
import { errorMessage } from '@/utils/errors'
import type { Equipment } from '@/types'
import { EquipmentIcon, StatusDot } from '@/components/icons'

type Filter = 'all' | Equipment['status']

export default function InventoryPage() {
  const { equipments, loading, updateStatus, deleteEquipment } = useEquipments()
  const { toast } = useToast()
  const [filter, setFilter] = useState<Filter>('all')

  const filtered = useMemo(() => {
    if (filter === 'all') return equipments
    return equipments.filter((e) => e.status === filter)
  }, [equipments, filter])

  const counts = useMemo(
    () => ({
      good: equipments.filter((e) => e.status === 'good').length,
      to_repair: equipments.filter((e) => e.status === 'to_repair').length,
      broken: equipments.filter((e) => e.status === 'broken').length,
    }),
    [equipments]
  )

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Supprimer "${name}" de l'inventaire ?`)) return
    try {
      await deleteEquipment(id)
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  return (
    <Layout>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <h1 className="page-title">Inventaire</h1>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>
            Équipements communs
          </p>
        </div>
        <Link
          to="/inventaire/nouveau"
          className="btn btn-primary"
          style={{ padding: '10px 14px', textDecoration: 'none', fontSize: 12.5 }}
        >
          + Ajouter
        </Link>
      </div>

      {/* Stats rapides */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        <div className="card" style={{ flex: 1, padding: 11, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--success-text)' }}>{counts.good}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginTop: 2 }}>Bon état</div>
        </div>
        <div className="card" style={{ flex: 1, padding: 11, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--warning-text)' }}>{counts.to_repair}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginTop: 2 }}>À réparer</div>
        </div>
        <div className="card" style={{ flex: 1, padding: 11, textAlign: 'center' }}>
          <div style={{ fontSize: 20, fontWeight: 800, color: 'var(--danger-text)' }}>{counts.broken}</div>
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', fontWeight: 700, marginTop: 2 }}>Hors service</div>
        </div>
      </div>

      {/* Filtres */}
      <div style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 6, marginBottom: 14 }}>
        {[
          { id: 'all' as Filter, label: 'Tous' },
          { id: 'good' as Filter, label: 'Bon' },
          { id: 'to_repair' as Filter, label: 'À réparer' },
          { id: 'broken' as Filter, label: 'HS' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            style={{
              background: filter === f.id ? 'var(--primary)' : '#fff',
              color: filter === f.id ? '#fff' : 'var(--text-muted)',
              border: '1.5px solid ' + (filter === f.id ? 'var(--primary)' : 'var(--border)'),
              padding: '6px 12px',
              borderRadius: 99,
              fontSize: 11.5,
              fontWeight: 600,
              whiteSpace: 'nowrap',
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement…
        </div>
      ) : filtered.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
          Aucun équipement {filter !== 'all' ? 'dans cette catégorie' : 'pour l\'instant'}.
        </div>
      ) : (
        filtered.map((eq) => {
          const status = EQUIPMENT_STATUS[eq.status]
          return (
            <div key={eq.id} className="card" style={{ marginBottom: 8, padding: 13 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                <div
                  style={{
                    width: 48,
                    height: 48,
                    borderRadius: 10,
                    background: 'var(--primary-bg)',
                    display: 'grid',
                    placeItems: 'center',
                    fontSize: 22,
                    overflow: 'hidden',
                    flexShrink: 0,
                  }}
                >
                  {eq.photo_path ? <SignedImage path={eq.photo_path} alt={eq.name} fallback={<EquipmentIcon category={eq.category} />} /> : <EquipmentIcon category={eq.category} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700 }}>{eq.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                    {eq.location || '—'}
                    {eq.purchase_price ? ` · ${formatMoney(eq.purchase_price)}` : ''}
                  </div>
                  <span
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 6,
                      marginTop: 4,
                      fontSize: 10.5,
                      fontWeight: 700,
                      color: status.color,
                    }}
                  >
                    <StatusDot color={status.dot} /> {status.label}
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                <select
                  value={eq.status}
                  onChange={(e) => updateStatus(eq.id, e.target.value as Equipment['status']).catch((err) => toast(errorMessage(err), 'error'))}
                  style={{
                    flex: 1,
                    padding: '7px 10px',
                    border: '1.5px solid var(--border)',
                    borderRadius: 8,
                    fontSize: 11.5,
                    fontFamily: 'inherit',
                    background: '#fff',
                  }}
                >
                  {Object.entries(EQUIPMENT_STATUS).map(([key, val]) => (
                    <option key={key} value={key}>
                      {val.label}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => handleDelete(eq.id, eq.name)}
                  style={{
                    background: 'var(--danger-bg)',
                    color: 'var(--danger-text)',
                    border: 'none',
                    padding: '7px 12px',
                    borderRadius: 8,
                    fontSize: 11.5,
                    fontWeight: 700,
                    cursor: 'pointer',
                    fontFamily: 'inherit',
                  }}
                ><Trash2 size={15} /></button>
              </div>
            </div>
          )
        })
      )}
    </Layout>
  )
}
