'use client'

import { Pencil, Send, Trash2 } from 'lucide-react'
import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { useToast } from '@/contexts/ToastContext'
import { useMessages } from '@/hooks/useMessages'
import Layout from '@/components/Layout'
import { formatRelative } from '@/utils/format'
import { errorMessage } from '@/utils/errors'

export default function ChatPage() {
  const { user } = useAuth()
  const { apartment, member } = useApartment()
  const { toast } = useToast()
  const { messages, loading, sendMessage, editMessage, deleteMessage } = useMessages()
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editText, setEditText] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)
  const isAdmin = member?.role === 'admin'

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!input.trim()) return
    setError(null)
    setSending(true)
    try {
      await sendMessage(input)
      setInput('')
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setSending(false)
    }
  }

  async function saveEdit(id: string) {
    if (!editText.trim()) return
    try {
      await editMessage(id, editText)
      setEditingId(null)
      setSelectedId(null)
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  async function remove(id: string) {
    if (!confirm('Supprimer ce message pour tout le monde ?')) return
    try {
      await deleteMessage(id)
      setSelectedId(null)
      toast('Message supprimé', 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  return (
    <Layout>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <h1 className="page-title">Messagerie</h1>
          <p style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 2 }}>{apartment?.name}</p>
        </div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: 'var(--success-bg)', color: 'var(--success-text)', padding: '4px 9px', borderRadius: 99, fontSize: 11, fontWeight: 700 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--success)' }} />
          En direct
        </span>
      </div>

      <div
        style={{
          background: 'var(--surface-2)', borderRadius: 12, padding: 14, height: 'calc(100vh - 320px)', minHeight: 340,
          overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 12,
        }}
      >
        {loading ? (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 20 }}>Chargement…</div>
        ) : messages.length === 0 ? (
          <div style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 20, fontSize: 13 }}>
            Aucun message pour l'instant.<br />Envoie le premier !
          </div>
        ) : (
          messages.map((m) => {
            const isMine = m.sender_id === user?.id
            const canAct = isMine || isAdmin
            const selected = selectedId === m.id
            const editing = editingId === m.id
            return (
              <div
                key={m.id}
                style={{
                  display: 'flex', gap: 8, alignItems: 'flex-end', maxWidth: '85%',
                  alignSelf: isMine ? 'flex-end' : 'flex-start', flexDirection: isMine ? 'row-reverse' : 'row',
                }}
              >
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: isMine ? 'var(--accent)' : 'var(--primary)', color: '#fff', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0 }}>
                  {(m.sender?.full_name ?? 'Inconnu').charAt(0).toUpperCase()}
                </div>
                <div style={{ minWidth: 0 }}>
                  <div
                    onClick={() => canAct && !editing && setSelectedId(selected ? null : m.id)}
                    style={{
                      background: isMine ? 'linear-gradient(135deg, var(--primary), var(--primary-light))' : '#fff',
                      color: isMine ? '#fff' : 'var(--text)', borderRadius: 14, padding: '9px 12px',
                      boxShadow: '0 1px 2px rgba(0,0,0,.06)', fontSize: 13, lineHeight: 1.4, cursor: canAct ? 'pointer' : 'default',
                    }}
                  >
                    {!isMine && (
                      <div style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--primary)', marginBottom: 2 }}>
                        {(m.sender?.full_name ?? 'Inconnu').split(' ')[0]}
                      </div>
                    )}

                    {editing ? (
                      <div onClick={(e) => e.stopPropagation()}>
                        <textarea
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          rows={3}
                          autoFocus
                          style={{ width: '100%', borderRadius: 8, border: 'none', padding: 8, fontFamily: 'inherit', fontSize: 13, resize: 'none', color: 'var(--text)' }}
                        />
                        <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                          <button onClick={() => setEditingId(null)} style={{ flex: 1, padding: '6px', borderRadius: 8, border: 'none', fontSize: 12, cursor: 'pointer' }}>Annuler</button>
                          <button onClick={() => saveEdit(m.id)} disabled={!editText.trim()} style={{ flex: 1, padding: '6px', borderRadius: 8, border: 'none', fontSize: 12, fontWeight: 700, background: 'var(--success)', color: '#fff', cursor: 'pointer' }}>Enregistrer</button>
                        </div>
                      </div>
                    ) : (
                      <div style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{m.content}</div>
                    )}

                    <div style={{ fontSize: 9.5, marginTop: 3, textAlign: 'right', color: isMine ? 'rgba(255,255,255,.6)' : 'var(--text-muted)' }}>
                      {m.edited_at && 'modifié · '}
                      {formatRelative(m.created_at)}
                    </div>
                  </div>

                  {selected && !editing && (
                    <div style={{ display: 'flex', gap: 6, marginTop: 4, justifyContent: isMine ? 'flex-end' : 'flex-start' }}>
                      {isMine && (
                        <button
                          onClick={() => { setEditingId(m.id); setEditText(m.content); setSelectedId(null) }}
                          style={{ background: 'var(--primary-bg)', color: 'var(--primary)', border: 'none', padding: '5px 10px', borderRadius: 8, fontSize: 11.5, fontWeight: 700, cursor: 'pointer' }}
                        >
                          <Pencil size={13} style={{ verticalAlign: '-2px', marginRight: 6 }} />Modifier
                        </button>
                      )}
                      <button
                        onClick={() => remove(m.id)}
                        style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', border: 'none', padding: '5px 10px', borderRadius: 8, fontSize: 11.5, fontWeight: 700, cursor: 'pointer' }}
                      >
                        <Trash2 size={13} style={{ verticalAlign: '-2px', marginRight: 6 }} />Supprimer
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )
          })
        )}
        <div ref={bottomRef} />
      </div>

      {error && (
        <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5, marginBottom: 8 }}>{error}</div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#fff', borderRadius: 12, padding: 6, boxShadow: 'var(--shadow)' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Écrire un message…"
          style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', padding: '10px 12px', fontSize: 14, fontFamily: 'inherit' }}
        />
        <button
          type="submit"
          disabled={sending || !input.trim()}
          aria-label="Envoyer"
          style={{
            width: 40, height: 40, borderRadius: '50%', background: 'linear-gradient(135deg, var(--primary), var(--primary-light))', color: '#fff',
            border: 'none', display: 'grid', placeItems: 'center', fontSize: 16,
            cursor: sending || !input.trim() ? 'not-allowed' : 'pointer', opacity: sending || !input.trim() ? 0.5 : 1,
          }}
        >
          <Send size={18} />
        </button>
      </form>
    </Layout>
  )
}
