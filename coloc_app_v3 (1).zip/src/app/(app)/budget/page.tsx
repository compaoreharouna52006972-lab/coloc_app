'use client'

import { AlertOctagon, AlertTriangle, X } from 'lucide-react'
import { useMemo, useState } from 'react'
import Layout from '@/components/Layout'
import { CategoryIcon } from '@/components/icons'
import { useBudget, CATEGORY_META } from '@/hooks/useBudget'
import { formatMoney } from '@/utils/format'
import { useToast } from '@/contexts/ToastContext'
import { errorMessage } from '@/utils/errors'

export default function BudgetPage() {
  const { lines, loading, upsertPlanned } = useBudget()
  const { toast } = useToast()
  const [editing, setEditing] = useState<string | null>(null)
  const [editValue, setEditValue] = useState('')

  const totalPlanned = useMemo(() => lines.reduce((s, l) => s + l.planned, 0), [lines])
  const totalActual = useMemo(() => lines.reduce((s, l) => s + l.actual, 0), [lines])
  const globalPercent =
    totalPlanned > 0 ? Math.round((totalActual / totalPlanned) * 100) : 0

  async function saveEdit(category: string) {
    const v = parseFloat(editValue)
    if (isNaN(v) || v < 0) {
      setEditing(null)
      return
    }
    try {
      await upsertPlanned(category, v)
      toast('Budget enregistré', 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
    setEditing(null)
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Budget du mois
      </h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
        {new Date().toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}
      </p>

      {/* KPI global */}
      <div
        className="card"
        style={{
          background: 'linear-gradient(135deg, var(--primary), var(--primary-light))',
          color: '#fff',
          marginBottom: 16,
        }}
      >
        <div style={{ fontSize: 11, opacity: 0.8, textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 700 }}>
          Total consommé
        </div>
        <div className="money" style={{ fontSize: 26, fontWeight: 800, marginTop: 6 }}>
          {formatMoney(totalActual)}{' '}
          <span style={{ fontSize: 14, opacity: 0.7, fontWeight: 500 }}>
            / {formatMoney(totalPlanned)}
          </span>
        </div>
        <div
          style={{
            height: 8,
            background: 'rgba(255,255,255,.2)',
            borderRadius: 99,
            overflow: 'hidden',
            marginTop: 12,
          }}
        >
          <div
            style={{
              height: '100%',
              width: `${Math.min(100, globalPercent)}%`,
              background: '#fff',
              borderRadius: 99,
            }}
          />
        </div>
        <div style={{ fontSize: 11.5, opacity: 0.8, marginTop: 8, display: 'flex', justifyContent: 'space-between' }}>
          <span>{globalPercent} % du budget</span>
          <span>
            Reste {formatMoney(Math.max(0, totalPlanned - totalActual))}
          </span>
        </div>
      </div>

      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
          Chargement…
        </div>
      ) : (
        lines.map((line) => {
          const meta = CATEGORY_META[line.category]
          const percent =
            line.planned > 0
              ? Math.round((line.actual / line.planned) * 100)
              : line.actual > 0
              ? 100
              : 0
          const isOver = line.planned > 0 && line.actual > line.planned
          const isWarn = !isOver && percent >= 80

          const barColor = isOver
            ? 'var(--danger)'
            : isWarn
            ? 'var(--warning)'
            : 'var(--success)'

          return (
            <div key={line.category} className="card" style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div style={{ fontSize: 13.5, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <CategoryIcon category={line.category} size={16} /> {meta.label}
                </div>
                <div className="money" style={{ fontSize: 12.5, fontWeight: 700, color: barColor }}>
                  {formatMoney(line.actual)}
                  {line.planned > 0 && (
                    <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>
                      {' '} / {formatMoney(line.planned)}
                    </span>
                  )}
                </div>
              </div>

              <div style={{ height: 7, background: 'var(--track)', borderRadius: 99, overflow: 'hidden' }}>
                <div
                  style={{
                    height: '100%',
                    width: `${Math.min(100, percent)}%`,
                    background: barColor,
                    borderRadius: 99,
                  }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                  {line.planned > 0 ? `${percent} %` : 'Aucun budget défini'}
                </span>
                <button
                  onClick={() => {
                    setEditing(line.category)
                    setEditValue(String(line.planned || ''))
                  }}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--primary)',
                    fontSize: 11.5,
                    fontWeight: 700,
                    padding: 4,
                    minHeight: 'auto',
                    cursor: 'pointer',
                  }}
                >
                  {line.planned > 0 ? 'Modifier' : 'Définir'}
                </button>
              </div>

              {isWarn && (
                <div style={{ marginTop: 6, background: 'var(--warning-bg)', color: 'var(--warning-text)', padding: '4px 9px', borderRadius: 6, fontSize: 10.5, fontWeight: 700, display: 'inline-block' }}>
                  <AlertTriangle size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Seuil 80 % atteint
                </div>
              )}
              {isOver && (
                <div style={{ marginTop: 6, background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: '4px 9px', borderRadius: 6, fontSize: 10.5, fontWeight: 700, display: 'inline-block' }}>
                  <AlertOctagon size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Plafond dépassé (+{formatMoney(line.actual - line.planned)})
                </div>
              )}

              {editing === line.category && (
                <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
                  <input
                    type="number"
                    min={0}
                    step={1}
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    placeholder="Montant prévu"
                    style={{ flex: 1, padding: '10px 12px', border: '1.5px solid var(--border)', borderRadius: 9, outline: 'none' }}
                    autoFocus
                  />
                  <button onClick={() => saveEdit(line.category)} className="btn btn-primary" style={{ padding: '10px 14px', minHeight: 'auto', fontSize: 12 }}>
                    OK
                  </button>
                  <button onClick={() => setEditing(null)} className="btn btn-secondary" style={{ padding: '10px 14px', minHeight: 'auto', fontSize: 12 }}>
                    <X size={16} />
                  </button>
                </div>
              )}
            </div>
          )
        })
      )}
    </Layout>
  )
}
