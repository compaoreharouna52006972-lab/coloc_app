'use client'

import { AlertTriangle, Calendar, Check, CheckCircle2, Trash2 } from 'lucide-react'
import { useMemo } from 'react'
import { Link } from '@/lib/router'
import Layout from '@/components/Layout'
import CleaningCard from '@/components/CleaningCard'
import { useTasks } from '@/hooks/useTasks'
import { formatDate, todayMA } from '@/utils/format'
import { useToast } from '@/contexts/ToastContext'
import { errorMessage } from '@/utils/errors'

export default function TasksPage() {
  const { tasks, loading, markDone, postpone, resume, deleteTask } = useTasks()
  const { toast } = useToast()

  async function run(action: () => Promise<void>, ok: string) {
    try {
      await action()
      toast(ok, 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  const active = useMemo(() => tasks.filter((t) => t.status === 'pending'), [tasks])
  const done = useMemo(() => tasks.filter((t) => t.status === 'done'), [tasks])
  const postponed = useMemo(() => tasks.filter((t) => t.status === 'postponed'), [tasks])

  return (
    <Layout>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div>
          <h1 className="page-title">Tâches</h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>
            Grand nettoyage en rotation · tâches de la coloc
          </p>
        </div>
        <Link
          to="/taches/nouvelle"
          className="btn btn-primary"
          style={{ padding: '10px 14px', textDecoration: 'none', fontSize: 12.5 }}
        >
          + Tâche
        </Link>
      </div>

      {/* Grand nettoyage : rotation automatique */}
      <CleaningCard />

      {/* Tâches en cours */}
      <div style={{ marginBottom: 14 }}>
        <h2 style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
          ⏳ En cours ({active.length})
        </h2>

        {loading ? (
          <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
            Chargement…
          </div>
        ) : active.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', color: 'var(--success-text)', fontWeight: 600 }}>
            <CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Aucune tâche en cours
          </div>
        ) : (
          active.map((t) => {
            const late = !!t.due_date && t.due_date.slice(0, 10) < todayMA()
            return (
              <div
                key={t.id}
                className="card"
                style={{
                  marginBottom: 8,
                  borderLeft: late ? '4px solid var(--danger)' : '4px solid var(--warning)',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700, flex: 1 }}>{t.title}</div>
                  {t.due_date && (
                    <span
                      style={{
                        background: late ? 'var(--danger-bg)' : 'var(--warning-bg)',
                        color: late ? 'var(--danger-text)' : 'var(--warning-text)',
                        padding: '2px 8px',
                        borderRadius: 5,
                        fontSize: 10.5,
                        fontWeight: 700,
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {late ? <AlertTriangle size={12} style={{ verticalAlign: '-2px', marginRight: 4 }} /> : <Calendar size={12} style={{ verticalAlign: '-2px', marginRight: 4 }} />}{formatDate(t.due_date)}
                    </span>
                  )}
                </div>

                {t.description && (
                  <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>
                    {t.description}
                  </p>
                )}

                <div style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 11.5, color: 'var(--text-muted)', marginBottom: 10 }}>
                  {t.assignee ? (
                    <>
                      <div
                        style={{
                          width: 24,
                          height: 24,
                          borderRadius: '50%',
                          background: 'var(--avatar-4)',
                          color: '#fff',
                          display: 'grid',
                          placeItems: 'center',
                          fontSize: 10,
                          fontWeight: 700,
                        }}
                      >
                        {t.assignee.full_name.charAt(0).toUpperCase()}
                      </div>
                      <span>{t.assignee.full_name}</span>
                    </>
                  ) : (
                    <span>Non assignée</span>
                  )}
                </div>

                <div style={{ display: 'flex', gap: 8 }}>
                  <button
                    onClick={() => run(() => postpone(t.id), 'Tâche reportée')}
                    className="btn btn-secondary"
                    style={{ flex: 1, padding: '8px', fontSize: 11.5 }}
                  >
                    Reporter
                  </button>
                  <button
                    onClick={() => run(() => markDone(t.id), 'Tâche terminée')}
                    className="btn btn-success"
                    style={{ flex: 1, padding: '8px', fontSize: 11.5 }}
                  >
                    <Check size={14} /> Fait
                  </button>
                </div>
              </div>
            )
          })
        )}
      </div>

      {/* Reportées */}
      {postponed.length > 0 && (
        <div style={{ marginBottom: 14 }}>
          <h2 style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
            ⏭️ Reportées ({postponed.length})
          </h2>
          {postponed.map((t) => (
            <div key={t.id} className="card" style={{ marginBottom: 8, borderLeft: '4px solid var(--border)', opacity: 0.75 }}>
              <div style={{ fontSize: 13, fontWeight: 700 }}>{t.title}</div>
              {t.assignee && (
                <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 4 }}>
                  Reportée par {t.assignee.full_name}
                </div>
              )}
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button onClick={() => run(() => resume(t.id), 'Tâche reprise')} className="btn btn-secondary" style={{ flex: 1, padding: '8px', fontSize: 11.5 }}>
                  ↩ Reprendre
                </button>
                <button
                  onClick={() => { if (confirm(`Supprimer « ${t.title} » ?`)) run(() => deleteTask(t.id), 'Tâche supprimée') }}
                  className="btn btn-danger"
                  style={{ padding: '8px 12px', fontSize: 11.5 }}
                  aria-label="Supprimer la tâche"
                ><Trash2 size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Terminées */}
      {done.length > 0 && (
        <div>
          <h2 style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Terminées ({done.length})
          </h2>
          {done.slice(0, 5).map((t) => (
            <div key={t.id} className="card" style={{ marginBottom: 8, borderLeft: '4px solid var(--success)', opacity: 0.7 }}>
              <div style={{ fontSize: 13, fontWeight: 700, textDecoration: 'line-through' }}>{t.title}</div>
              {t.assignee && (
                <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 4 }}>
                  Terminée par {t.assignee.full_name}
                </div>
              )}
              <button onClick={() => run(() => resume(t.id), 'Tâche rouverte')} className="btn btn-secondary" style={{ marginTop: 10, padding: '6px 10px', fontSize: 11 }}>
                ↩ Rouvrir
              </button>
            </div>
          ))}
        </div>
      )}
    </Layout>
  )
}
