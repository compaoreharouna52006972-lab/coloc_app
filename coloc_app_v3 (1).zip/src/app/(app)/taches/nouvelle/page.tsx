'use client'

import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useApartment } from '@/contexts/ApartmentContext'
import { useTasks } from '@/hooks/useTasks'
import Layout from '@/components/Layout'
import type { Profile } from '@/types'

export default function NewTaskPage() {
  const navigate = useNavigate()
  const { apartment } = useApartment()
  const { createTask } = useTasks()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [assignedTo, setAssignedTo] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [members, setMembers] = useState<Pick<Profile, 'id' | 'full_name'>[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!apartment) return
    supabase
      .from('members')
      .select('user_id, profiles(id, full_name)')
      .eq('apartment_id', apartment.id)
      .eq('is_active', true)
      .then(({ data }) => {
        if (!data) return
        const list = data
          .map((m) => m.profiles as unknown as Pick<Profile, 'id' | 'full_name'>)
          .filter(Boolean)
        setMembers(list)
      })
  }, [apartment])

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await createTask({
        title: title.trim(),
        description: description.trim() || undefined,
        assigned_to: assignedTo || null,
        due_date: dueDate || null,
      })
      navigate('/taches', { replace: true })
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  if (!apartment) return null

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 16 }}>Nouvelle tâche
      </h1>

      <form onSubmit={handleSubmit} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <label htmlFor="title" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
            Titre
          </label>
          <input
            id="title"
            type="text"
            required
            minLength={2}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Ex : Recharge gaz"
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="desc" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
            Description (optionnel)
          </label>
          <textarea
            id="desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Détails…"
            rows={3}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none', fontFamily: 'inherit', resize: 'none' }}
          />
        </div>

        <div>
          <label htmlFor="assign" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
            Assignée à
          </label>
          <select
            id="assign"
            value={assignedTo}
            onChange={(e) => setAssignedTo(e.target.value)}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none', background: '#fff' }}
          >
            <option value="">Personne (non assignée)</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.full_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="due" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
            Échéance (optionnel)
          </label>
          <input
            id="due"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
            style={{ width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' }}
          />
        </div>

        {error && (
          <div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>
            {error}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <button type="button" onClick={() => navigate(-1)} className="btn btn-secondary" style={{ flex: 1 }}>
            Annuler
          </button>
          <button type="submit" className="btn btn-primary" disabled={loading || title.trim().length < 2} style={{ flex: 1 }}>
            {loading ? 'Création…' : 'Créer'}
          </button>
        </div>
      </form>
    </Layout>
  )
}
