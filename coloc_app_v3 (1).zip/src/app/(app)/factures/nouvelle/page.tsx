'use client'

import { Lightbulb, Lock, PlaneTakeoff } from 'lucide-react'
import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from '@/lib/router'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { useToast } from '@/contexts/ToastContext'
import { useMembers } from '@/hooks/useMembers'
import { useAbsences } from '@/hooks/useAbsences'
import Layout from '@/components/Layout'
import { formatMoney } from '@/utils/format'
import { errorMessage } from '@/utils/errors'
import { computeShares, previousMonthRange } from '@/utils/presence'
import type { Invoice } from '@/types'

const CATEGORIES = [
  { value: 'loyer', label: 'Loyer' },
  { value: 'electricite', label: 'Électricité' },
  { value: 'eau', label: 'Eau' },
  { value: 'wifi', label: 'WiFi' },
  { value: 'courses', label: 'Courses' },
  { value: 'gaz', label: 'Gaz' },
  { value: 'autre', label: 'Autre' },
] as const

type Category = (typeof CATEGORIES)[number]['value']

const inputStyle = { width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' } as const
const labelStyle = { display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 } as const

export default function NewInvoicePage() {
  const { id: editId } = useParams<{ id: string }>()
  const isEdit = Boolean(editId)
  const navigate = useNavigate()
  const { user } = useAuth()
  const { apartment } = useApartment()
  const { members, loading: membersLoading } = useMembers()
  const { absences } = useAbsences()
  const { toast } = useToast()

  const defaults = useMemo(() => previousMonthRange(), [])
  const [title, setTitle] = useState('')
  const [amount, setAmount] = useState('')
  const [category, setCategory] = useState<Category>('electricite')
  const [dueDate, setDueDate] = useState('')
  const [periodStart, setPeriodStart] = useState(defaults.start)
  const [periodEnd, setPeriodEnd] = useState(defaults.end)
  const [receipt, setReceipt] = useState<File | null>(null)
  const [existingReceipt, setExistingReceipt] = useState<string | null>(null)
  const [payerId, setPayerId] = useState<string | null>(null)
  // null = tout le monde (création) ; sinon la liste explicite des participants
  const [included, setIncluded] = useState<Set<string> | null>(null)
  const [locked, setLocked] = useState(false)
  const [loadingInvoice, setLoadingInvoice] = useState(isEdit)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Chargement de la facture à modifier
  useEffect(() => {
    if (!editId) return
    let active = true
    ;(async () => {
      const { data: inv, error: invErr } = await supabase.from('invoices').select('*').eq('id', editId).single()
      const { data: shares } = await supabase
        .from('invoice_shares')
        .select('debtor_id, amount_paid, pending_amount, status')
        .eq('invoice_id', editId)
      if (!active) return
      if (invErr || !inv) {
        setError(invErr?.message ?? 'Facture introuvable')
        setLoadingInvoice(false)
        return
      }
      const invoice = inv as Invoice
      setTitle(invoice.title)
      setAmount(String(invoice.amount))
      setCategory(invoice.category)
      setDueDate(invoice.due_date ?? '')
      if (invoice.period_start && invoice.period_end) {
        setPeriodStart(invoice.period_start)
        setPeriodEnd(invoice.period_end)
      }
      setPayerId(invoice.paid_by)
      setExistingReceipt(invoice.receipt_path)
      const rows = (shares ?? []) as { debtor_id: string; amount_paid: number; pending_amount: number; status: string }[]
      setLocked(rows.some((r) => r.amount_paid > 0 || r.pending_amount > 0 || r.status === 'awaiting_confirmation' || r.status === 'confirmed'))
      setIncluded(new Set(rows.map((r) => r.debtor_id)))
      setLoadingInvoice(false)
    })()
    return () => {
      active = false
    }
  }, [editId])

  if (!apartment || !user) return null

  const payer = payerId ?? user.id
  const usesPeriod = category === 'eau' || category === 'electricite'
  const periodValid = usesPeriod && !!periodStart && !!periodEnd && periodEnd >= periodStart
  const isIncluded = (id: string) => included === null || included.has(id)
  const debtorIds = members.filter((m) => m.user_id !== payer && isIncluded(m.user_id)).map((m) => m.user_id)
  const total = parseFloat(amount)
  const validTotal = !isNaN(total) && total > 0

  const preview = validTotal
    ? computeShares(total, payer, debtorIds, absences, periodValid ? periodStart : null, periodValid ? periodEnd : null)
    : new Map<string, { amount: number; present: number; total: number }>()

  function toggle(id: string) {
    setIncluded((prev) => {
      const base = prev ?? new Set(members.map((m) => m.user_id))
      const next = new Set(base)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  async function uploadReceipt(invoiceId: string) {
    if (!receipt || !apartment) return
    try {
      const ext = receipt.name.split('.').pop() || 'jpg'
      const path = `${apartment.id}/receipts/${invoiceId}-${Date.now()}.${ext}`
      const { error: upErr } = await supabase.storage.from('receipts').upload(path, receipt)
      if (upErr) throw upErr
      const { error: updErr } = await supabase.from('invoices').update({ receipt_path: path }).eq('id', invoiceId)
      if (updErr) throw updErr
      if (existingReceipt) await supabase.storage.from('receipts').remove([existingReceipt])
    } catch {
      toast("Facture enregistrée, mais le reçu n'a pas pu être envoyé", 'info')
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!apartment || !user) return
    setError(null)
    setLoading(true)

    try {
      if (!validTotal) throw new Error('Montant invalide')
      if (receipt && receipt.size > 5 * 1024 * 1024) throw new Error('Reçu trop volumineux (5 Mo maximum)')

      const params = {
        p_title: title.trim(),
        p_amount: total,
        p_category: category,
        p_due: dueDate || null,
        p_debtors: debtorIds,
        p_period_start: periodValid ? periodStart : null,
        p_period_end: periodValid ? periodEnd : null,
      }

      if (isEdit && editId) {
        const { error: rpcErr } = await supabase.rpc('update_invoice', { p_invoice: editId, ...params })
        if (rpcErr) throw rpcErr
        await uploadReceipt(editId)
        toast('Facture modifiée', 'success')
        navigate('/factures', { replace: true })
      } else {
        const { data: invoiceId, error: rpcErr } = await supabase.rpc('create_invoice_with_shares', {
          p_apartment: apartment.id,
          ...params,
        })
        if (rpcErr) throw rpcErr
        if (invoiceId) await uploadReceipt(invoiceId as string)
        toast('Facture créée', 'success')
        navigate('/', { replace: true })
      }
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setLoading(false)
    }
  }

  if (loadingInvoice) {
    return (
      <Layout>
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      </Layout>
    )
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 16 }}>{isEdit ? 'Modifier la facture' : 'Nouvelle facture'}</h1>

      <form onSubmit={handleSubmit} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {locked && (
          <div role="status" style={{ background: 'var(--warning-bg)', color: 'var(--warning-text)', padding: 10, borderRadius: 8, fontSize: 12.5, lineHeight: 1.5 }}>
            <Lock size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Des paiements ont déjà été enregistrés : seuls le titre, la catégorie, l'échéance et le reçu sont modifiables.
          </div>
        )}

        <div>
          <label htmlFor="title" style={labelStyle}>Titre</label>
          <input id="title" type="text" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex : Électricité octobre" style={inputStyle} />
        </div>

        <div>
          <label htmlFor="amount" style={labelStyle}>Montant total (DH)</label>
          <input id="amount" type="number" inputMode="decimal" required min="0.01" step="0.01" value={amount} disabled={locked} onChange={(e) => setAmount(e.target.value)} placeholder="250" style={inputStyle} />
        </div>

        <div>
          <label htmlFor="category" style={labelStyle}>Catégorie</label>
          <select id="category" value={category} onChange={(e) => setCategory(e.target.value as Category)} style={{ ...inputStyle, background: '#fff' }}>
            {CATEGORIES.map((c) => (<option key={c.value} value={c.value}>{c.label}</option>))}
          </select>
        </div>

        {usesPeriod && (
          <div style={{ background: 'var(--primary-bg)', borderRadius: 10, padding: 12 }}>
            <span style={{ ...labelStyle, color: 'var(--primary)' }}>Période facturée (absences prises en compte)</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <input aria-label="Début de période" type="date" value={periodStart} disabled={locked} onChange={(e) => setPeriodStart(e.target.value)} style={{ ...inputStyle, background: '#fff' }} />
              <input aria-label="Fin de période" type="date" value={periodEnd} min={periodStart} disabled={locked} onChange={(e) => setPeriodEnd(e.target.value)} style={{ ...inputStyle, background: '#fff' }} />
            </div>
            <p style={{ fontSize: 11.5, color: 'var(--primary)', marginTop: 6, lineHeight: 1.5 }}>
              Les parts sont calculées au prorata des jours de présence de chacun.
            </p>
          </div>
        )}

        <div>
          <label htmlFor="due" style={labelStyle}>Date d'échéance (optionnel)</label>
          <input id="due" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} style={inputStyle} />
        </div>

        <div>
          <span style={labelStyle}>Qui partage cette facture ?</span>
          {membersLoading ? (
            <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Chargement…</div>
          ) : (
            members.map((m) => {
              const isPayer = m.user_id === payer
              const checked = isPayer || isIncluded(m.user_id)
              const name = m.profile?.full_name ?? 'Colocataire'
              const info = preview.get(m.user_id)
              return (
                <label key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: '1px dashed var(--border)', fontSize: 13, opacity: isPayer ? 0.7 : 1 }}>
                  <input type="checkbox" checked={checked} disabled={isPayer || locked} onChange={() => toggle(m.user_id)} style={{ width: 18, height: 18 }} />
                  <span style={{ flex: 1 }}>
                    {name}{isPayer ? ' (a payé)' : ''}
                    {info && periodValid && info.present < info.total && (
                      <span style={{ display: 'block', fontSize: 11, color: 'var(--warning-text)' }}>
                        <PlaneTakeoff size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />présent {info.present}/{info.total} jours
                      </span>
                    )}
                  </span>
                  {checked && info && <span className="money" style={{ fontWeight: 700 }}>{formatMoney(info.amount)}</span>}
                </label>
              )
            })
          )}
        </div>

        <div>
          <label htmlFor="receipt" style={labelStyle}>
            Reçu ou photo (optionnel){existingReceipt ? ' — un reçu existe déjà, en choisir un remplace l\'ancien' : ''}
          </label>
          <input id="receipt" type="file" accept="image/*,application/pdf" onChange={(e) => setReceipt(e.target.files?.[0] ?? null)} style={{ width: '100%', fontSize: 12 }} />
        </div>

        <div style={{ background: 'var(--primary-bg)', color: 'var(--primary)', padding: 12, borderRadius: 10, fontSize: 12.5, lineHeight: 1.5 }}>
          <Lightbulb size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Chaque colocataire coché doit sa part à celui qui a payé. Les centimes restants restent à sa charge.
        </div>

        {error && (<div role="alert" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: 10, borderRadius: 8, fontSize: 12.5 }}>{error}</div>)}

        <div style={{ display: 'flex', gap: 8 }}>
          <button type="button" onClick={() => navigate(-1)} className="btn btn-secondary" style={{ flex: 1 }}>Annuler</button>
          <button type="submit" className="btn btn-primary" disabled={loading || !validTotal || title.trim().length === 0} style={{ flex: 1 }}>
            {loading ? 'Enregistrement…' : isEdit ? 'Enregistrer' : 'Créer'}
          </button>
        </div>
      </form>
    </Layout>
  )
}
