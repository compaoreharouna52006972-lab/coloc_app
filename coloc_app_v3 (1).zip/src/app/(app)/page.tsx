'use client'

import { AlertTriangle, CheckCircle2, FileText, Plus } from 'lucide-react'
import { useMemo } from 'react'
import { Navigate, Link } from '@/lib/router'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { useDebts } from '@/hooks/useDebts'
import Layout from '@/components/Layout'
import MyObligations from '@/components/MyObligations'
import {
  computeRemaining,
  isLate,
  totalPending,
  totalLate,
  totalConfirmedThisMonth,
} from '@/utils/balance'
import { formatMoney } from '@/utils/format'

function greeting(): string {
  const h = new Date().getHours()
  if (h < 5) return 'Bonsoir'
  if (h < 18) return 'Bonjour'
  return 'Bonsoir'
}

export default function HomePage() {
  const { profile } = useAuth()
  const { apartment, member, loading: aptLoading } = useApartment()
  const { debts, loading: debtsLoading } = useDebts()

  const stats = useMemo(
    () => ({
      total: totalPending(debts),
      late: totalLate(debts),
      confirmed: totalConfirmedThisMonth(debts),
    }),
    [debts]
  )

  const myDebts = useMemo(
    () => debts.filter((d) => d.debtor_id === profile?.id && d.status !== 'confirmed'),
    [debts, profile?.id]
  )

  const myCredits = useMemo(
    () => debts.filter((d) => d.creditor_id === profile?.id && d.status !== 'confirmed'),
    [debts, profile?.id]
  )

  if (aptLoading) {
    return (
      <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
        Chargement…
      </div>
    )
  }

  if (!apartment) {
    return <Navigate to="/onboarding" replace />
  }

  const firstName = profile?.full_name?.split('@')[0].split(' ')[0] ?? 'toi'
  const hero = (
    <div style={{ marginTop: 18 }}>
      <div style={{ fontSize: 23, fontWeight: 800, letterSpacing: -0.3 }}>
        {greeting()} {firstName}
      </div>
      <div style={{ fontSize: 12.5, opacity: 0.65, marginTop: 3 }}>Voici l'état de votre appartement aujourd'hui.</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 16 }}>
        {[
          { label: 'Total dû', value: stats.total, color: '#EEF1EF' },
          { label: 'En retard', value: stats.late, color: stats.late > 0 ? '#F0C48A' : '#EEF1EF' },
          { label: 'Réglé ce mois', value: stats.confirmed, color: '#EEF1EF' },
        ].map((k) => (
          <div key={k.label} style={{ background: 'rgba(255,255,255,0.07)', borderRadius: 12, padding: '12px 13px' }}>
            <div style={{ fontSize: 10.5, opacity: 0.6, fontWeight: 500 }}>{k.label}</div>
            <div className="money" style={{ fontSize: 17, fontWeight: 800, marginTop: 2, color: k.color }}>{formatMoney(k.value)}</div>
          </div>
        ))}
      </div>
    </div>
  )

  return (
    <Layout hero={hero}>
      {/* Mes obligations : ménage, tâches, dettes à régler, paiements à confirmer */}
      <MyObligations debts={debts} />

      <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
        <Link to="/factures/nouvelle" className="btn btn-primary" style={{ flex: 1 }}>
          <Plus size={16} /> Ajouter une facture
        </Link>
        <Link to="/factures" className="btn btn-secondary" style={{ flex: 1 }}>
          <FileText size={16} /> Historique
        </Link>
      </div>

      {/* Dettes de chacun */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <h2 style={{ fontSize: 16, fontWeight: 700 }}>Dettes de chacun</h2>
        <Link to="/dettes" style={{ fontSize: 12, color: 'var(--primary-light)', fontWeight: 600 }}>
          Voir tout →
        </Link>
      </div>

      {debtsLoading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
          Chargement…
        </div>
      ) : debts.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--success-text)', fontSize: 13, fontWeight: 600 }}>
          <CheckCircle2 size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />Tout le monde est à jour !
        </div>
      ) : (
        <div style={{ marginBottom: 20 }}>
          {debts
            .filter((d) => d.status !== 'confirmed')
            .slice(0, 5)
            .map((d) => {
              const remaining = computeRemaining(d)
              const late = isLate(d, d.invoice.due_date)
              const canPay = d.debtor_id === profile?.id
              const canConfirm =
                d.creditor_id === profile?.id && d.status === 'awaiting_confirmation'

              return (
                <div
                  key={d.id}
                  className="card"
                  style={{
                    padding: 14,
                    marginBottom: 8,
                    borderLeft: late ? '4px solid var(--danger)' : '4px solid var(--warning)',
                    background: late ? 'var(--danger-bg)' : 'var(--card)',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--primary)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 13 }}>
                        {(d.debtor?.full_name ?? 'Inconnu').charAt(0).toUpperCase()}
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700 }}>
                        {(d.debtor?.full_name ?? 'Inconnu').split(' ')[0]}
                      </span>
                      <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>doit</span>
                      <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent)', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 13 }}>
                        {(d.creditor?.full_name ?? 'Inconnu').charAt(0).toUpperCase()}
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700 }}>
                        {(d.creditor?.full_name ?? 'Inconnu').split(' ')[0]}
                      </span>
                    </div>
                    <span className="money" style={{ fontSize: 15, fontWeight: 800, color: 'var(--danger-text)' }}>
                      {formatMoney(remaining)}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10, fontSize: 11.5, color: 'var(--text-muted)' }}>
                    <span style={{ background: 'var(--primary-bg)', color: 'var(--primary)', padding: '2px 8px', borderRadius: 5, fontWeight: 600 }}>
                      {d.invoice.title}
                    </span>
                    {late && (
                      <span style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', padding: '2px 8px', borderRadius: 5, fontWeight: 700 }}>
                        <AlertTriangle size={14} style={{ verticalAlign: '-2px', marginRight: 5 }} />En retard
                      </span>
                    )}
                    {d.status === 'awaiting_confirmation' && (
                      <span style={{ background: 'var(--warning-bg)', color: 'var(--warning-text)', padding: '2px 8px', borderRadius: 5, fontWeight: 700 }}>
                        ⏳ En attente
                      </span>
                    )}
                  </div>

                  {canPay && (d.status === 'pending' || d.status === 'disputed') && (
                    <Link
                      to={`/dettes/${d.id}/payer`}
                      className="btn btn-primary"
                      style={{ display: 'block', textAlign: 'center', textDecoration: 'none', padding: '10px', fontSize: 13 }}
                    >
                      Régler ma part
                    </Link>
                  )}

                  {canConfirm && (
                    <Link
                      to={`/dettes/${d.id}/confirmer`}
                      className="btn btn-success"
                      style={{ display: 'block', textAlign: 'center', textDecoration: 'none', padding: '10px', fontSize: 13 }}
                    >
                      Confirmer la réception
                    </Link>
                  )}
                </div>
              )
            })}
        </div>
      )}

      {/* Mes dettes / mes créances */}
      {(myDebts.length > 0 || myCredits.length > 0) && (
        <div className="card" style={{ marginBottom: 16 }}>
          <h3 style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 10 }}>Ta situation
          </h3>
          {myDebts.length > 0 && (
            <div style={{ fontSize: 12.5, marginBottom: 6, color: 'var(--danger-text)' }}>
              Tu dois <strong>{formatMoney(myDebts.reduce((s, d) => s + computeRemaining(d), 0))}</strong> à tes colocataires
            </div>
          )}
          {myCredits.length > 0 && (
            <div style={{ fontSize: 12.5, color: 'var(--success-text)' }}>
              On te doit <strong>{formatMoney(myCredits.reduce((s, d) => s + computeRemaining(d), 0))}</strong>
            </div>
          )}
        </div>
      )}

      {/* Code d'invitation */}
      <div className="card">
        <h3 style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Inviter un colocataire
        </h3>
        <div
          style={{
            background: 'var(--primary-bg)',
            color: 'var(--primary)',
            borderRadius: 10,
            padding: '14px 18px',
            textAlign: 'center',
            fontSize: 22,
            fontWeight: 800,
            letterSpacing: '0.15em',
          }}
        >
          {apartment.invite_code}
        </div>
      </div>
    </Layout>
  )
}
