'use client'

import { Trash2 } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import Layout from '@/components/Layout'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { useToast } from '@/contexts/ToastContext'
import { useAbsences } from '@/hooks/useAbsences'
import { useMembers } from '@/hooks/useMembers'
import { errorMessage } from '@/utils/errors'

const inputStyle = { width: '100%', padding: '12px 14px', border: '1.5px solid var(--border)', borderRadius: 10, outline: 'none' } as const

function fmt(d: string) {
  return new Date(`${d}T00:00:00`).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
}

function dayCount(start: string, end: string) {
  return Math.round((new Date(`${end}T00:00:00Z`).getTime() - new Date(`${start}T00:00:00Z`).getTime()) / 86400000) + 1
}

export default function AbsencesPage() {
  const { user } = useAuth()
  const { member } = useApartment()
  const { toast } = useToast()
  const { absences, loading, declare, remove } = useAbsences()
  const { members } = useMembers()
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')
  const [busy, setBusy] = useState(false)

  const nameOf = (id: string) => members.find((m) => m.user_id === id)?.profile?.full_name ?? 'Colocataire'
  const today = new Date().toISOString().slice(0, 10)
  const validRange = !!start && !!end && end >= start

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!validRange) return
    setBusy(true)
    try {
      await declare(start, end)
      toast('Absence enregistrée, tes colocataires sont prévenus', 'success')
      setStart('')
      setEnd('')
    } catch (err) {
      toast(errorMessage(err), 'error')
    } finally {
      setBusy(false)
    }
  }

  async function handleRemove(id: string) {
    if (!confirm('Supprimer cette absence ?')) return
    try {
      await remove(id)
      toast('Absence supprimée', 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    }
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Absences</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
        Ta part d'eau et d'électricité baisse au prorata des jours d'absence.
      </p>

      <form onSubmit={handleSubmit} className="card" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <div style={{ flex: 1 }}>
            <label htmlFor="abs-start" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Du</label>
            <input id="abs-start" type="date" required value={start} onChange={(e) => setStart(e.target.value)} style={inputStyle} />
          </div>
          <div style={{ flex: 1 }}>
            <label htmlFor="abs-end" style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Au (inclus)</label>
            <input id="abs-end" type="date" required min={start || undefined} value={end} onChange={(e) => setEnd(e.target.value)} style={inputStyle} />
          </div>
        </div>
        {validRange && (
          <div style={{ fontSize: 12.5, color: 'var(--primary)', background: 'var(--primary-bg)', padding: 10, borderRadius: 8 }}>
            {dayCount(start, end)} jour(s) d'absence déclarés.
          </div>
        )}
        <button type="submit" className="btn btn-primary" disabled={busy || !validRange}>
          {busy ? 'Enregistrement…' : "Déclarer mon absence"}
        </button>
        <p style={{ fontSize: 11.5, color: 'var(--text-muted)', lineHeight: 1.5 }}>
          Elle compte dès le premier jour pour les factures d'eau et d'électricité créées ensuite avec une période. Le loyer et le WiFi restent à parts égales.
        </p>
      </form>

      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      ) : absences.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Aucune absence déclarée.</div>
      ) : (
        absences.map((a) => {
          const mine = a.user_id === user?.id
          const past = a.end_date < today
          return (
            <div key={a.id} className="card" style={{ marginBottom: 8, padding: 14, opacity: past ? 0.65 : 1, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13.5, fontWeight: 700 }}>{mine ? 'Toi' : nameOf(a.user_id)}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                  {fmt(a.start_date)} → {fmt(a.end_date)} · {dayCount(a.start_date, a.end_date)} j
                </div>
              </div>
              {(mine || member?.role === 'admin') && (
                <button onClick={() => handleRemove(a.id)} aria-label="Supprimer l'absence" style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', border: 'none', padding: '6px 10px', borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}><Trash2 size={15} /></button>
              )}
            </div>
          )
        })
      )}
    </Layout>
  )
}
