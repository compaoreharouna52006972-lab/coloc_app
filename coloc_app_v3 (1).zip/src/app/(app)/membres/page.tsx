'use client'

import { useState } from 'react'
import { useNavigate } from '@/lib/router'
import Layout from '@/components/Layout'
import { useAuth } from '@/contexts/AuthContext'
import { useApartment } from '@/contexts/ApartmentContext'
import { useToast } from '@/contexts/ToastContext'
import { useMembers } from '@/hooks/useMembers'
import { errorMessage } from '@/utils/errors'
import type { Member } from '@/types'

const ROLE_LABEL: Record<Member['role'], string> = {
  admin: 'Admin',
  manager: 'Gestionnaire',
  member: 'Membre',
}

export default function MembersPage() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { apartment, member } = useApartment()
  const { toast } = useToast()
  const { members, loading, setRole, removeMember, leave, regenerateCode } = useMembers()
  const [busy, setBusy] = useState(false)

  if (!apartment) return null
  const isAdmin = member?.role === 'admin'

  const run = async (action: () => Promise<void>, ok?: string) => {
    setBusy(true)
    try {
      await action()
      if (ok) toast(ok, 'success')
    } catch (err) {
      toast(errorMessage(err), 'error')
    } finally {
      setBusy(false)
    }
  }

  const shareInvite = async () => {
    const text = `Rejoins « ${apartment.name} » sur Appart 4B avec le code ${apartment.invite_code} : ${window.location.origin}`
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Appart 4B', text })
      } catch {
        /* partage annulé */
      }
      return
    }
    try {
      await navigator.clipboard.writeText(text)
      toast('Invitation copiée', 'success')
    } catch {
      toast('Copie impossible sur cet appareil', 'error')
    }
  }

  const handleLeave = () => {
    if (!confirm("Quitter l'appartement ? Tu devras être réinvité pour y revenir.")) return
    run(async () => {
      await leave()
      navigate('/', { replace: true })
    })
  }

  return (
    <Layout>
      <h1 className="page-title" style={{ marginBottom: 4 }}>Colocataires</h1>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>{apartment.name}</p>

      <div className="card" style={{ marginBottom: 14 }}>
        <h2 style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Inviter quelqu'un</h2>
        <div
          style={{
            background: 'var(--primary-bg)',
            color: 'var(--primary)',
            borderRadius: 10,
            padding: '12px 16px',
            textAlign: 'center',
            fontSize: 22,
            fontWeight: 800,
            letterSpacing: '0.15em',
          }}
        >
          {apartment.invite_code}
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={shareInvite}>
            Partager
          </button>
          {isAdmin && (
            <button
              className="btn btn-secondary"
              style={{ flex: 1 }}
              disabled={busy}
              onClick={() => {
                if (confirm("Générer un nouveau code ? L'ancien ne fonctionnera plus.")) {
                  run(regenerateCode, 'Nouveau code généré')
                }
              }}
            >
              Nouveau code
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Chargement…</div>
      ) : (
        members.map((m) => {
          const name = m.profile?.full_name ?? 'Colocataire'
          const isMe = m.user_id === user?.id
          return (
            <div key={m.id} className="card" style={{ marginBottom: 8, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div
                  style={{
                    width: 38,
                    height: 38,
                    borderRadius: '50%',
                    background: isMe ? 'var(--accent)' : 'var(--primary)',
                    color: '#fff',
                    display: 'grid',
                    placeItems: 'center',
                    fontWeight: 700,
                  }}
                >
                  {name.charAt(0).toUpperCase()}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700 }}>
                    {name} {isMe && <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>(toi)</span>}
                  </div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{ROLE_LABEL[m.role]}</div>
                </div>
              </div>

              {isAdmin && !isMe && (
                <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
                  <select
                    aria-label={`Rôle de ${name}`}
                    value={m.role}
                    disabled={busy}
                    onChange={(e) => run(() => setRole(m.id, e.target.value as Member['role']), 'Rôle mis à jour')}
                    style={{ flex: 1, padding: '7px 10px', border: '1.5px solid var(--border)', borderRadius: 8, fontSize: 12, background: '#fff' }}
                  >
                    <option value="member">Membre</option>
                    <option value="manager">Gestionnaire</option>
                    <option value="admin">Admin</option>
                  </select>
                  <button
                    disabled={busy}
                    onClick={() => {
                      if (confirm(`Retirer ${name} de l'appartement ?`)) run(() => removeMember(m.id), `${name} a été retiré`)
                    }}
                    style={{ background: 'var(--danger-bg)', color: 'var(--danger-text)', border: 'none', padding: '7px 12px', borderRadius: 8, fontSize: 11.5, fontWeight: 700, cursor: 'pointer' }}
                  >
                    Retirer
                  </button>
                </div>
              )}
            </div>
          )
        })
      )}

      <button className="btn btn-danger" style={{ width: '100%', marginTop: 8 }} disabled={busy} onClick={handleLeave}>
        Quitter l'appartement
      </button>
    </Layout>
  )
}
