'use client'

import { useEffect, type ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/AuthContext'

// Remplace l'ancien ProtectedRoute : toutes les pages de ce groupe exigent une connexion.
// (Les données restent protégées par les règles d'accès de la base, pas seulement par cet écran.)
export default function ProtectedLayout({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) router.replace('/login')
  }, [loading, user, router])

  if (loading || !user) {
    return (
      <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)', fontSize: 14 }}>
        Chargement…
      </div>
    )
  }

  return <>{children}</>
}
