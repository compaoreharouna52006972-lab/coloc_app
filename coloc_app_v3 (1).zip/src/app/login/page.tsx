'use client'

import { useState, type FormEvent } from 'react'
import { Navigate } from '@/lib/router'
import { useAuth } from '@/contexts/AuthContext'

export default function LoginPage() {
  const { user, signInWithEmail } = useAuth()
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (user) {
    return <Navigate to="/" replace />
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await signInWithEmail(email)
      setSent(true)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue'
      setError(message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20,
      }}
    >
      <div style={{ width: '100%', maxWidth: 420 }}>
        <div
          style={{
            background: 'var(--hero)',
            color: '#EEF1EF',
            borderRadius: 20,
            padding: '40px 24px',
            textAlign: 'center',
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 11.5, letterSpacing: 1.2, opacity: 0.55, textTransform: 'uppercase', fontWeight: 600 }}>Appart 4B</div>
          <h1 style={{ fontSize: 26, fontWeight: 800, letterSpacing: -0.3, marginTop: 4 }}>Connexion</h1>
          <p style={{ fontSize: 13, opacity: 0.7, marginTop: 6 }}>Gestion de colocation</p>
        </div>

        {sent ? (
          <div className="card" role="status" aria-live="polite">
            <h2
              style={{
                fontSize: 16,
                fontWeight: 700,
                marginBottom: 10,
                color: 'var(--success-text)',
              }}
            >Lien envoyé
            </h2>
            <p
              style={{
                fontSize: 13.5,
                color: 'var(--text-muted)',
                lineHeight: 1.6,
              }}
            >
              Un lien de connexion a été envoyé à <strong>{email}</strong>.
              <br />
              Ouvre ta boîte mail et clique sur le lien pour te connecter.
            </p>
            <button
              className="btn btn-secondary"
              style={{ marginTop: 16, width: '100%' }}
              onClick={() => {
                setSent(false)
                setEmail('')
              }}
            >
              Renvoyer un lien
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="card"
            style={{ display: 'flex', flexDirection: 'column', gap: 14 }}
          >
            <div>
              <label
                htmlFor="email"
                style={{
                  display: 'block',
                  fontSize: 13,
                  fontWeight: 600,
                  marginBottom: 6,
                }}
              >
                Ton adresse email
              </label>
              <input
                id="email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="prenom@exemple.com"
                aria-describedby="email-help"
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  border: '1.5px solid var(--border)',
                  borderRadius: 10,
                  outline: 'none',
                }}
              />
              <p
                id="email-help"
                style={{
                  fontSize: 11.5,
                  color: 'var(--text-muted)',
                  marginTop: 6,
                }}
              >
                On t'enverra un lien magique pour te connecter, sans mot de passe.
              </p>
            </div>

            {error && (
              <div
                role="alert"
                style={{
                  background: 'var(--danger-bg)',
                  color: 'var(--danger-text)',
                  padding: 10,
                  borderRadius: 8,
                  fontSize: 12.5,
                }}
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading || !email}
              style={{ width: '100%' }}
            >
              {loading ? 'Envoi…' : 'Recevoir le lien'}
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
