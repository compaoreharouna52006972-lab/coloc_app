// Charge un fichier TypeScript de src/ pour les tests, sans outil de build :
// il est converti en JavaScript (avec ses dépendances locales) dans un dossier temporaire.
import { createRequire } from 'node:module'
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const require = createRequire(import.meta.url)
const ts = require('typescript')
const SRC = resolve(import.meta.dirname, '../../src')
const OUT = mkdtempSync(join(tmpdir(), 'coloc-tests-'))
const done = new Set()

function candidate(base) {
  for (const c of [base + '.ts', base + '.tsx', join(base, 'index.ts')]) if (existsSync(c)) return c
  throw new Error('Module introuvable : ' + base)
}

function compile(file) {
  if (done.has(file)) return
  done.add(file)
  const source = readFileSync(file, 'utf8')
  let js = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
  }).outputText
  const rel = file.slice(SRC.length + 1).replace(/\.tsx?$/, '.mjs')
  js = js.replace(/from\s+(['"])(\.{1,2}\/[^'"]+|@\/[^'"]+)\1/g, (_, q, spec) => {
    const target = candidate(spec.startsWith('@/') ? join(SRC, spec.slice(2)) : resolve(dirname(file), spec))
    compile(target)
    const targetRel = target.slice(SRC.length + 1).replace(/\.tsx?$/, '.mjs')
    let r = relativeImport(rel, targetRel)
    return `from ${q}${r}${q}`
  })
  const dest = join(OUT, rel)
  mkdirSync(dirname(dest), { recursive: true })
  writeFileSync(dest, js)
}

function relativeImport(fromRel, toRel) {
  const fromParts = dirname(fromRel).split('/').filter((p) => p && p !== '.')
  const toParts = toRel.split('/')
  while (fromParts.length && toParts.length > 1 && fromParts[0] === toParts[0]) {
    fromParts.shift()
    toParts.shift()
  }
  const up = fromParts.map(() => '..')
  return (up.length ? up : ['.']).concat(toParts).join('/')
}

export async function load(srcRelativePath) {
  const file = candidate(join(SRC, srcRelativePath.replace(/\.tsx?$/, '')))
  compile(file)
  const out = join(OUT, file.slice(SRC.length + 1).replace(/\.tsx?$/, '.mjs'))
  return import(pathToFileURL(out).href)
}
