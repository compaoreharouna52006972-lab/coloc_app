// Lancer avec : npm test   (Node 22+, après npm install)
import test from 'node:test'
import assert from 'node:assert/strict'
import { load } from './helpers/load.mjs'

const balance = await load('utils/balance.ts')
const presence = await load('utils/presence.ts')
const format = await load('utils/format.ts')

const share = (over = {}) => ({
  id: 's', invoice_id: 'i', debtor_id: 'B', creditor_id: 'A',
  amount_due: 100, amount_paid: 0, status: 'pending',
  debtor: { id: 'B', full_name: 'Bilal' }, creditor: { id: 'A', full_name: 'Amine' },
  ...over,
})

test('computeRemaining ne descend jamais sous zéro', () => {
  assert.equal(balance.computeRemaining(share({ amount_due: 100, amount_paid: 30 })), 70)
  assert.equal(balance.computeRemaining(share({ amount_due: 100, amount_paid: 120 })), 0)
})

test('netBalances ignore les dettes confirmées et déduit les paiements partiels', () => {
  const nets = balance.netBalances([
    share({ amount_paid: 40 }),
    share({ debtor_id: 'C', debtor: { id: 'C', full_name: 'Chaima' }, status: 'confirmed', amount_paid: 100 }),
  ])
  const by = Object.fromEntries(nets.map((n) => [n.id, n.amount]))
  assert.equal(by.B, -60)
  assert.equal(by.A, 60)
  assert.equal(by.C, undefined)
})

test('settleUp solde tout avec le moins de virements et conserve la somme', () => {
  const t = balance.settleUp([
    { id: 'A', name: 'A', amount: 100 },
    { id: 'B', name: 'B', amount: -60 },
    { id: 'C', name: 'C', amount: -40 },
  ])
  assert.deepEqual(t, [{ from: 'B', to: 'A', amount: 60 }, { from: 'C', to: 'A', amount: 40 }])
})

test('settleUp : jamais de centime perdu, même avec des montants décimaux', () => {
  const balances = [
    { id: 'A', name: 'A', amount: 33.33 },
    { id: 'B', name: 'B', amount: 66.67 },
    { id: 'C', name: 'C', amount: -50.1 },
    { id: 'D', name: 'D', amount: -49.9 },
  ]
  const sent = {}
  const recv = {}
  for (const t of balance.settleUp(balances)) {
    sent[t.from] = (sent[t.from] ?? 0) + Math.round(t.amount * 100)
    recv[t.to] = (recv[t.to] ?? 0) + Math.round(t.amount * 100)
  }
  assert.equal(sent.C, 5010)
  assert.equal(sent.D, 4990)
  assert.equal(recv.A, 3333)
  assert.equal(recv.B, 6667)
})

function daysFromToday(delta) {
  const [y, m, d] = format.todayMA().split('-').map(Number)
  return new Date(Date.UTC(y, m - 1, d + delta)).toISOString().slice(0, 10)
}

test('isLate : une échéance du jour n\'est PAS en retard, celle d\'hier oui', () => {
  assert.equal(balance.isLate(share(), daysFromToday(0)), false)
  assert.equal(balance.isLate(share(), daysFromToday(1)), false)
  assert.equal(balance.isLate(share(), daysFromToday(-1)), true)
  assert.equal(balance.isLate(share(), null), false)
})

test('isLate : une dette confirmée n\'est jamais en retard', () => {
  assert.equal(balance.isLate(share({ status: 'confirmed' }), daysFromToday(-30)), false)
})

test('totalPending et totalLate', () => {
  const rows = [
    { ...share({ amount_due: 100, amount_paid: 40 }), invoice: { id: 'i', title: 't', due_date: daysFromToday(-2), category: 'eau', amount: 100, created_at: '' } },
    { ...share({ amount_due: 50, status: 'confirmed', amount_paid: 50 }), invoice: { id: 'i', title: 't', due_date: daysFromToday(-2), category: 'eau', amount: 50, created_at: '' } },
    { ...share({ amount_due: 30 }), invoice: { id: 'i', title: 't', due_date: daysFromToday(5), category: 'eau', amount: 30, created_at: '' } },
  ]
  assert.equal(balance.totalPending(rows), 90)
  assert.equal(balance.totalLate(rows), 60)
})

test('todayMA renvoie une date AAAA-MM-JJ', () => {
  assert.match(format.todayMA(), /^\d{4}-\d{2}-\d{2}$/)
})

test('computeShares : parts égales sans période, le payeur est exclu', () => {
  const m = presence.computeShares(300, 'A', ['A', 'B', 'C'], [])
  assert.equal(m.has('A'), false)
  assert.equal(m.get('B').amount, 100)
  assert.equal(m.get('C').amount, 100)
})

test('computeShares : eau/électricité au prorata des jours de présence (exemple 400 DH sur 30 jours)', () => {
  // B absent 18 jours sur 30 : présent 12 jours. A (payeur), C, D présents 30 jours.
  const absences = [{ user_id: 'B', start_date: '2026-11-01', end_date: '2026-11-18' }]
  const m = presence.computeShares(400, 'A', ['A', 'B', 'C', 'D'], absences, '2026-11-01', '2026-11-30')
  const b = m.get('B').amount
  const c = m.get('C').amount
  assert.ok(Math.abs(b - 47.06) <= 0.015, `B = ${b}`)
  assert.ok(Math.abs(c - 117.65) <= 0.015, `C = ${c}`)
  assert.equal(m.get('B').present, 12)
  assert.equal(m.get('B').total, 30)
  const debtors = [...m.values()].reduce((s, x) => s + x.amount, 0)
  // Le payeur garde sa propre part (≈ 117,65) et absorbe les centimes d'arrondi des autres
  assert.ok(Math.abs(400 - debtors - 117.65) < 0.05, `part du payeur = ${(400 - debtors).toFixed(2)}`)
})

test('computeShares : tout le monde absent sur la période → répartition égale (pas de division par zéro)', () => {
  const abs = ['A', 'B', 'C'].map((u) => ({ user_id: u, start_date: '2026-11-01', end_date: '2026-11-30' }))
  const m = presence.computeShares(300, 'A', ['A', 'B', 'C'], abs, '2026-11-01', '2026-11-30')
  assert.ok(Number.isFinite(m.get('B').amount))
  assert.equal(m.get('B').amount, m.get('C').amount)
})

test('previousMonthRange : mois précédent complet', () => {
  const r = presence.previousMonthRange()
  assert.match(r.start, /^\d{4}-\d{2}-01$/)
  assert.ok(r.end > r.start)
})

test('formatMoney affiche un montant en dirhams', () => {
  assert.match(format.formatMoney(450.5), /^450,50 DH$/)
  assert.match(format.formatMoney(450), /^450 DH$/)
  assert.match(format.formatMoney(1234.5), /^1.234,50 DH$/)
})
